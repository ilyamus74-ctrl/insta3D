/*!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19  Distrib 10.11.8-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: maklertour
-- ------------------------------------------------------
-- Server version	10.11.8-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `audit_logs`
--

DROP TABLE IF EXISTS `audit_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `audit_logs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uid_created` bigint(20) unsigned DEFAULT NULL,
  `event_time` datetime(6) NOT NULL DEFAULT current_timestamp(6),
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `event_type` varchar(64) NOT NULL,
  `entity_type` varchar(64) DEFAULT NULL,
  `entity_id` bigint(20) unsigned DEFAULT NULL,
  `ip_address` varchar(64) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `description` text DEFAULT NULL,
  `extra_data` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`extra_data`)),
  PRIMARY KEY (`id`),
  KEY `idx_audit_user` (`user_id`),
  KEY `idx_audit_event_time` (`event_time`)
) ENGINE=InnoDB AUTO_INCREMENT=79 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `audit_logs`
--

LOCK TABLES `audit_logs` WRITE;
/*!40000 ALTER TABLE `audit_logs` DISABLE KEYS */;
INSERT INTO `audit_logs` VALUES
(1,1778418301678120,'2026-05-10 16:05:01.678308',1,'LOGIN',NULL,NULL,'84.166.209.16','Mozilla/5.0 (X11; Linux x86_64; rv:145.0) Gecko/20100101 Firefox/145.0','Пользователь вошёл в систему',NULL),
(2,1778424800384035,'2026-05-10 17:53:20.384349',2,'LOGIN',NULL,NULL,'84.166.209.16','Mozilla/5.0 (X11; Linux x86_64; rv:145.0) Gecko/20100101 Firefox/145.0','Пользователь вошёл в систему',NULL),
(3,1778428233754396,'2026-05-10 18:50:33.754913',1,'MOBILE_LOGIN','USER',1,'84.166.209.16','curl/8.9.1','Вход из мобильного приложения','{\"device_name\":\"test-phone\",\"device_fingerprint\":\"test-device-001\",\"ip\":\"84.166.209.16\",\"user_agent\":\"curl\\/8.9.1\"}'),
(4,1778445158217607,'2026-05-10 23:32:38.217884',NULL,'MOBILE_TOKEN_INVALID','MOBILE_TOKEN',NULL,'61.8.134.50','okhttp/4.12.0','Невалидный мобильный token','{\"ip\":\"61.8.134.50\",\"user_agent\":\"okhttp\\/4.12.0\",\"method\":\"POST\",\"uri\":\"\\/api\\/mobile.php?action=ping\",\"reason\":\"token_not_found_or_expired\",\"token_hash_prefix\":\"2987862d7b69\"}'),
(5,1778445163205994,'2026-05-10 23:32:43.206516',NULL,'MOBILE_LOGIN_FAILED','USER',NULL,'61.8.134.50','okhttp/4.12.0','Неудачный вход в мобильное приложение','{\"ip\":\"61.8.134.50\",\"user_agent\":\"okhttp\\/4.12.0\",\"method\":\"POST\",\"uri\":\"\\/api\\/mobile.php?action=login\",\"username\":\"vggf\",\"device_name\":\"motorola motorola edge 50 neo\",\"device_fingerprint\":\"969117b65b9b580f\",\"reason\":\"user_not_found\"}'),
(6,1778445194337183,'2026-05-10 23:33:14.337309',2,'MOBILE_LOGIN','USER',2,'61.8.134.50','okhttp/4.12.0','Вход из мобильного приложения','{\"ip\":\"61.8.134.50\",\"user_agent\":\"okhttp\\/4.12.0\",\"method\":\"POST\",\"uri\":\"\\/api\\/mobile.php?action=login\",\"device_name\":\"motorola motorola edge 50 neo\",\"device_fingerprint\":\"969117b65b9b580f\"}'),
(7,1778445205080724,'2026-05-10 23:33:25.080978',2,'MOBILE_APP_OPEN','USER',2,'61.8.134.50','okhttp/4.12.0','Открытие мобильного приложения','{\"ip\":\"61.8.134.50\",\"user_agent\":\"okhttp\\/4.12.0\",\"method\":\"POST\",\"uri\":\"\\/api\\/mobile.php?action=ping\"}'),
(8,1778448041049006,'2026-05-11 00:20:41.049316',2,'MOBILE_APP_OPEN','USER',2,'61.8.134.41','okhttp/4.12.0','Открытие мобильного приложения','{\"ip\":\"61.8.134.41\",\"user_agent\":\"okhttp\\/4.12.0\",\"method\":\"POST\",\"uri\":\"\\/api\\/mobile.php?action=ping\"}'),
(9,1778448061524732,'2026-05-11 00:21:01.524905',2,'MOBILE_LOGOUT','USER',2,'61.8.134.41','okhttp/4.12.0','Выход из мобильного приложения','{\"ip\":\"61.8.134.41\",\"user_agent\":\"okhttp\\/4.12.0\",\"method\":\"POST\",\"uri\":\"\\/api\\/mobile.php?action=logout\",\"token_hash_prefix\":\"50949862ba4a\"}'),
(10,1778448076483880,'2026-05-11 00:21:16.484039',2,'MOBILE_LOGIN','USER',2,'61.8.134.41','okhttp/4.12.0','Вход из мобильного приложения','{\"ip\":\"61.8.134.41\",\"user_agent\":\"okhttp\\/4.12.0\",\"method\":\"POST\",\"uri\":\"\\/api\\/mobile.php?action=login\",\"device_name\":\"motorola motorola edge 50 neo\",\"device_fingerprint\":\"969117b65b9b580f\"}'),
(11,1778448176349834,'2026-05-11 00:22:56.350075',2,'MOBILE_APP_OPEN','USER',2,'61.8.134.41','okhttp/4.12.0','Открытие мобильного приложения','{\"ip\":\"61.8.134.41\",\"user_agent\":\"okhttp\\/4.12.0\",\"method\":\"POST\",\"uri\":\"\\/api\\/mobile.php?action=ping\"}'),
(12,1778448176871727,'2026-05-11 00:22:56.872008',2,'MOBILE_APP_OPEN','USER',2,'61.8.134.41','okhttp/4.12.0','Открытие мобильного приложения','{\"ip\":\"61.8.134.41\",\"user_agent\":\"okhttp\\/4.12.0\",\"method\":\"POST\",\"uri\":\"\\/api\\/mobile.php?action=ping\"}'),
(13,1778448755727511,'2026-05-11 00:32:35.727754',2,'MOBILE_APP_OPEN','USER',2,'61.8.134.41','okhttp/4.12.0','Открытие мобильного приложения','{\"ip\":\"61.8.134.41\",\"user_agent\":\"okhttp\\/4.12.0\",\"method\":\"POST\",\"uri\":\"\\/api\\/mobile.php?action=ping\"}'),
(14,1778448817344682,'2026-05-11 00:33:37.344992',2,'MOBILE_APP_OPEN','USER',2,'61.8.134.41','okhttp/4.12.0','Открытие мобильного приложения','{\"ip\":\"61.8.134.41\",\"user_agent\":\"okhttp\\/4.12.0\",\"method\":\"POST\",\"uri\":\"\\/api\\/mobile.php?action=ping\"}'),
(15,1778448820425966,'2026-05-11 00:33:40.426218',2,'MOBILE_APP_OPEN','USER',2,'61.8.134.41','okhttp/4.12.0','Открытие мобильного приложения','{\"ip\":\"61.8.134.41\",\"user_agent\":\"okhttp\\/4.12.0\",\"method\":\"POST\",\"uri\":\"\\/api\\/mobile.php?action=ping\"}'),
(16,1778477302279831,'2026-05-11 08:28:22.280622',1,'MOBILE_LOGIN','USER',1,'84.166.209.16','curl/8.9.1','Вход из мобильного приложения','{\"ip\":\"84.166.209.16\",\"user_agent\":\"curl\\/8.9.1\",\"method\":\"POST\",\"uri\":\"\\/api\\/mobile.php?action=login\",\"device_name\":\"curl-test\",\"device_fingerprint\":\"curl-test-001\"}'),
(17,1778478884009594,'2026-05-11 08:54:44.009827',1,'LOGIN',NULL,NULL,'84.166.209.16','Mozilla/5.0 (X11; Linux x86_64; rv:145.0) Gecko/20100101 Firefox/145.0','Пользователь вошёл в систему',NULL),
(18,1778479394289586,'2026-05-11 09:03:14.289806',2,'MOBILE_APP_OPEN','USER',2,'61.8.128.73','okhttp/4.12.0','Открытие мобильного приложения','{\"ip\":\"61.8.128.73\",\"user_agent\":\"okhttp\\/4.12.0\",\"method\":\"POST\",\"uri\":\"\\/api\\/mobile.php?action=ping\"}'),
(19,1778479432585348,'2026-05-11 09:03:52.585806',2,'MOBILE_APP_OPEN','USER',2,'61.8.128.73','okhttp/4.12.0','Открытие мобильного приложения','{\"ip\":\"61.8.128.73\",\"user_agent\":\"okhttp\\/4.12.0\",\"method\":\"POST\",\"uri\":\"\\/api\\/mobile.php?action=ping\"}'),
(20,1778479658974810,'2026-05-11 09:07:38.975008',2,'LOGIN',NULL,NULL,'84.166.209.16','Mozilla/5.0 (X11; Linux x86_64; rv:145.0) Gecko/20100101 Firefox/145.0','Пользователь вошёл в систему',NULL),
(21,1778479868396606,'2026-05-11 09:11:08.396864',2,'MOBILE_APP_OPEN','USER',2,'61.8.134.53','okhttp/4.12.0','Открытие мобильного приложения','{\"ip\":\"61.8.134.53\",\"user_agent\":\"okhttp\\/4.12.0\",\"method\":\"POST\",\"uri\":\"\\/api\\/mobile.php?action=ping\"}'),
(22,1778479882495123,'2026-05-11 09:11:22.495460',2,'MOBILE_LOGOUT','USER',2,'61.8.134.53','okhttp/4.12.0','Выход из мобильного приложения','{\"ip\":\"61.8.134.53\",\"user_agent\":\"okhttp\\/4.12.0\",\"method\":\"POST\",\"uri\":\"\\/api\\/mobile.php?action=logout\",\"token_hash_prefix\":\"468d7f04bd5f\"}'),
(23,1778479910702942,'2026-05-11 09:11:50.703347',2,'MOBILE_LOGIN','USER',2,'61.8.134.53','okhttp/4.12.0','Вход из мобильного приложения','{\"ip\":\"61.8.134.53\",\"user_agent\":\"okhttp\\/4.12.0\",\"method\":\"POST\",\"uri\":\"\\/api\\/mobile.php?action=login\",\"device_name\":\"motorola motorola edge 50 neo\",\"device_fingerprint\":\"969117b65b9b580f\"}'),
(24,1778480035300602,'2026-05-11 09:13:55.300905',2,'MOBILE_LOGOUT','USER',2,'61.8.134.53','okhttp/4.12.0','Выход из мобильного приложения','{\"ip\":\"61.8.134.53\",\"user_agent\":\"okhttp\\/4.12.0\",\"method\":\"POST\",\"uri\":\"\\/api\\/mobile.php?action=logout\",\"token_hash_prefix\":\"8d4c7ba3736d\"}'),
(25,1778480045888307,'2026-05-11 09:14:05.888589',1,'MOBILE_LOGIN','USER',1,'61.8.134.53','okhttp/4.12.0','Вход из мобильного приложения','{\"ip\":\"61.8.134.53\",\"user_agent\":\"okhttp\\/4.12.0\",\"method\":\"POST\",\"uri\":\"\\/api\\/mobile.php?action=login\",\"device_name\":\"motorola motorola edge 50 neo\",\"device_fingerprint\":\"969117b65b9b580f\"}'),
(26,1778481979739502,'2026-05-11 09:46:19.739809',1,'LOGOUT',NULL,NULL,'84.166.209.16','Mozilla/5.0 (X11; Linux x86_64; rv:145.0) Gecko/20100101 Firefox/145.0','Пользователь вышел из системы',NULL),
(27,1778481990291258,'2026-05-11 09:46:30.291459',1,'LOGIN',NULL,NULL,'84.166.209.16','Mozilla/5.0 (X11; Linux x86_64; rv:145.0) Gecko/20100101 Firefox/145.0','Пользователь вошёл в систему',NULL),
(28,1778482393832110,'2026-05-11 09:53:13.832467',1,'LOGOUT',NULL,NULL,'84.166.209.16','Mozilla/5.0 (X11; Linux x86_64; rv:145.0) Gecko/20100101 Firefox/145.0','Пользователь вышел из системы',NULL),
(29,1778482400762034,'2026-05-11 09:53:20.762254',1,'LOGIN',NULL,NULL,'84.166.209.16','Mozilla/5.0 (X11; Linux x86_64; rv:145.0) Gecko/20100101 Firefox/145.0','Пользователь вошёл в систему',NULL),
(30,1778483935507277,'2026-05-11 10:18:55.507695',1,'ORDER_CREATED','TOUR_ORDER',4,'84.166.209.16','Mozilla/5.0 (X11; Linux x86_64; rv:145.0) Gecko/20100101 Firefox/145.0','Создана заявка','{\"title\":\"ввввв\",\"address\":\"цувуц\",\"area_m2\":3333}'),
(31,1778483951185125,'2026-05-11 10:19:11.185485',1,'USER_UPDATED','USER',2,'84.166.209.16','Mozilla/5.0 (X11; Linux x86_64; rv:145.0) Gecko/20100101 Firefox/145.0','Обновлены роль/активность пользователя','{\"role\":\"OPERATOR\",\"is_active\":1}'),
(32,1778483969201626,'2026-05-11 10:19:29.201882',2,'LOGIN',NULL,NULL,'84.166.209.16','Mozilla/5.0 (X11; Linux x86_64; rv:145.0) Gecko/20100101 Firefox/145.0','Пользователь вошёл в систему',NULL),
(33,1778483980531043,'2026-05-11 10:19:40.532676',2,'ORDER_TAKEN','TOUR_ORDER',3,'84.166.209.16','Mozilla/5.0 (X11; Linux x86_64; rv:145.0) Gecko/20100101 Firefox/145.0','Оператор взял заявку в работу',NULL),
(34,1778484031247393,'2026-05-11 10:20:31.247701',1,'LOGIN',NULL,NULL,'84.166.209.16','Mozilla/5.0 (X11; Linux x86_64; rv:145.0) Gecko/20100101 Firefox/145.0','Пользователь вошёл в систему',NULL),
(35,1778486303632754,'2026-05-11 10:58:23.632882',1,'LOGIN',NULL,NULL,'84.166.209.16','Mozilla/5.0 (X11; Linux x86_64; rv:145.0) Gecko/20100101 Firefox/145.0','Пользователь вошёл в систему',NULL),
(36,1778486316169758,'2026-05-11 10:58:36.170222',1,'USER_UPDATED','USER',2,'84.166.209.16','Mozilla/5.0 (X11; Linux x86_64; rv:145.0) Gecko/20100101 Firefox/145.0','Обновлены роль/активность пользователя','{\"role\":\"BROKER\",\"is_active\":1}'),
(37,1778486318427737,'2026-05-11 10:58:38.428028',1,'USER_UPDATED','USER',2,'84.166.209.16','Mozilla/5.0 (X11; Linux x86_64; rv:145.0) Gecko/20100101 Firefox/145.0','Обновлены роль/активность пользователя','{\"role\":\"ADMIN\",\"is_active\":1}'),
(38,1778486321351703,'2026-05-11 10:58:41.351991',1,'USER_UPDATED','USER',2,'84.166.209.16','Mozilla/5.0 (X11; Linux x86_64; rv:145.0) Gecko/20100101 Firefox/145.0','Обновлены роль/активность пользователя','{\"role\":\"OPERATOR\",\"is_active\":1}'),
(39,1778486333545330,'2026-05-11 10:58:53.545803',1,'ORDER_CREATED','TOUR_ORDER',5,'84.166.209.16','Mozilla/5.0 (X11; Linux x86_64; rv:145.0) Gecko/20100101 Firefox/145.0','Создана заявка','{\"title\":\"12323\",\"address\":\"123\",\"area_m2\":111}'),
(40,1778486341304851,'2026-05-11 10:59:01.306646',1,'ORDER_TAKEN','TOUR_ORDER',5,'84.166.209.16','Mozilla/5.0 (X11; Linux x86_64; rv:145.0) Gecko/20100101 Firefox/145.0','Оператор взял заявку в работу',NULL),
(41,1778486360380040,'2026-05-11 10:59:20.380266',2,'LOGIN',NULL,NULL,'84.166.209.16','Mozilla/5.0 (X11; Linux x86_64; rv:145.0) Gecko/20100101 Firefox/145.0','Пользователь вошёл в систему',NULL),
(42,1778486370647079,'2026-05-11 10:59:30.647471',2,'ORDER_TAKEN','TOUR_ORDER',2,'84.166.209.16','Mozilla/5.0 (X11; Linux x86_64; rv:145.0) Gecko/20100101 Firefox/145.0','Оператор взял заявку в работу',NULL),
(43,1778486411505119,'2026-05-11 11:00:11.507178',2,'ORDER_CREATED','TOUR_ORDER',6,'84.166.209.16','Mozilla/5.0 (X11; Linux x86_64; rv:145.0) Gecko/20100101 Firefox/145.0','Создана заявка','{\"title\":\"oper\",\"address\":\"oper\",\"area_m2\":111}'),
(44,1778486608189222,'2026-05-11 11:03:28.189357',1,'LOGIN',NULL,NULL,'84.166.209.16','Mozilla/5.0 (X11; Linux x86_64; rv:145.0) Gecko/20100101 Firefox/145.0','Пользователь вошёл в систему',NULL),
(45,1778486923857603,'2026-05-11 11:08:43.857896',1,'MOBILE_APP_OPEN','USER',1,'61.8.134.6','okhttp/4.12.0','Открытие мобильного приложения','{\"ip\":\"61.8.134.6\",\"user_agent\":\"okhttp\\/4.12.0\",\"method\":\"POST\",\"uri\":\"\\/api\\/mobile.php?action=ping\"}'),
(46,1778488636070572,'2026-05-11 11:37:16.070848',1,'MOBILE_APP_OPEN','USER',1,'61.8.134.26','okhttp/4.12.0','Открытие мобильного приложения','{\"ip\":\"61.8.134.26\",\"user_agent\":\"okhttp\\/4.12.0\",\"method\":\"POST\",\"uri\":\"\\/api\\/mobile.php?action=ping\"}'),
(47,1778488780002370,'2026-05-11 11:39:40.002737',2,'LOGIN',NULL,NULL,'84.166.209.16','Mozilla/5.0 (X11; Linux x86_64; rv:145.0) Gecko/20100101 Firefox/145.0','Пользователь вошёл в систему',NULL),
(48,1778488802901304,'2026-05-11 11:40:02.901705',1,'ORDER_TAKEN','TOUR_ORDER',4,'61.8.134.26','okhttp/4.12.0','Заявка взята в работу',NULL),
(49,1778489280354985,'2026-05-11 11:48:00.355317',1,'MOBILE_APP_OPEN','USER',1,'61.8.128.89','okhttp/4.12.0','Открытие мобильного приложения','{\"ip\":\"61.8.128.89\",\"user_agent\":\"okhttp\\/4.12.0\",\"method\":\"POST\",\"uri\":\"\\/api\\/mobile.php?action=ping\"}'),
(50,1778489389325899,'2026-05-11 11:49:49.326230',1,'ORDER_CREATED','TOUR_ORDER',1,'84.166.209.16','Mozilla/5.0 (X11; Linux x86_64; rv:145.0) Gecko/20100101 Firefox/145.0','Создана заявка','{\"title\":\"админ тест\",\"address\":\"админский\",\"area_m2\":100}'),
(51,1778489429355985,'2026-05-11 11:50:29.357951',1,'ORDER_CREATED','TOUR_ORDER',2,'84.166.209.16','Mozilla/5.0 (X11; Linux x86_64; rv:145.0) Gecko/20100101 Firefox/145.0','Создана заявка','{\"title\":\"admin 02\",\"address\":\"adminskiy 02\",\"area_m2\":200}'),
(52,1778489472689338,'2026-05-11 11:51:12.689655',2,'ORDER_CREATED','TOUR_ORDER',3,'84.166.209.16','Mozilla/5.0 (X11; Linux x86_64; rv:145.0) Gecko/20100101 Firefox/145.0','Создана заявка','{\"title\":\"ilya\",\"address\":\"ilyamskiy\",\"area_m2\":300}'),
(53,1778489491392856,'2026-05-11 11:51:31.394997',2,'ORDER_CREATED','TOUR_ORDER',4,'84.166.209.16','Mozilla/5.0 (X11; Linux x86_64; rv:145.0) Gecko/20100101 Firefox/145.0','Создана заявка','{\"title\":\"ilya 02\",\"address\":\"iyamskiy 02\",\"area_m2\":400}'),
(54,1778490713560844,'2026-05-11 12:11:53.561067',1,'MOBILE_APP_OPEN','USER',1,'61.8.128.44','okhttp/4.12.0','Открытие мобильного приложения','{\"ip\":\"61.8.128.44\",\"user_agent\":\"okhttp\\/4.12.0\",\"method\":\"POST\",\"uri\":\"\\/api\\/mobile.php?action=ping\"}'),
(55,1778492478254697,'2026-05-11 12:41:18.255067',1,'MOBILE_APP_OPEN','USER',1,'61.8.128.5','okhttp/4.12.0','Открытие мобильного приложения','{\"ip\":\"61.8.128.5\",\"user_agent\":\"okhttp\\/4.12.0\",\"method\":\"POST\",\"uri\":\"\\/api\\/mobile.php?action=ping\"}'),
(56,1778493436305877,'2026-05-11 12:57:16.306375',1,'LOGIN',NULL,NULL,'84.166.209.16','Mozilla/5.0 (X11; Linux x86_64; rv:145.0) Gecko/20100101 Firefox/145.0','Пользователь вошёл в систему',NULL),
(57,1778493496456177,'2026-05-11 12:58:16.456639',1,'ORDER_UPDATED','TOUR_ORDER',2,'84.166.209.16','Mozilla/5.0 (X11; Linux x86_64; rv:145.0) Gecko/20100101 Firefox/145.0','Заявка обновлена',NULL),
(58,1778493515872238,'2026-05-11 12:58:35.872615',1,'ORDER_UPDATED','TOUR_ORDER',4,'84.166.209.16','Mozilla/5.0 (X11; Linux x86_64; rv:145.0) Gecko/20100101 Firefox/145.0','Заявка обновлена',NULL),
(59,1778493546491505,'2026-05-11 12:59:06.491779',2,'LOGIN',NULL,NULL,'84.166.209.16','Mozilla/5.0 (X11; Linux x86_64; rv:145.0) Gecko/20100101 Firefox/145.0','Пользователь вошёл в систему',NULL),
(60,1778493621313749,'2026-05-11 13:00:21.314018',2,'ORDER_UPDATED','TOUR_ORDER',4,'84.166.209.16','Mozilla/5.0 (X11; Linux x86_64; rv:145.0) Gecko/20100101 Firefox/145.0','Заявка обновлена',NULL),
(61,1778493846644001,'2026-05-11 13:04:06.644324',1,'MOBILE_APP_OPEN','USER',1,'61.8.134.17','okhttp/4.12.0','Открытие мобильного приложения','{\"ip\":\"61.8.134.17\",\"user_agent\":\"okhttp\\/4.12.0\",\"method\":\"POST\",\"uri\":\"\\/api\\/mobile.php?action=ping\"}'),
(62,1778494743126264,'2026-05-11 13:19:03.126535',2,'ORDER_UPDATED','TOUR_ORDER',3,'84.166.209.16','Mozilla/5.0 (X11; Linux x86_64; rv:145.0) Gecko/20100101 Firefox/145.0','Заявка обновлена',NULL),
(63,1778494761605980,'2026-05-11 13:19:21.606318',2,'ORDER_UPDATED','TOUR_ORDER',3,'84.166.209.16','Mozilla/5.0 (X11; Linux x86_64; rv:145.0) Gecko/20100101 Firefox/145.0','Заявка обновлена',NULL),
(64,1778494778079879,'2026-05-11 13:19:38.080234',2,'ORDER_UPDATED','TOUR_ORDER',4,'84.166.209.16','Mozilla/5.0 (X11; Linux x86_64; rv:145.0) Gecko/20100101 Firefox/145.0','Заявка обновлена',NULL),
(65,1778495514081837,'2026-05-11 13:31:54.082174',1,'MOBILE_APP_OPEN','USER',1,'61.8.134.58','okhttp/4.12.0','Открытие мобильного приложения','{\"ip\":\"61.8.134.58\",\"user_agent\":\"okhttp\\/4.12.0\",\"method\":\"POST\",\"uri\":\"\\/api\\/mobile.php?action=ping\"}'),
(66,1778495581743151,'2026-05-11 13:33:01.743594',1,'MOBILE_APP_OPEN','USER',1,'61.8.134.58','okhttp/4.12.0','Открытие мобильного приложения','{\"ip\":\"61.8.134.58\",\"user_agent\":\"okhttp\\/4.12.0\",\"method\":\"POST\",\"uri\":\"\\/api\\/mobile.php?action=ping\"}'),
(67,1778495623573855,'2026-05-11 13:33:43.574167',1,'MOBILE_APP_OPEN','USER',1,'61.8.134.58','okhttp/4.12.0','Открытие мобильного приложения','{\"ip\":\"61.8.134.58\",\"user_agent\":\"okhttp\\/4.12.0\",\"method\":\"POST\",\"uri\":\"\\/api\\/mobile.php?action=ping\"}'),
(68,1778495627860622,'2026-05-11 13:33:47.860880',1,'MOBILE_LOGOUT','USER',1,'61.8.134.58','okhttp/4.12.0','Выход из мобильного приложения','{\"ip\":\"61.8.134.58\",\"user_agent\":\"okhttp\\/4.12.0\",\"method\":\"POST\",\"uri\":\"\\/api\\/mobile.php?action=logout\",\"token_hash_prefix\":\"25cbc97bc62e\"}'),
(69,1778495638216246,'2026-05-11 13:33:58.216614',2,'MOBILE_LOGIN','USER',2,'61.8.134.58','okhttp/4.12.0','Вход из мобильного приложения','{\"ip\":\"61.8.134.58\",\"user_agent\":\"okhttp\\/4.12.0\",\"method\":\"POST\",\"uri\":\"\\/api\\/mobile.php?action=login\",\"device_name\":\"motorola motorola edge 50 neo\",\"device_fingerprint\":\"969117b65b9b580f\"}'),
(70,1778495712274362,'2026-05-11 13:35:12.274685',2,'MOBILE_APP_OPEN','USER',2,'61.8.134.58','okhttp/4.12.0','Открытие мобильного приложения','{\"ip\":\"61.8.134.58\",\"user_agent\":\"okhttp\\/4.12.0\",\"method\":\"POST\",\"uri\":\"\\/api\\/mobile.php?action=ping\"}'),
(71,1778497423547232,'2026-05-11 14:03:43.547643',2,'MOBILE_APP_OPEN','USER',2,'61.8.128.101','okhttp/4.12.0','Открытие мобильного приложения','{\"ip\":\"61.8.128.101\",\"user_agent\":\"okhttp\\/4.12.0\",\"method\":\"POST\",\"uri\":\"\\/api\\/mobile.php?action=ping\"}'),
(72,1778497472347700,'2026-05-11 14:04:32.347946',2,'MOBILE_APP_OPEN','USER',2,'61.8.128.101','okhttp/4.12.0','Открытие мобильного приложения','{\"ip\":\"61.8.128.101\",\"user_agent\":\"okhttp\\/4.12.0\",\"method\":\"POST\",\"uri\":\"\\/api\\/mobile.php?action=ping\"}'),
(73,1778497802946103,'2026-05-11 14:10:02.946378',2,'MOBILE_APP_OPEN','USER',2,'61.8.128.101','okhttp/4.12.0','Открытие мобильного приложения','{\"ip\":\"61.8.128.101\",\"user_agent\":\"okhttp\\/4.12.0\",\"method\":\"POST\",\"uri\":\"\\/api\\/mobile.php?action=ping\"}'),
(74,1778498262213023,'2026-05-11 14:17:42.213409',2,'ORDER_TAKEN','TOUR_ORDER',4,'61.8.128.8','okhttp/4.12.0','Заявка взята в работу',NULL),
(75,1778498363136641,'2026-05-11 14:19:23.136939',2,'MOBILE_APP_OPEN','USER',2,'61.8.128.8','okhttp/4.12.0','Открытие мобильного приложения','{\"ip\":\"61.8.128.8\",\"user_agent\":\"okhttp\\/4.12.0\",\"method\":\"POST\",\"uri\":\"\\/api\\/mobile.php?action=ping\"}'),
(76,1778498417892156,'2026-05-11 14:20:17.892581',2,'LOGIN',NULL,NULL,'84.166.209.16','Mozilla/5.0 (X11; Linux x86_64; rv:145.0) Gecko/20100101 Firefox/145.0','Пользователь вошёл в систему',NULL),
(77,1778498441848777,'2026-05-11 14:20:41.849024',2,'MOBILE_APP_OPEN','USER',2,'61.8.128.8','okhttp/4.12.0','Открытие мобильного приложения','{\"ip\":\"61.8.128.8\",\"user_agent\":\"okhttp\\/4.12.0\",\"method\":\"POST\",\"uri\":\"\\/api\\/mobile.php?action=ping\"}'),
(78,1778500202309188,'2026-05-11 14:50:02.309540',2,'MOBILE_APP_OPEN','USER',2,'61.8.128.47','okhttp/4.12.0','Открытие мобильного приложения','{\"ip\":\"61.8.128.47\",\"user_agent\":\"okhttp\\/4.12.0\",\"method\":\"POST\",\"uri\":\"\\/api\\/mobile.php?action=ping\"}');
/*!40000 ALTER TABLE `audit_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `capture_points`
--

DROP TABLE IF EXISTS `capture_points`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `capture_points` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `session_id` bigint(20) unsigned NOT NULL,
  `app_point_uuid` varchar(64) NOT NULL,
  `title` varchar(190) DEFAULT NULL,
  `room_name` varchar(190) DEFAULT NULL,
  `sequence_number` int(11) NOT NULL DEFAULT 0,
  `preview_path` varchar(500) DEFAULT NULL,
  `original_path` varchar(500) DEFAULT NULL,
  `upload_state` enum('LOCAL_ONLY','QUEUED','UPLOADING','UPLOADED','FAILED') NOT NULL DEFAULT 'LOCAL_ONLY',
  `created_at` datetime(6) NOT NULL DEFAULT current_timestamp(6),
  `updated_at` datetime(6) NOT NULL DEFAULT current_timestamp(6) ON UPDATE current_timestamp(6),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_capture_point_app_uuid` (`app_point_uuid`),
  KEY `idx_capture_points_session` (`session_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `capture_points`
--

LOCK TABLES `capture_points` WRITE;
/*!40000 ALTER TABLE `capture_points` DISABLE KEYS */;
/*!40000 ALTER TABLE `capture_points` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `capture_sessions`
--

DROP TABLE IF EXISTS `capture_sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `capture_sessions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `order_id` bigint(20) unsigned NOT NULL,
  `operator_id` bigint(20) unsigned NOT NULL,
  `app_session_uuid` varchar(64) NOT NULL,
  `camera_model` varchar(128) DEFAULT NULL,
  `status` enum('LOCAL_ONLY','CAPTURED','UPLOADING','UPLOADED','PROCESSING','READY','FAILED') NOT NULL DEFAULT 'LOCAL_ONLY',
  `started_at` datetime(6) DEFAULT NULL,
  `completed_at` datetime(6) DEFAULT NULL,
  `created_at` datetime(6) NOT NULL DEFAULT current_timestamp(6),
  `updated_at` datetime(6) NOT NULL DEFAULT current_timestamp(6) ON UPDATE current_timestamp(6),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_capture_session_app_uuid` (`app_session_uuid`),
  KEY `idx_capture_sessions_order` (`order_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `capture_sessions`
--

LOCK TABLES `capture_sessions` WRITE;
/*!40000 ALTER TABLE `capture_sessions` DISABLE KEYS */;
INSERT INTO `capture_sessions` VALUES
(1,1,1,'test-session-001','Insta360 X4','CAPTURED','2026-05-10 16:44:48.869484',NULL,'2026-05-10 16:44:48.869484','2026-05-10 16:45:44.326718');
/*!40000 ALTER TABLE `capture_sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `form_tokens`
--

DROP TABLE IF EXISTS `form_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `form_tokens` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `token` char(64) NOT NULL,
  `form_name` varchar(64) NOT NULL,
  `is_used` tinyint(1) NOT NULL DEFAULT 0,
  `used_at` datetime(6) DEFAULT NULL,
  `expires_at` datetime(6) NOT NULL,
  `created_at` datetime(6) NOT NULL DEFAULT current_timestamp(6),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_form_token` (`token`),
  KEY `idx_form_tokens_user_form` (`user_id`,`form_name`),
  KEY `idx_form_tokens_expires` (`expires_at`)
) ENGINE=InnoDB AUTO_INCREMENT=66 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `form_tokens`
--

LOCK TABLES `form_tokens` WRITE;
/*!40000 ALTER TABLE `form_tokens` DISABLE KEYS */;
INSERT INTO `form_tokens` VALUES
(1,1,'70e39c97619720617c27858239263787ea88438e93038a65272420ca7682742f','create_order',0,NULL,'2026-05-11 10:48:26.744921','2026-05-11 10:18:26.744921'),
(2,1,'bb7f3708e067321de456b52fa1337cafc2f646bf0df28739874c4c6f00e5ce75','create_order',0,NULL,'2026-05-11 10:48:34.658302','2026-05-11 10:18:34.658302'),
(3,1,'d0f7b88a462d2bff1037197f1733dd099b12c045b3f6b1af9e3991854ee73706','create_order',1,'2026-05-11 10:18:55.503335','2026-05-11 10:48:39.110331','2026-05-11 10:18:39.110331'),
(4,1,'53604655fdc436b64576f9e2d8b68dcec707d6f3a59b44fb04b156573f24ab1f','create_order',0,NULL,'2026-05-11 10:48:55.535303','2026-05-11 10:18:55.535303'),
(5,1,'171b0e07d4604d8203d5636f6576092c8d42e4737041ac5fe3fefbc4fe908ae2','create_order',0,NULL,'2026-05-11 10:49:00.330561','2026-05-11 10:19:00.330561'),
(6,2,'e4d53434d2b75826c9aa53b4514c9bfe2d8cd80e785a421f9df09625ffded036','create_order',0,NULL,'2026-05-11 10:49:32.694566','2026-05-11 10:19:32.694566'),
(7,2,'e36ffba3a473a8f4a0b0cef627df9b497fa47253b0c138bbbdbd1d004b747c7f','create_order',0,NULL,'2026-05-11 10:49:45.257856','2026-05-11 10:19:45.257856'),
(8,1,'1a8dc9ace72f72656cb0def4750899e86707ea358f79f40659a0b9c6d7fad34b','create_order',0,NULL,'2026-05-11 11:28:27.129675','2026-05-11 10:58:27.129675'),
(9,1,'a95be7055096e7f52e947c0e2e68b831611ee87aba22d957bfa5ca0f66f06235','create_order',1,'2026-05-11 10:58:53.542038','2026-05-11 11:28:49.801959','2026-05-11 10:58:49.801959'),
(10,1,'1d9bd1914dfa191e35d0dfe27a1c187072999da2fbfb73ff4147c7f6b6721418','create_order',0,NULL,'2026-05-11 11:28:53.572974','2026-05-11 10:58:53.572974'),
(11,2,'2d98338572ea4af0afb9d46d354c0a9908f7be5393ee4c8ee97378fdcbf5d58b','create_order',0,NULL,'2026-05-11 11:29:23.455463','2026-05-11 10:59:23.455463'),
(12,2,'d280b32ec2f86e110763983dcbe4e27a10f3cdb17fab9a3fe76a417e6ebf8ddc','create_order',0,NULL,'2026-05-11 11:29:26.951611','2026-05-11 10:59:26.951611'),
(13,2,'59ced9aa724bfdd5cb25f2e69ae075fa1285db0b1834433668ac071ba2236f21','create_order',0,NULL,'2026-05-11 11:29:53.561637','2026-05-11 10:59:53.561637'),
(14,2,'fe0364a87bf5d997bf44b272abab54784daa8e60924ede4a8ee8394e56963f08','create_order',1,'2026-05-11 11:00:11.461205','2026-05-11 11:29:59.392220','2026-05-11 10:59:59.392220'),
(15,2,'ba71c7f2c74165cb700876eb831e72ee505efde126637affe1f3da12bc399261','create_order',0,NULL,'2026-05-11 11:30:11.536377','2026-05-11 11:00:11.536377'),
(16,2,'cb19e1cf28ed57db5ccfb23768297b5f4e96daa380110029d0d968a917552c7e','create_order',0,NULL,'2026-05-11 11:30:13.757356','2026-05-11 11:00:13.757356'),
(17,2,'711e72788d0adcdeb9eb86d068858740869bc5b118aa682146816dcd79dd6869','create_order',0,NULL,'2026-05-11 11:30:19.580552','2026-05-11 11:00:19.580552'),
(18,2,'b80573a687f5fc7d9b78f17c6d6832b672d9847217f0ef395980d3c6b63d79cd','create_order',0,NULL,'2026-05-11 11:33:13.835913','2026-05-11 11:03:13.835913'),
(19,2,'31d21d2668662013036ddf13a7b1a402e05e9237356495fafd53c08b37b2c3bb','create_order',0,NULL,'2026-05-11 11:33:16.511969','2026-05-11 11:03:16.511969'),
(20,2,'4a0af1255a97fcb688fdb1cef8711be1953e8f6945b60dd261af4384b4c7cd1c','create_order',0,NULL,'2026-05-11 11:33:19.569949','2026-05-11 11:03:19.569949'),
(21,1,'fe0d5cc50a25fff068765a1916c6f569dcdbef667dfcfa7de47e6f8267cf8559','create_order',0,NULL,'2026-05-11 11:33:30.403187','2026-05-11 11:03:30.403187'),
(22,1,'3dd9bc9460f23eef2642ea32db228c34dc5e43650178d0e873111af24364499a','create_order',0,NULL,'2026-05-11 11:50:55.817247','2026-05-11 11:20:55.817247'),
(23,1,'aa04cf623791f7c16650a997d3c8d94cd0c499a15a5adb49cbe4d04d142354e4','create_order',0,NULL,'2026-05-11 11:51:28.873644','2026-05-11 11:21:28.873644'),
(24,1,'eb8ce33287c20c4fff474b209c514d078aea65703deb90c90cd78b8577207d6b','create_order',0,NULL,'2026-05-11 12:03:30.451218','2026-05-11 11:33:30.451218'),
(25,1,'e3a7fb0a57c912385d358635c4e79fdb0a544cf386def9f6581eb02b2610f9d7','create_order',0,NULL,'2026-05-11 12:03:32.012810','2026-05-11 11:33:32.012810'),
(26,1,'1c7d3ca84a7d06036f78c6f3db61852d2c9e8b20816aeb3b8841598d60f18c15','create_order',0,NULL,'2026-05-11 12:03:53.794214','2026-05-11 11:33:53.794214'),
(27,2,'cd18a2e8946f49f9279475e6973b5bae8de7e072001ff79d41006e5afb637c56','create_order',0,NULL,'2026-05-11 12:09:41.726443','2026-05-11 11:39:41.726443'),
(28,2,'3fac7e3d4055a13c3fc459318e74e18b6a87477544fd1d6f41dcd455f9680924','create_order',0,NULL,'2026-05-11 12:10:19.107012','2026-05-11 11:40:19.107012'),
(29,2,'6cd2842ef8e38dd300017a57e7545b5a4a2a990f8fc628d3e1bb95554f64b4e8','create_order',0,NULL,'2026-05-11 12:10:40.572051','2026-05-11 11:40:40.572051'),
(30,2,'9eca51598ec3a62a285382fe05ad06d0c61fd55c93273faa52002685e38917a8','create_order',0,NULL,'2026-05-11 12:16:11.013727','2026-05-11 11:46:11.013727'),
(31,2,'a5a3014e9359884c6ca02bd0460f2a3495564ab3179e5e8aade983995b8f08c4','create_order',0,NULL,'2026-05-11 12:16:28.263348','2026-05-11 11:46:28.263348'),
(32,2,'719662fa8d295669ae27b1ea048471eb881b4aafb5b5aeeef8e464c1a5076905','create_order',0,NULL,'2026-05-11 12:16:32.286150','2026-05-11 11:46:32.286150'),
(33,1,'6c39a9222f3ae224bca73feb6c367dffaceed556abd37f031e48da1d6e88a8c4','create_order',1,'2026-05-11 11:49:49.322877','2026-05-11 12:19:26.709710','2026-05-11 11:49:26.709710'),
(34,1,'068409b06082c9260f5d493ec0ebc3b6cc718f39cac2902daf4156ab7b61bd5f','create_order',1,'2026-05-11 11:50:29.330789','2026-05-11 12:19:49.354909','2026-05-11 11:49:49.354909'),
(35,2,'67fdd026cd31fd873ade50e6fb625f8d73c4f07b45a416252e0b902cc74db01a','create_order',0,NULL,'2026-05-11 12:19:56.135742','2026-05-11 11:49:56.135742'),
(36,2,'1f371f4b4c81d4ed6a58acb02eb7daaaf98c875f744d261846460f732c8ed7db','create_order',0,NULL,'2026-05-11 12:19:58.204169','2026-05-11 11:49:58.204169'),
(37,2,'309ad7aa37146af051c2be6072c2172f9cba1df62397db88fb85fa56755c2466','create_order',1,'2026-05-11 11:51:12.686531','2026-05-11 12:20:01.754696','2026-05-11 11:50:01.754696'),
(38,1,'c73d16c1ad94d78f0589fa9183ca4a9a187746ae6032eda51a4fbe119dce76d2','create_order',0,NULL,'2026-05-11 12:20:29.395784','2026-05-11 11:50:29.395784'),
(39,1,'02069ddaa520c21e27b6a0b976fea711de32d89f1e06d9a0e5f5e3ba9537fc51','create_order',0,NULL,'2026-05-11 12:20:39.814126','2026-05-11 11:50:39.814126'),
(40,2,'49b236b49ffb1359faa715f7bd92e20552d6cfcd9bb17e88c6e53862817fbdd1','create_order',1,'2026-05-11 11:51:31.388478','2026-05-11 12:21:12.719419','2026-05-11 11:51:12.719419'),
(41,2,'e2c9d2bd3c1aa71df93304907ae92a420fc64118e361d985f3e9c2410046bb57','create_order',0,NULL,'2026-05-11 12:21:31.421720','2026-05-11 11:51:31.421720'),
(42,2,'07be86f9d5a4081b5007b0e26436ef739058507bf0a0fb1e31f6ca069b575554','create_order',0,NULL,'2026-05-11 12:21:36.076399','2026-05-11 11:51:36.076399'),
(43,2,'625c0807c9c565fd0a5e0632e78cab0957da0475db2c1080fd0ed0b057e3cebe','create_order',0,NULL,'2026-05-11 12:25:19.246969','2026-05-11 11:55:19.246969'),
(44,1,'5f7f8d44fdc0debb37c238ac027b3201b8362b4c20816fca42b6cf0deb81d0cd','create_order',0,NULL,'2026-05-11 12:48:25.707832','2026-05-11 12:18:25.707832'),
(45,1,'362ca6e15943f87fdef3317088c49254765f44859220dc90b53972071d01c46d','create_order',0,NULL,'2026-05-11 13:27:54.279913','2026-05-11 12:57:54.279913'),
(46,1,'826ee190120d6002beae5e87174ffbb5f57970f138949145603e1429b33248d4','create_order',0,NULL,'2026-05-11 13:28:09.246035','2026-05-11 12:58:09.246035'),
(47,1,'871d152b0143ae2842053f5d12e5b66bc1231f96fbb44313fa0593709bc8a99c','create_order',0,NULL,'2026-05-11 13:28:27.380566','2026-05-11 12:58:27.380566'),
(48,1,'c16960ae7f95f202784a414e8591ff03153e1beb399e7dcf3d81fd62d0030ab7','create_order',0,NULL,'2026-05-11 13:28:37.959039','2026-05-11 12:58:37.959039'),
(49,1,'e5f58009f2d7c4ab718737e8416ecdadcdb2421f9d5e8d83eeb2f312a60828a2','create_order',0,NULL,'2026-05-11 13:29:33.237348','2026-05-11 12:59:33.237348'),
(50,1,'35c63d1aa374cf4f4302f96cf69d9c708b9f03d1711928b513285ff0f489ed22','create_order',0,NULL,'2026-05-11 13:42:38.040621','2026-05-11 13:12:38.040621'),
(51,2,'56e0db8ea8250c6212b7ab4a47ba6459e1e9423963d285c5940239b2e84a51e4','create_order',0,NULL,'2026-05-11 13:42:42.486034','2026-05-11 13:12:42.486034'),
(52,2,'6bfe37caa3a41124a7d677d50a8201468cf0121f66f848703ad026393f788b64','create_order',0,NULL,'2026-05-11 13:42:50.878303','2026-05-11 13:12:50.878303'),
(53,2,'82c6b9a15943a0a3732e4a74e7cc567fad2bf1f09cc24551f95fd6076c4181ef','create_order',0,NULL,'2026-05-11 13:42:52.836850','2026-05-11 13:12:52.836850'),
(54,2,'7b766fe2085d8b5beaa062e72dae5a71d24e9fa6324b877e9e4f2ede83ec7a2f','create_order',0,NULL,'2026-05-11 13:43:05.459457','2026-05-11 13:13:05.459457'),
(55,2,'8c394190c9df13c1b6f7506620aa42e0275aafe92a763420966e9804d5002013','create_order',0,NULL,'2026-05-11 13:43:19.288015','2026-05-11 13:13:19.288015'),
(56,1,'be02bad87d57cb275c23076ef7888a7ace110d1072fa9e04bad898d8f73edc5d','create_order',0,NULL,'2026-05-11 13:43:20.938531','2026-05-11 13:13:20.938531'),
(57,2,'baceae95ab427e7bb4e054f3ec86ca6948032889fb22a3d1476e9894fb0fe2ea','create_order',0,NULL,'2026-05-11 13:43:49.914599','2026-05-11 13:13:49.914599'),
(58,2,'d07bc23a1a03efcb417a4532f2309d596dfbc610331b24448278623ee7e9c6cb','create_order',0,NULL,'2026-05-11 13:48:47.016550','2026-05-11 13:18:47.016550'),
(59,2,'0c0de6755bb7cb49f39bd732002bd17d0febd4aa4abb4148583d3bdff247bbed','create_order',0,NULL,'2026-05-11 13:48:58.165879','2026-05-11 13:18:58.165879'),
(60,2,'5368b05dd358f8bcf489d094c8b88e193440ee06e7d3a54299d72c531a281125','create_order',0,NULL,'2026-05-11 13:49:06.764003','2026-05-11 13:19:06.764003'),
(61,2,'64f02988cfc86e55a02e83281e5b4fede8988be5fb9c7678c88bde994be8bfa7','create_order',0,NULL,'2026-05-11 13:49:29.543809','2026-05-11 13:19:29.543809'),
(62,2,'c4a58da6cf36fc3dc5f1c4846f585a8787d82eced4cb65539714f6ed6a296598','create_order',0,NULL,'2026-05-11 13:49:33.529416','2026-05-11 13:19:33.529416'),
(63,1,'2f594f798a4bd647dbd3ea458136849b01f5f30f89662a4f257872d78e6956d5','create_order',0,NULL,'2026-05-11 14:06:01.483892','2026-05-11 13:36:01.483892'),
(64,2,'d9c009731e6ed70c3224d8e931a3b5fd5163c6509e8f8ecb19175a5e5b902842','create_order',0,NULL,'2026-05-11 14:06:13.147790','2026-05-11 13:36:13.147790'),
(65,2,'dfb348e52f8cb20c31e111d2667010e1e4c06bd3628000f830eaf4286dc6ed5e','create_order',0,NULL,'2026-05-11 14:50:19.490832','2026-05-11 14:20:19.490832');
/*!40000 ALTER TABLE `form_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `menu_groups`
--

DROP TABLE IF EXISTS `menu_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `menu_groups` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(64) NOT NULL,
  `title` varchar(128) NOT NULL,
  `icon` varchar(64) DEFAULT NULL,
  `sort_order` int(11) NOT NULL DEFAULT 100,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_menu_groups_code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `menu_groups`
--

LOCK TABLES `menu_groups` WRITE;
/*!40000 ALTER TABLE `menu_groups` DISABLE KEYS */;
INSERT INTO `menu_groups` VALUES
(1,'main','MaklerTour','bi bi-house',10,1),
(2,'admin','Admin','bi bi-gear',90,1);
/*!40000 ALTER TABLE `menu_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `menu_items`
--

DROP TABLE IF EXISTS `menu_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `menu_items` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `group_code` varchar(64) NOT NULL,
  `menu_key` varchar(128) NOT NULL,
  `title` varchar(128) NOT NULL,
  `icon` varchar(64) DEFAULT NULL,
  `action` varchar(128) DEFAULT NULL,
  `url` varchar(255) DEFAULT NULL,
  `sort_order` int(11) NOT NULL DEFAULT 100,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_menu_items_key` (`menu_key`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `menu_items`
--

LOCK TABLES `menu_items` WRITE;
/*!40000 ALTER TABLE `menu_items` DISABLE KEYS */;
INSERT INTO `menu_items` VALUES
(1,'main','orders','Заявки','bi bi-list-task','view_orders','/orders.php',10,1),
(2,'main','operator_orders','Рынок заявок','bi bi-camera-video','view_market','/market.php',20,1),
(3,'admin','users','Пользователи','bi bi-people','view_users','/main.php?page=users',10,1),
(4,'admin','audit','Аудит','bi bi-clock-history','view_audit','/audit.php',20,1);
/*!40000 ALTER TABLE `menu_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mobile_tokens`
--

DROP TABLE IF EXISTS `mobile_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mobile_tokens` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `token_hash` char(64) NOT NULL,
  `device_name` varchar(190) DEFAULT NULL,
  `device_fingerprint` varchar(190) DEFAULT NULL,
  `expires_at` datetime(6) DEFAULT NULL,
  `last_used_at` datetime(6) DEFAULT NULL,
  `created_at` datetime(6) NOT NULL DEFAULT current_timestamp(6),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_mobile_token_hash` (`token_hash`),
  KEY `idx_mobile_tokens_user` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mobile_tokens`
--

LOCK TABLES `mobile_tokens` WRITE;
/*!40000 ALTER TABLE `mobile_tokens` DISABLE KEYS */;
INSERT INTO `mobile_tokens` VALUES
(1,1,'a1e7033e201976eca08a2e9d10f1b9021abf034891be2fc6eee043d3ef9523d3','test-phone','test-device-001','2026-08-08 16:43:04.740160','2026-05-10 17:24:01.321757','2026-05-10 16:43:04.740160'),
(2,1,'340adb5ef6fcf4ff3a7cf0bc21bb5f18db4cf7e6b6e63bcba477db603aa69751','test-phone','test-device-001','2026-08-08 18:50:33.606617',NULL,'2026-05-10 18:50:33.606617'),
(5,1,'62d8d2eebbd744a6e6e3737cb957b677a4fe3a3cfd5ccb536796f7e9124d28e5','curl-test','curl-test-001','2026-08-09 08:28:22.278118','2026-05-11 08:28:31.730456','2026-05-11 08:28:22.278118'),
(8,2,'5a41ba452bfb474926ff1291a8c700b1eb446728ec103cacbd6d7750f36b8116','motorola motorola edge 50 neo','969117b65b9b580f','2026-08-09 13:33:58.214948','2026-05-11 14:50:04.602413','2026-05-11 13:33:58.214948');
/*!40000 ALTER TABLE `mobile_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `role_menu`
--

DROP TABLE IF EXISTS `role_menu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `role_menu` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `role_code` varchar(32) NOT NULL,
  `menu_key` varchar(128) NOT NULL,
  `is_allowed` tinyint(1) NOT NULL DEFAULT 1,
  `can_view` tinyint(1) NOT NULL DEFAULT 1,
  `can_edit` tinyint(1) NOT NULL DEFAULT 0,
  `can_delete` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_role_menu` (`role_code`,`menu_key`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `role_menu`
--

LOCK TABLES `role_menu` WRITE;
/*!40000 ALTER TABLE `role_menu` DISABLE KEYS */;
INSERT INTO `role_menu` VALUES
(1,'ADMIN','orders',1,1,1,1),
(2,'ADMIN','operator_orders',1,1,1,1),
(3,'ADMIN','users',1,1,1,1),
(4,'BROKER','orders',1,1,1,0),
(5,'OPERATOR','operator_orders',1,1,1,0),
(6,'ADMIN','audit',1,1,0,0);
/*!40000 ALTER TABLE `role_menu` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `role_permissions`
--

DROP TABLE IF EXISTS `role_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `role_permissions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `role_code` varchar(32) NOT NULL,
  `permission_code` varchar(128) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_role_permission` (`role_code`,`permission_code`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `role_permissions`
--

LOCK TABLES `role_permissions` WRITE;
/*!40000 ALTER TABLE `role_permissions` DISABLE KEYS */;
INSERT INTO `role_permissions` VALUES
(1,'ADMIN','*'),
(6,'ADMIN','audit.view'),
(2,'BROKER','orders.create'),
(3,'BROKER','orders.view_own'),
(4,'OPERATOR','orders.take'),
(5,'OPERATOR','orders.upload');
/*!40000 ALTER TABLE `role_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tour_orders`
--

DROP TABLE IF EXISTS `tour_orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tour_orders` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `broker_id` bigint(20) unsigned NOT NULL,
  `operator_id` bigint(20) unsigned DEFAULT NULL,
  `title` varchar(190) NOT NULL,
  `address` text NOT NULL,
  `area_m2` decimal(10,2) DEFAULT NULL,
  `customer_name` varchar(190) DEFAULT NULL,
  `customer_phone` varchar(64) DEFAULT NULL,
  `customer_email` varchar(190) DEFAULT NULL,
  `status` enum('NEW','ASSIGNED','IN_PROGRESS','CAPTURED','UPLOADING','UPLOADED','PROCESSING','READY','CANCELLED') NOT NULL DEFAULT 'NEW',
  `is_published` tinyint(1) NOT NULL DEFAULT 0,
  `public_token` varchar(64) DEFAULT NULL,
  `created_at` datetime(6) NOT NULL DEFAULT current_timestamp(6),
  `updated_at` datetime(6) NOT NULL DEFAULT current_timestamp(6) ON UPDATE current_timestamp(6),
  `closed_at` datetime(6) DEFAULT NULL,
  `closed_by` bigint(20) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_tour_orders_public_token` (`public_token`),
  KEY `idx_tour_orders_broker` (`broker_id`),
  KEY `idx_tour_orders_operator` (`operator_id`),
  KEY `idx_tour_orders_status` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tour_orders`
--

LOCK TABLES `tour_orders` WRITE;
/*!40000 ALTER TABLE `tour_orders` DISABLE KEYS */;
INSERT INTO `tour_orders` VALUES
(1,1,NULL,'админ тест','админский',100.00,'админ','01','01@gmail.com','NEW',0,'1a84c8982edefaca4b3defa1a865d935','2026-05-11 11:49:49.324797','2026-05-11 11:49:49.324797',NULL,NULL),
(2,1,NULL,'admin 02','adminskiy 02',200.00,'admin 02','02','02@gmail.com','NEW',1,'3ae4780ab1c380868b253bb95258e500','2026-05-11 11:50:29.354555','2026-05-11 12:58:16.454667',NULL,NULL),
(3,2,NULL,'ilya','ilyamskiy',300.00,'ilya','03','03@gmail.com','NEW',0,'ba5ee8cdc37ced726d5a7e4fc3dd723a','2026-05-11 11:51:12.688328','2026-05-11 13:19:21.604710',NULL,NULL),
(4,2,2,'ilya 02','iyamskiy 02',400.00,'02','02','04@gmail.com','ASSIGNED',1,'f06937cdbdadca3c59614082582d0af6','2026-05-11 11:51:31.391885','2026-05-11 14:17:42.193139',NULL,NULL);
/*!40000 ALTER TABLE `tour_orders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `uploads`
--

DROP TABLE IF EXISTS `uploads`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `uploads` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `order_id` bigint(20) unsigned DEFAULT NULL,
  `session_id` bigint(20) unsigned DEFAULT NULL,
  `entity_type` enum('POINT_PREVIEW','POINT_ORIGINAL','VIDEO_SCAN') NOT NULL,
  `entity_id` bigint(20) unsigned DEFAULT NULL,
  `original_filename` varchar(255) NOT NULL,
  `storage_path` varchar(500) DEFAULT NULL,
  `mime_type` varchar(128) DEFAULT NULL,
  `size_bytes` bigint(20) unsigned DEFAULT NULL,
  `sha256` char(64) DEFAULT NULL,
  `state` enum('INIT','UPLOADING','COMPLETED','FAILED') NOT NULL DEFAULT 'INIT',
  `created_at` datetime(6) NOT NULL DEFAULT current_timestamp(6),
  `completed_at` datetime(6) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_uploads_user` (`user_id`),
  KEY `idx_uploads_order` (`order_id`),
  KEY `idx_uploads_session` (`session_id`),
  KEY `idx_uploads_state` (`state`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `uploads`
--

LOCK TABLES `uploads` WRITE;
/*!40000 ALTER TABLE `uploads` DISABLE KEYS */;
/*!40000 ALTER TABLE `uploads` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(64) NOT NULL,
  `email` varchar(190) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `full_name` varchar(190) DEFAULT NULL,
  `phone` varchar(64) DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `role` enum('ADMIN','BROKER','OPERATOR','CLIENT') NOT NULL DEFAULT 'BROKER',
  `ui_lang` varchar(8) NOT NULL DEFAULT 'ru',
  `ui_settings` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`ui_settings`)),
  `last_login_at` datetime(6) DEFAULT NULL,
  `login_count` int(10) unsigned NOT NULL DEFAULT 0,
  `last_login_ip` varchar(64) DEFAULT NULL,
  `last_user_agent` text DEFAULT NULL,
  `created_at` datetime(6) NOT NULL DEFAULT current_timestamp(6),
  `updated_at` datetime(6) NOT NULL DEFAULT current_timestamp(6) ON UPDATE current_timestamp(6),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_users_username` (`username`),
  UNIQUE KEY `uq_users_email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES
(1,'admin','admin@maklertour.local','$2b$10$wgYcHFsY3HFOwEdfKtKaPOmosiZnMeCL5bERqgSwIQtrCyEg4c2yW','Administrator',NULL,1,'ADMIN','ru',NULL,'2026-05-11 12:57:16.213589',8,'84.166.209.16','Mozilla/5.0 (X11; Linux x86_64; rv:145.0) Gecko/20100101 Firefox/145.0','2026-05-10 12:56:12.748785','2026-05-11 12:57:16.213589'),
(2,'ilya.chykalov@cargocells.com','ilya.chykalov@cargocells.com','$2y$10$Bzj.QidkppPdySgLGZnYIuvVDKjNnG7xM5EZifJRdU3ipThRVQVRa','myself',NULL,1,'OPERATOR','ru',NULL,'2026-05-11 14:20:17.888722',7,'84.166.209.16','Mozilla/5.0 (X11; Linux x86_64; rv:145.0) Gecko/20100101 Firefox/145.0','2026-05-10 17:52:34.220151','2026-05-11 14:20:17.888722');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `video_scans`
--

DROP TABLE IF EXISTS `video_scans`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `video_scans` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `session_id` bigint(20) unsigned NOT NULL,
  `app_scan_uuid` varchar(64) NOT NULL,
  `filename` varchar(255) NOT NULL,
  `local_camera_url` text DEFAULT NULL,
  `storage_path` varchar(500) DEFAULT NULL,
  `size_bytes` bigint(20) unsigned DEFAULT NULL,
  `duration_sec` int(11) DEFAULT NULL,
  `upload_state` enum('LOCAL_ONLY','QUEUED','UPLOADING','UPLOADED','FAILED') NOT NULL DEFAULT 'LOCAL_ONLY',
  `processing_state` enum('NOT_STARTED','PROCESSING','DONE','FAILED') NOT NULL DEFAULT 'NOT_STARTED',
  `created_at` datetime(6) NOT NULL DEFAULT current_timestamp(6),
  `updated_at` datetime(6) NOT NULL DEFAULT current_timestamp(6) ON UPDATE current_timestamp(6),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_video_scan_app_uuid` (`app_scan_uuid`),
  KEY `idx_video_scans_session` (`session_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `video_scans`
--

LOCK TABLES `video_scans` WRITE;
/*!40000 ALTER TABLE `video_scans` DISABLE KEYS */;
INSERT INTO `video_scans` VALUES
(1,1,'test-scan-001','test-scan-001_test.mp4','http://192.168.42.1:80/DCIM/Camera01/test.mp4','orders/1/sessions/test-session-001/videos/test-scan-001_test.mp4',4069115,1,'UPLOADED','NOT_STARTED','2026-05-10 17:17:46.570740','2026-05-10 17:24:01.334015');
/*!40000 ALTER TABLE `video_scans` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'maklertour'
--

--
-- Dumping routines for database 'maklertour'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-05-11 15:15:00
