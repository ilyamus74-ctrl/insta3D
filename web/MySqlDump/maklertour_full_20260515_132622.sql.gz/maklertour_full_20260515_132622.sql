/*!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19  Distrib 10.11.8-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: maklertour
-- ------------------------------------------------------
-- Server version	10.11.8-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `audit_logs`
--

DROP TABLE IF EXISTS `audit_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `audit_logs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uid_created` bigint(20) unsigned DEFAULT NULL,
  `event_time` datetime(6) NOT NULL DEFAULT current_timestamp(6),
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `event_type` varchar(64) NOT NULL,
  `entity_type` varchar(64) DEFAULT NULL,
  `entity_id` bigint(20) unsigned DEFAULT NULL,
  `ip_address` varchar(64) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `description` text DEFAULT NULL,
  `extra_data` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`extra_data`)),
  PRIMARY KEY (`id`),
  KEY `idx_audit_user` (`user_id`),
  KEY `idx_audit_event_time` (`event_time`)
) ENGINE=InnoDB AUTO_INCREMENT=178 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `audit_logs`
--

LOCK TABLES `audit_logs` WRITE;
/*!40000 ALTER TABLE `audit_logs` DISABLE KEYS */;
INSERT INTO `audit_logs` VALUES
(1,1778418301678120,'2026-05-10 16:05:01.678308',1,'LOGIN',NULL,NULL,'84.166.209.16','Mozilla/5.0 (X11; Linux x86_64; rv:145.0) Gecko/20100101 Firefox/145.0','Пользователь вошёл в систему',NULL),
(2,1778424800384035,'2026-05-10 17:53:20.384349',2,'LOGIN',NULL,NULL,'84.166.209.16','Mozilla/5.0 (X11; Linux x86_64; rv:145.0) Gecko/20100101 Firefox/145.0','Пользователь вошёл в систему',NULL),
(3,1778428233754396,'2026-05-10 18:50:33.754913',1,'MOBILE_LOGIN','USER',1,'84.166.209.16','curl/8.9.1','Вход из мобильного приложения','{\"device_name\":\"test-phone\",\"device_fingerprint\":\"test-device-001\",\"ip\":\"84.166.209.16\",\"user_agent\":\"curl\\/8.9.1\"}'),
(4,1778445158217607,'2026-05-10 23:32:38.217884',NULL,'MOBILE_TOKEN_INVALID','MOBILE_TOKEN',NULL,'61.8.134.50','okhttp/4.12.0','Невалидный мобильный token','{\"ip\":\"61.8.134.50\",\"user_agent\":\"okhttp\\/4.12.0\",\"method\":\"POST\",\"uri\":\"\\/api\\/mobile.php?action=ping\",\"reason\":\"token_not_found_or_expired\",\"token_hash_prefix\":\"2987862d7b69\"}'),
(5,1778445163205994,'2026-05-10 23:32:43.206516',NULL,'MOBILE_LOGIN_FAILED','USER',NULL,'61.8.134.50','okhttp/4.12.0','Неудачный вход в мобильное приложение','{\"ip\":\"61.8.134.50\",\"user_agent\":\"okhttp\\/4.12.0\",\"method\":\"POST\",\"uri\":\"\\/api\\/mobile.php?action=login\",\"username\":\"vggf\",\"device_name\":\"motorola motorola edge 50 neo\",\"device_fingerprint\":\"969117b65b9b580f\",\"reason\":\"user_not_found\"}'),
(6,1778445194337183,'2026-05-10 23:33:14.337309',2,'MOBILE_LOGIN','USER',2,'61.8.134.50','okhttp/4.12.0','Вход из мобильного приложения','{\"ip\":\"61.8.134.50\",\"user_agent\":\"okhttp\\/4.12.0\",\"method\":\"POST\",\"uri\":\"\\/api\\/mobile.php?action=login\",\"device_name\":\"motorola motorola edge 50 neo\",\"device_fingerprint\":\"969117b65b9b580f\"}'),
(7,1778445205080724,'2026-05-10 23:33:25.080978',2,'MOBILE_APP_OPEN','USER',2,'61.8.134.50','okhttp/4.12.0','Открытие мобильного приложения','{\"ip\":\"61.8.134.50\",\"user_agent\":\"okhttp\\/4.12.0\",\"method\":\"POST\",\"uri\":\"\\/api\\/mobile.php?action=ping\"}'),
(8,1778448041049006,'2026-05-11 00:20:41.049316',2,'MOBILE_APP_OPEN','USER',2,'61.8.134.41','okhttp/4.12.0','Открытие мобильного приложения','{\"ip\":\"61.8.134.41\",\"user_agent\":\"okhttp\\/4.12.0\",\"method\":\"POST\",\"uri\":\"\\/api\\/mobile.php?action=ping\"}'),
(9,1778448061524732,'2026-05-11 00:21:01.524905',2,'MOBILE_LOGOUT','USER',2,'61.8.134.41','okhttp/4.12.0','Выход из мобильного приложения','{\"ip\":\"61.8.134.41\",\"user_agent\":\"okhttp\\/4.12.0\",\"method\":\"POST\",\"uri\":\"\\/api\\/mobile.php?action=logout\",\"token_hash_prefix\":\"50949862ba4a\"}'),
(10,1778448076483880,'2026-05-11 00:21:16.484039',2,'MOBILE_LOGIN','USER',2,'61.8.134.41','okhttp/4.12.0','Вход из мобильного приложения','{\"ip\":\"61.8.134.41\",\"user_agent\":\"okhttp\\/4.12.0\",\"method\":\"POST\",\"uri\":\"\\/api\\/mobile.php?action=login\",\"device_name\":\"motorola motorola edge 50 neo\",\"device_fingerprint\":\"969117b65b9b580f\"}'),
(11,1778448176349834,'2026-05-11 00:22:56.350075',2,'MOBILE_APP_OPEN','USER',2,'61.8.134.41','okhttp/4.12.0','Открытие мобильного приложения','{\"ip\":\"61.8.134.41\",\"user_agent\":\"okhttp\\/4.12.0\",\"method\":\"POST\",\"uri\":\"\\/api\\/mobile.php?action=ping\"}'),
(12,1778448176871727,'2026-05-11 00:22:56.872008',2,'MOBILE_APP_OPEN','USER',2,'61.8.134.41','okhttp/4.12.0','Открытие мобильного приложения','{\"ip\":\"61.8.134.41\",\"user_agent\":\"okhttp\\/4.12.0\",\"method\":\"POST\",\"uri\":\"\\/api\\/mobile.php?action=ping\"}'),
(13,1778448755727511,'2026-05-11 00:32:35.727754',2,'MOBILE_APP_OPEN','USER',2,'61.8.134.41','okhttp/4.12.0','Открытие мобильного приложения','{\"ip\":\"61.8.134.41\",\"user_agent\":\"okhttp\\/4.12.0\",\"method\":\"POST\",\"uri\":\"\\/api\\/mobile.php?action=ping\"}'),
(14,1778448817344682,'2026-05-11 00:33:37.344992',2,'MOBILE_APP_OPEN','USER',2,'61.8.134.41','okhttp/4.12.0','Открытие мобильного приложения','{\"ip\":\"61.8.134.41\",\"user_agent\":\"okhttp\\/4.12.0\",\"method\":\"POST\",\"uri\":\"\\/api\\/mobile.php?action=ping\"}'),
(15,1778448820425966,'2026-05-11 00:33:40.426218',2,'MOBILE_APP_OPEN','USER',2,'61.8.134.41','okhttp/4.12.0','Открытие мобильного приложения','{\"ip\":\"61.8.134.41\",\"user_agent\":\"okhttp\\/4.12.0\",\"method\":\"POST\",\"uri\":\"\\/api\\/mobile.php?action=ping\"}'),
(16,1778477302279831,'2026-05-11 08:28:22.280622',1,'MOBILE_LOGIN','USER',1,'84.166.209.16','curl/8.9.1','Вход из мобильного приложения','{\"ip\":\"84.166.209.16\",\"user_agent\":\"curl\\/8.9.1\",\"method\":\"POST\",\"uri\":\"\\/api\\/mobile.php?action=login\",\"device_name\":\"curl-test\",\"device_fingerprint\":\"curl-test-001\"}'),
(17,1778478884009594,'2026-05-11 08:54:44.009827',1,'LOGIN',NULL,NULL,'84.166.209.16','Mozilla/5.0 (X11; Linux x86_64; rv:145.0) Gecko/20100101 Firefox/145.0','Пользователь вошёл в систему',NULL),
(18,1778479394289586,'2026-05-11 09:03:14.289806',2,'MOBILE_APP_OPEN','USER',2,'61.8.128.73','okhttp/4.12.0','Открытие мобильного приложения','{\"ip\":\"61.8.128.73\",\"user_agent\":\"okhttp\\/4.12.0\",\"method\":\"POST\",\"uri\":\"\\/api\\/mobile.php?action=ping\"}'),
(19,1778479432585348,'2026-05-11 09:03:52.585806',2,'MOBILE_APP_OPEN','USER',2,'61.8.128.73','okhttp/4.12.0','Открытие мобильного приложения','{\"ip\":\"61.8.128.73\",\"user_agent\":\"okhttp\\/4.12.0\",\"method\":\"POST\",\"uri\":\"\\/api\\/mobile.php?action=ping\"}'),
(20,1778479658974810,'2026-05-11 09:07:38.975008',2,'LOGIN',NULL,NULL,'84.166.209.16','Mozilla/5.0 (X11; Linux x86_64; rv:145.0) Gecko/20100101 Firefox/145.0','Пользователь вошёл в систему',NULL),
(21,1778479868396606,'2026-05-11 09:11:08.396864',2,'MOBILE_APP_OPEN','USER',2,'61.8.134.53','okhttp/4.12.0','Открытие мобильного приложения','{\"ip\":\"61.8.134.53\",\"user_agent\":\"okhttp\\/4.12.0\",\"method\":\"POST\",\"uri\":\"\\/api\\/mobile.php?action=ping\"}'),
(22,1778479882495123,'2026-05-11 09:11:22.495460',2,'MOBILE_LOGOUT','USER',2,'61.8.134.53','okhttp/4.12.0','Выход из мобильного приложения','{\"ip\":\"61.8.134.53\",\"user_agent\":\"okhttp\\/4.12.0\",\"method\":\"POST\",\"uri\":\"\\/api\\/mobile.php?action=logout\",\"token_hash_prefix\":\"468d7f04bd5f\"}'),
(23,1778479910702942,'2026-05-11 09:11:50.703347',2,'MOBILE_LOGIN','USER',2,'61.8.134.53','okhttp/4.12.0','Вход из мобильного приложения','{\"ip\":\"61.8.134.53\",\"user_agent\":\"okhttp\\/4.12.0\",\"method\":\"POST\",\"uri\":\"\\/api\\/mobile.php?action=login\",\"device_name\":\"motorola motorola edge 50 neo\",\"device_fingerprint\":\"969117b65b9b580f\"}'),
(24,1778480035300602,'2026-05-11 09:13:55.300905',2,'MOBILE_LOGOUT','USER',2,'61.8.134.53','okhttp/4.12.0','Выход из мобильного приложения','{\"ip\":\"61.8.134.53\",\"user_agent\":\"okhttp\\/4.12.0\",\"method\":\"POST\",\"uri\":\"\\/api\\/mobile.php?action=logout\",\"token_hash_prefix\":\"8d4c7ba3736d\"}'),
(25,1778480045888307,'2026-05-11 09:14:05.888589',1,'MOBILE_LOGIN','USER',1,'61.8.134.53','okhttp/4.12.0','Вход из мобильного приложения','{\"ip\":\"61.8.134.53\",\"user_agent\":\"okhttp\\/4.12.0\",\"method\":\"POST\",\"uri\":\"\\/api\\/mobile.php?action=login\",\"device_name\":\"motorola motorola edge 50 neo\",\"device_fingerprint\":\"969117b65b9b580f\"}'),
(26,1778481979739502,'2026-05-11 09:46:19.739809',1,'LOGOUT',NULL,NULL,'84.166.209.16','Mozilla/5.0 (X11; Linux x86_64; rv:145.0) Gecko/20100101 Firefox/145.0','Пользователь вышел из системы',NULL),
(27,1778481990291258,'2026-05-11 09:46:30.291459',1,'LOGIN',NULL,NULL,'84.166.209.16','Mozilla/5.0 (X11; Linux x86_64; rv:145.0) Gecko/20100101 Firefox/145.0','Пользователь вошёл в систему',NULL),
(28,1778482393832110,'2026-05-11 09:53:13.832467',1,'LOGOUT',NULL,NULL,'84.166.209.16','Mozilla/5.0 (X11; Linux x86_64; rv:145.0) Gecko/20100101 Firefox/145.0','Пользователь вышел из системы',NULL),
(29,1778482400762034,'2026-05-11 09:53:20.762254',1,'LOGIN',NULL,NULL,'84.166.209.16','Mozilla/5.0 (X11; Linux x86_64; rv:145.0) Gecko/20100101 Firefox/145.0','Пользователь вошёл в систему',NULL),
(30,1778483935507277,'2026-05-11 10:18:55.507695',1,'ORDER_CREATED','TOUR_ORDER',4,'84.166.209.16','Mozilla/5.0 (X11; Linux x86_64; rv:145.0) Gecko/20100101 Firefox/145.0','Создана заявка','{\"title\":\"ввввв\",\"address\":\"цувуц\",\"area_m2\":3333}'),
(31,1778483951185125,'2026-05-11 10:19:11.185485',1,'USER_UPDATED','USER',2,'84.166.209.16','Mozilla/5.0 (X11; Linux x86_64; rv:145.0) Gecko/20100101 Firefox/145.0','Обновлены роль/активность пользователя','{\"role\":\"OPERATOR\",\"is_active\":1}'),
(32,1778483969201626,'2026-05-11 10:19:29.201882',2,'LOGIN',NULL,NULL,'84.166.209.16','Mozilla/5.0 (X11; Linux x86_64; rv:145.0) Gecko/20100101 Firefox/145.0','Пользователь вошёл в систему',NULL),
(33,1778483980531043,'2026-05-11 10:19:40.532676',2,'ORDER_TAKEN','TOUR_ORDER',3,'84.166.209.16','Mozilla/5.0 (X11; Linux x86_64; rv:145.0) Gecko/20100101 Firefox/145.0','Оператор взял заявку в работу',NULL),
(34,1778484031247393,'2026-05-11 10:20:31.247701',1,'LOGIN',NULL,NULL,'84.166.209.16','Mozilla/5.0 (X11; Linux x86_64; rv:145.0) Gecko/20100101 Firefox/145.0','Пользователь вошёл в систему',NULL),
(35,1778486303632754,'2026-05-11 10:58:23.632882',1,'LOGIN',NULL,NULL,'84.166.209.16','Mozilla/5.0 (X11; Linux x86_64; rv:145.0) Gecko/20100101 Firefox/145.0','Пользователь вошёл в систему',NULL),
(36,1778486316169758,'2026-05-11 10:58:36.170222',1,'USER_UPDATED','USER',2,'84.166.209.16','Mozilla/5.0 (X11; Linux x86_64; rv:145.0) Gecko/20100101 Firefox/145.0','Обновлены роль/активность пользователя','{\"role\":\"BROKER\",\"is_active\":1}'),
(37,1778486318427737,'2026-05-11 10:58:38.428028',1,'USER_UPDATED','USER',2,'84.166.209.16','Mozilla/5.0 (X11; Linux x86_64; rv:145.0) Gecko/20100101 Firefox/145.0','Обновлены роль/активность пользователя','{\"role\":\"ADMIN\",\"is_active\":1}'),
(38,1778486321351703,'2026-05-11 10:58:41.351991',1,'USER_UPDATED','USER',2,'84.166.209.16','Mozilla/5.0 (X11; Linux x86_64; rv:145.0) Gecko/20100101 Firefox/145.0','Обновлены роль/активность пользователя','{\"role\":\"OPERATOR\",\"is_active\":1}'),
(39,1778486333545330,'2026-05-11 10:58:53.545803',1,'ORDER_CREATED','TOUR_ORDER',5,'84.166.209.16','Mozilla/5.0 (X11; Linux x86_64; rv:145.0) Gecko/20100101 Firefox/145.0','Создана заявка','{\"title\":\"12323\",\"address\":\"123\",\"area_m2\":111}'),
(40,1778486341304851,'2026-05-11 10:59:01.306646',1,'ORDER_TAKEN','TOUR_ORDER',5,'84.166.209.16','Mozilla/5.0 (X11; Linux x86_64; rv:145.0) Gecko/20100101 Firefox/145.0','Оператор взял заявку в работу',NULL),
(41,1778486360380040,'2026-05-11 10:59:20.380266',2,'LOGIN',NULL,NULL,'84.166.209.16','Mozilla/5.0 (X11; Linux x86_64; rv:145.0) Gecko/20100101 Firefox/145.0','Пользователь вошёл в систему',NULL),
(42,1778486370647079,'2026-05-11 10:59:30.647471',2,'ORDER_TAKEN','TOUR_ORDER',2,'84.166.209.16','Mozilla/5.0 (X11; Linux x86_64; rv:145.0) Gecko/20100101 Firefox/145.0','Оператор взял заявку в работу',NULL),
(43,1778486411505119,'2026-05-11 11:00:11.507178',2,'ORDER_CREATED','TOUR_ORDER',6,'84.166.209.16','Mozilla/5.0 (X11; Linux x86_64; rv:145.0) Gecko/20100101 Firefox/145.0','Создана заявка','{\"title\":\"oper\",\"address\":\"oper\",\"area_m2\":111}'),
(44,1778486608189222,'2026-05-11 11:03:28.189357',1,'LOGIN',NULL,NULL,'84.166.209.16','Mozilla/5.0 (X11; Linux x86_64; rv:145.0) Gecko/20100101 Firefox/145.0','Пользователь вошёл в систему',NULL),
(45,1778486923857603,'2026-05-11 11:08:43.857896',1,'MOBILE_APP_OPEN','USER',1,'61.8.134.6','okhttp/4.12.0','Открытие мобильного приложения','{\"ip\":\"61.8.134.6\",\"user_agent\":\"okhttp\\/4.12.0\",\"method\":\"POST\",\"uri\":\"\\/api\\/mobile.php?action=ping\"}'),
(46,1778488636070572,'2026-05-11 11:37:16.070848',1,'MOBILE_APP_OPEN','USER',1,'61.8.134.26','okhttp/4.12.0','Открытие мобильного приложения','{\"ip\":\"61.8.134.26\",\"user_agent\":\"okhttp\\/4.12.0\",\"method\":\"POST\",\"uri\":\"\\/api\\/mobile.php?action=ping\"}'),
(47,1778488780002370,'2026-05-11 11:39:40.002737',2,'LOGIN',NULL,NULL,'84.166.209.16','Mozilla/5.0 (X11; Linux x86_64; rv:145.0) Gecko/20100101 Firefox/145.0','Пользователь вошёл в систему',NULL),
(48,1778488802901304,'2026-05-11 11:40:02.901705',1,'ORDER_TAKEN','TOUR_ORDER',4,'61.8.134.26','okhttp/4.12.0','Заявка взята в работу',NULL),
(49,1778489280354985,'2026-05-11 11:48:00.355317',1,'MOBILE_APP_OPEN','USER',1,'61.8.128.89','okhttp/4.12.0','Открытие мобильного приложения','{\"ip\":\"61.8.128.89\",\"user_agent\":\"okhttp\\/4.12.0\",\"method\":\"POST\",\"uri\":\"\\/api\\/mobile.php?action=ping\"}'),
(50,1778489389325899,'2026-05-11 11:49:49.326230',1,'ORDER_CREATED','TOUR_ORDER',1,'84.166.209.16','Mozilla/5.0 (X11; Linux x86_64; rv:145.0) Gecko/20100101 Firefox/145.0','Создана заявка','{\"title\":\"админ тест\",\"address\":\"админский\",\"area_m2\":100}'),
(51,1778489429355985,'2026-05-11 11:50:29.357951',1,'ORDER_CREATED','TOUR_ORDER',2,'84.166.209.16','Mozilla/5.0 (X11; Linux x86_64; rv:145.0) Gecko/20100101 Firefox/145.0','Создана заявка','{\"title\":\"admin 02\",\"address\":\"adminskiy 02\",\"area_m2\":200}'),
(52,1778489472689338,'2026-05-11 11:51:12.689655',2,'ORDER_CREATED','TOUR_ORDER',3,'84.166.209.16','Mozilla/5.0 (X11; Linux x86_64; rv:145.0) Gecko/20100101 Firefox/145.0','Создана заявка','{\"title\":\"ilya\",\"address\":\"ilyamskiy\",\"area_m2\":300}'),
(53,1778489491392856,'2026-05-11 11:51:31.394997',2,'ORDER_CREATED','TOUR_ORDER',4,'84.166.209.16','Mozilla/5.0 (X11; Linux x86_64; rv:145.0) Gecko/20100101 Firefox/145.0','Создана заявка','{\"title\":\"ilya 02\",\"address\":\"iyamskiy 02\",\"area_m2\":400}'),
(54,1778490713560844,'2026-05-11 12:11:53.561067',1,'MOBILE_APP_OPEN','USER',1,'61.8.128.44','okhttp/4.12.0','Открытие мобильного приложения','{\"ip\":\"61.8.128.44\",\"user_agent\":\"okhttp\\/4.12.0\",\"method\":\"POST\",\"uri\":\"\\/api\\/mobile.php?action=ping\"}'),
(55,1778492478254697,'2026-05-11 12:41:18.255067',1,'MOBILE_APP_OPEN','USER',1,'61.8.128.5','okhttp/4.12.0','Открытие мобильного приложения','{\"ip\":\"61.8.128.5\",\"user_agent\":\"okhttp\\/4.12.0\",\"method\":\"POST\",\"uri\":\"\\/api\\/mobile.php?action=ping\"}'),
(56,1778493436305877,'2026-05-11 12:57:16.306375',1,'LOGIN',NULL,NULL,'84.166.209.16','Mozilla/5.0 (X11; Linux x86_64; rv:145.0) Gecko/20100101 Firefox/145.0','Пользователь вошёл в систему',NULL),
(57,1778493496456177,'2026-05-11 12:58:16.456639',1,'ORDER_UPDATED','TOUR_ORDER',2,'84.166.209.16','Mozilla/5.0 (X11; Linux x86_64; rv:145.0) Gecko/20100101 Firefox/145.0','Заявка обновлена',NULL),
(58,1778493515872238,'2026-05-11 12:58:35.872615',1,'ORDER_UPDATED','TOUR_ORDER',4,'84.166.209.16','Mozilla/5.0 (X11; Linux x86_64; rv:145.0) Gecko/20100101 Firefox/145.0','Заявка обновлена',NULL),
(59,1778493546491505,'2026-05-11 12:59:06.491779',2,'LOGIN',NULL,NULL,'84.166.209.16','Mozilla/5.0 (X11; Linux x86_64; rv:145.0) Gecko/20100101 Firefox/145.0','Пользователь вошёл в систему',NULL),
(60,1778493621313749,'2026-05-11 13:00:21.314018',2,'ORDER_UPDATED','TOUR_ORDER',4,'84.166.209.16','Mozilla/5.0 (X11; Linux x86_64; rv:145.0) Gecko/20100101 Firefox/145.0','Заявка обновлена',NULL),
(61,1778493846644001,'2026-05-11 13:04:06.644324',1,'MOBILE_APP_OPEN','USER',1,'61.8.134.17','okhttp/4.12.0','Открытие мобильного приложения','{\"ip\":\"61.8.134.17\",\"user_agent\":\"okhttp\\/4.12.0\",\"method\":\"POST\",\"uri\":\"\\/api\\/mobile.php?action=ping\"}'),
(62,1778494743126264,'2026-05-11 13:19:03.126535',2,'ORDER_UPDATED','TOUR_ORDER',3,'84.166.209.16','Mozilla/5.0 (X11; Linux x86_64; rv:145.0) Gecko/20100101 Firefox/145.0','Заявка обновлена',NULL),
(63,1778494761605980,'2026-05-11 13:19:21.606318',2,'ORDER_UPDATED','TOUR_ORDER',3,'84.166.209.16','Mozilla/5.0 (X11; Linux x86_64; rv:145.0) Gecko/20100101 Firefox/145.0','Заявка обновлена',NULL),
(64,1778494778079879,'2026-05-11 13:19:38.080234',2,'ORDER_UPDATED','TOUR_ORDER',4,'84.166.209.16','Mozilla/5.0 (X11; Linux x86_64; rv:145.0) Gecko/20100101 Firefox/145.0','Заявка обновлена',NULL),
(65,1778495514081837,'2026-05-11 13:31:54.082174',1,'MOBILE_APP_OPEN','USER',1,'61.8.134.58','okhttp/4.12.0','Открытие мобильного приложения','{\"ip\":\"61.8.134.58\",\"user_agent\":\"okhttp\\/4.12.0\",\"method\":\"POST\",\"uri\":\"\\/api\\/mobile.php?action=ping\"}'),
(66,1778495581743151,'2026-05-11 13:33:01.743594',1,'MOBILE_APP_OPEN','USER',1,'61.8.134.58','okhttp/4.12.0','Открытие мобильного приложения','{\"ip\":\"61.8.134.58\",\"user_agent\":\"okhttp\\/4.12.0\",\"method\":\"POST\",\"uri\":\"\\/api\\/mobile.php?action=ping\"}'),
(67,1778495623573855,'2026-05-11 13:33:43.574167',1,'MOBILE_APP_OPEN','USER',1,'61.8.134.58','okhttp/4.12.0','Открытие мобильного приложения','{\"ip\":\"61.8.134.58\",\"user_agent\":\"okhttp\\/4.12.0\",\"method\":\"POST\",\"uri\":\"\\/api\\/mobile.php?action=ping\"}'),
(68,1778495627860622,'2026-05-11 13:33:47.860880',1,'MOBILE_LOGOUT','USER',1,'61.8.134.58','okhttp/4.12.0','Выход из мобильного приложения','{\"ip\":\"61.8.134.58\",\"user_agent\":\"okhttp\\/4.12.0\",\"method\":\"POST\",\"uri\":\"\\/api\\/mobile.php?action=logout\",\"token_hash_prefix\":\"25cbc97bc62e\"}'),
(69,1778495638216246,'2026-05-11 13:33:58.216614',2,'MOBILE_LOGIN','USER',2,'61.8.134.58','okhttp/4.12.0','Вход из мобильного приложения','{\"ip\":\"61.8.134.58\",\"user_agent\":\"okhttp\\/4.12.0\",\"method\":\"POST\",\"uri\":\"\\/api\\/mobile.php?action=login\",\"device_name\":\"motorola motorola edge 50 neo\",\"device_fingerprint\":\"969117b65b9b580f\"}'),
(70,1778495712274362,'2026-05-11 13:35:12.274685',2,'MOBILE_APP_OPEN','USER',2,'61.8.134.58','okhttp/4.12.0','Открытие мобильного приложения','{\"ip\":\"61.8.134.58\",\"user_agent\":\"okhttp\\/4.12.0\",\"method\":\"POST\",\"uri\":\"\\/api\\/mobile.php?action=ping\"}'),
(71,1778497423547232,'2026-05-11 14:03:43.547643',2,'MOBILE_APP_OPEN','USER',2,'61.8.128.101','okhttp/4.12.0','Открытие мобильного приложения','{\"ip\":\"61.8.128.101\",\"user_agent\":\"okhttp\\/4.12.0\",\"method\":\"POST\",\"uri\":\"\\/api\\/mobile.php?action=ping\"}'),
(72,1778497472347700,'2026-05-11 14:04:32.347946',2,'MOBILE_APP_OPEN','USER',2,'61.8.128.101','okhttp/4.12.0','Открытие мобильного приложения','{\"ip\":\"61.8.128.101\",\"user_agent\":\"okhttp\\/4.12.0\",\"method\":\"POST\",\"uri\":\"\\/api\\/mobile.php?action=ping\"}'),
(73,1778497802946103,'2026-05-11 14:10:02.946378',2,'MOBILE_APP_OPEN','USER',2,'61.8.128.101','okhttp/4.12.0','Открытие мобильного приложения','{\"ip\":\"61.8.128.101\",\"user_agent\":\"okhttp\\/4.12.0\",\"method\":\"POST\",\"uri\":\"\\/api\\/mobile.php?action=ping\"}'),
(74,1778498262213023,'2026-05-11 14:17:42.213409',2,'ORDER_TAKEN','TOUR_ORDER',4,'61.8.128.8','okhttp/4.12.0','Заявка взята в работу',NULL),
(75,1778498363136641,'2026-05-11 14:19:23.136939',2,'MOBILE_APP_OPEN','USER',2,'61.8.128.8','okhttp/4.12.0','Открытие мобильного приложения','{\"ip\":\"61.8.128.8\",\"user_agent\":\"okhttp\\/4.12.0\",\"method\":\"POST\",\"uri\":\"\\/api\\/mobile.php?action=ping\"}'),
(76,1778498417892156,'2026-05-11 14:20:17.892581',2,'LOGIN',NULL,NULL,'84.166.209.16','Mozilla/5.0 (X11; Linux x86_64; rv:145.0) Gecko/20100101 Firefox/145.0','Пользователь вошёл в систему',NULL),
(77,1778498441848777,'2026-05-11 14:20:41.849024',2,'MOBILE_APP_OPEN','USER',2,'61.8.128.8','okhttp/4.12.0','Открытие мобильного приложения','{\"ip\":\"61.8.128.8\",\"user_agent\":\"okhttp\\/4.12.0\",\"method\":\"POST\",\"uri\":\"\\/api\\/mobile.php?action=ping\"}'),
(78,1778500202309188,'2026-05-11 14:50:02.309540',2,'MOBILE_APP_OPEN','USER',2,'61.8.128.47','okhttp/4.12.0','Открытие мобильного приложения','{\"ip\":\"61.8.128.47\",\"user_agent\":\"okhttp\\/4.12.0\",\"method\":\"POST\",\"uri\":\"\\/api\\/mobile.php?action=ping\"}'),
(79,1778501865942417,'2026-05-11 15:17:45.942582',2,'MOBILE_APP_OPEN','USER',2,'61.8.128.42','okhttp/4.12.0','Открытие мобильного приложения','{\"ip\":\"61.8.128.42\",\"user_agent\":\"okhttp\\/4.12.0\",\"method\":\"POST\",\"uri\":\"\\/api\\/mobile.php?action=ping\"}'),
(80,1778501901744197,'2026-05-11 15:18:21.745275',2,'MOBILE_LOGIN','USER',2,'84.166.209.16','curl/8.9.1','Вход из мобильного приложения','{\"ip\":\"84.166.209.16\",\"user_agent\":\"curl\\/8.9.1\",\"method\":\"POST\",\"uri\":\"\\/api\\/mobile.php?action=login\",\"device_name\":\"curl-test\",\"device_fingerprint\":\"curl-upload-test\"}'),
(81,1778502081694419,'2026-05-11 15:21:21.694729',2,'MOBILE_APP_OPEN','USER',2,'61.8.128.42','okhttp/4.12.0','Открытие мобильного приложения','{\"ip\":\"61.8.128.42\",\"user_agent\":\"okhttp\\/4.12.0\",\"method\":\"POST\",\"uri\":\"\\/api\\/mobile.php?action=ping\"}'),
(82,1778504001666745,'2026-05-11 15:53:21.667083',2,'MOBILE_APP_OPEN','USER',2,'84.166.209.16','okhttp/4.12.0','Открытие мобильного приложения','{\"ip\":\"84.166.209.16\",\"user_agent\":\"okhttp\\/4.12.0\",\"method\":\"POST\",\"uri\":\"\\/api\\/mobile.php?action=ping\"}'),
(83,1778504813276697,'2026-05-11 16:06:53.277033',2,'MOBILE_APP_OPEN','USER',2,'84.166.209.16','okhttp/4.12.0','Открытие мобильного приложения','{\"ip\":\"84.166.209.16\",\"user_agent\":\"okhttp\\/4.12.0\",\"method\":\"POST\",\"uri\":\"\\/api\\/mobile.php?action=ping\"}'),
(84,1778521897136029,'2026-05-11 20:51:37.136455',1,'LOGIN',NULL,NULL,'84.166.209.16','Mozilla/5.0 (X11; Linux x86_64; rv:145.0) Gecko/20100101 Firefox/145.0','Пользователь вошёл в систему',NULL),
(85,1778522177051858,'2026-05-11 20:56:17.052153',2,'MOBILE_APP_OPEN','USER',2,'61.8.135.7','okhttp/4.12.0','Открытие мобильного приложения','{\"ip\":\"61.8.135.7\",\"user_agent\":\"okhttp\\/4.12.0\",\"method\":\"POST\",\"uri\":\"\\/api\\/mobile.php?action=ping\"}'),
(86,1778526981740878,'2026-05-11 22:16:21.741095',2,'MOBILE_APP_OPEN','USER',2,'61.8.135.25','okhttp/4.12.0','Открытие мобильного приложения','{\"ip\":\"61.8.135.25\",\"user_agent\":\"okhttp\\/4.12.0\",\"method\":\"POST\",\"uri\":\"\\/api\\/mobile.php?action=ping\"}'),
(87,1778527054892025,'2026-05-11 22:17:34.892236',1,'LOGIN',NULL,NULL,'84.166.209.16','Mozilla/5.0 (X11; Linux x86_64; rv:145.0) Gecko/20100101 Firefox/145.0','Пользователь вошёл в систему',NULL),
(88,1778529299417378,'2026-05-11 22:54:59.417581',2,'MOBILE_APP_OPEN','USER',2,'61.8.135.50','okhttp/4.12.0','Открытие мобильного приложения','{\"ip\":\"61.8.135.50\",\"user_agent\":\"okhttp\\/4.12.0\",\"method\":\"POST\",\"uri\":\"\\/api\\/mobile.php?action=ping\"}'),
(89,1778529364423197,'2026-05-11 22:56:04.423748',2,'VIDEO_UPLOADED','TOUR_ORDER',4,'61.8.135.50','okhttp/4.12.0','Загружен video scan','{\"ip\":\"61.8.135.50\",\"user_agent\":\"okhttp\\/4.12.0\",\"method\":\"POST\",\"uri\":\"\\/api\\/mobile.php?action=upload_video_scan\",\"capture_session_id\":4,\"app_scan_uuid\":\"bffdf9a5-fc10-42f7-b9dc-d04c5c7792c8\",\"storage_path\":\"orders\\/4\\/sessions\\/192c4533-fe07-45e1-881b-c3c41f95a563\\/videos\\/bffdf9a5-fc10-42f7-b9dc-d04c5c7792c8_VID_20260511_141109_00_128.mp4\",\"size_bytes\":189451514,\"duration_sec\":7,\"local_camera_url\":\"http:\\/\\/192.168.42.1:80\\/DCIM\\/Camera01\\/VID_20260511_141109_00_128.mp4\"}'),
(90,1778529371686477,'2026-05-11 22:56:11.686911',2,'PHOTO_UPLOADED','TOUR_ORDER',4,'61.8.135.50','okhttp/4.12.0','Загружен photo point','{\"ip\":\"61.8.135.50\",\"user_agent\":\"okhttp\\/4.12.0\",\"method\":\"POST\",\"uri\":\"\\/api\\/mobile.php?action=upload_photo_point\",\"capture_session_id\":4,\"app_point_uuid\":\"2b6ac6de-48c6-4e2e-816c-112868c8a8b5\",\"preview_storage_path\":\"orders\\/4\\/sessions\\/192c4533-fe07-45e1-881b-c3c41f95a563\\/photos\\/previews\\/2b6ac6de-48c6-4e2e-816c-112868c8a8b5_2b6ac6de-48c6-4e2e-816c-112868c8a8b5.jpg\",\"original_storage_path\":\"orders\\/4\\/sessions\\/192c4533-fe07-45e1-881b-c3c41f95a563\\/photos\\/originals\\/2b6ac6de-48c6-4e2e-816c-112868c8a8b5_2b6ac6de-48c6-4e2e-816c-112868c8a8b5.jpg\"}'),
(91,1778531709133813,'2026-05-11 23:35:09.134140',2,'LOGIN',NULL,NULL,'84.166.209.16','Mozilla/5.0 (X11; Linux x86_64; rv:145.0) Gecko/20100101 Firefox/145.0','Пользователь вошёл в систему',NULL),
(92,1778566798428605,'2026-05-12 09:19:58.429310',2,'MOBILE_APP_OPEN','USER',2,'61.8.135.69','okhttp/4.12.0','Открытие мобильного приложения','{\"ip\":\"61.8.135.69\",\"user_agent\":\"okhttp\\/4.12.0\",\"method\":\"POST\",\"uri\":\"\\/api\\/mobile.php?action=ping\"}'),
(93,1778570608291716,'2026-05-12 10:23:28.292175',2,'VIDEO_UPLOADED','TOUR_ORDER',4,'61.8.135.83','okhttp/4.12.0','Загружен video scan','{\"ip\":\"61.8.135.83\",\"user_agent\":\"okhttp\\/4.12.0\",\"method\":\"POST\",\"uri\":\"\\/api\\/mobile.php?action=upload_video_scan\",\"capture_session_id\":4,\"app_scan_uuid\":\"bffdf9a5-fc10-42f7-b9dc-d04c5c7792c8\",\"storage_path\":\"orders\\/4\\/sessions\\/192c4533-fe07-45e1-881b-c3c41f95a563\\/videos\\/bffdf9a5-fc10-42f7-b9dc-d04c5c7792c8_VID_20260511_141109_00_128.mp4\",\"size_bytes\":189451514,\"duration_sec\":7,\"local_camera_url\":\"http:\\/\\/192.168.42.1:80\\/DCIM\\/Camera01\\/VID_20260511_141109_00_128.mp4\"}'),
(94,1778570618859831,'2026-05-12 10:23:39.022034',2,'PHOTO_UPLOADED','TOUR_ORDER',4,'61.8.135.83','okhttp/4.12.0','Загружен photo point','{\"ip\":\"61.8.135.83\",\"user_agent\":\"okhttp\\/4.12.0\",\"method\":\"POST\",\"uri\":\"\\/api\\/mobile.php?action=upload_photo_point\",\"capture_session_id\":4,\"app_point_uuid\":\"2b6ac6de-48c6-4e2e-816c-112868c8a8b5\",\"preview_storage_path\":\"orders\\/4\\/sessions\\/192c4533-fe07-45e1-881b-c3c41f95a563\\/photos\\/previews\\/2b6ac6de-48c6-4e2e-816c-112868c8a8b5_2b6ac6de-48c6-4e2e-816c-112868c8a8b5.jpg\",\"original_storage_path\":\"orders\\/4\\/sessions\\/192c4533-fe07-45e1-881b-c3c41f95a563\\/photos\\/originals\\/2b6ac6de-48c6-4e2e-816c-112868c8a8b5_2b6ac6de-48c6-4e2e-816c-112868c8a8b5.jpg\"}'),
(95,1778585731470227,'2026-05-12 14:35:31.470596',1,'LOGIN',NULL,NULL,'84.166.208.159','Mozilla/5.0 (X11; Linux x86_64; rv:145.0) Gecko/20100101 Firefox/145.0','Пользователь вошёл в систему',NULL),
(96,1778611746972178,'2026-05-12 21:49:06.972558',1,'LOGIN',NULL,NULL,'84.166.208.159','Mozilla/5.0 (X11; Linux x86_64; rv:145.0) Gecko/20100101 Firefox/145.0','Пользователь вошёл в систему',NULL),
(97,1778612874625900,'2026-05-12 22:07:54.626474',2,'MOBILE_APP_OPEN','USER',2,'61.8.130.187','okhttp/4.12.0','Открытие мобильного приложения','{\"ip\":\"61.8.130.187\",\"user_agent\":\"okhttp\\/4.12.0\",\"method\":\"POST\",\"uri\":\"\\/api\\/mobile.php?action=ping\"}'),
(98,1778613155046620,'2026-05-12 22:12:35.046997',2,'VIDEO_UPLOADED','TOUR_ORDER',4,'84.166.208.159','okhttp/4.12.0','Загружен video scan','{\"ip\":\"84.166.208.159\",\"user_agent\":\"okhttp\\/4.12.0\",\"method\":\"POST\",\"uri\":\"\\/api\\/mobile.php?action=upload_video_scan\",\"capture_session_id\":12,\"app_scan_uuid\":\"25be3d10-beda-480b-b1c3-bb33ef7a2971\",\"storage_path\":\"orders\\/4\\/sessions\\/1674181c-1f00-4e96-9ea2-1914671e4b74\\/videos\\/25be3d10-beda-480b-b1c3-bb33ef7a2971_VID_20260512_200830_00_131.mp4\",\"size_bytes\":170315002,\"duration_sec\":5,\"local_camera_url\":\"http:\\/\\/192.168.42.1:80\\/DCIM\\/Camera01\\/VID_20260512_200830_00_131.mp4\"}'),
(99,1778613167198137,'2026-05-12 22:12:47.198451',2,'PHOTO_UPLOADED','TOUR_ORDER',4,'84.166.208.159','okhttp/4.12.0','Загружен photo point','{\"ip\":\"84.166.208.159\",\"user_agent\":\"okhttp\\/4.12.0\",\"method\":\"POST\",\"uri\":\"\\/api\\/mobile.php?action=upload_photo_point\",\"capture_session_id\":12,\"app_point_uuid\":\"2d999854-e210-4cd9-adc4-67eaef8457c6\",\"preview_storage_path\":\"orders\\/4\\/sessions\\/1674181c-1f00-4e96-9ea2-1914671e4b74\\/photos\\/previews\\/2d999854-e210-4cd9-adc4-67eaef8457c6_2d999854-e210-4cd9-adc4-67eaef8457c6.jpg\",\"original_storage_path\":\"orders\\/4\\/sessions\\/1674181c-1f00-4e96-9ea2-1914671e4b74\\/photos\\/originals\\/2d999854-e210-4cd9-adc4-67eaef8457c6_2d999854-e210-4cd9-adc4-67eaef8457c6.jpg\"}'),
(100,1778613178543515,'2026-05-12 22:12:58.557164',2,'PHOTO_UPLOADED','TOUR_ORDER',4,'84.166.208.159','okhttp/4.12.0','Загружен photo point','{\"ip\":\"84.166.208.159\",\"user_agent\":\"okhttp\\/4.12.0\",\"method\":\"POST\",\"uri\":\"\\/api\\/mobile.php?action=upload_photo_point\",\"capture_session_id\":12,\"app_point_uuid\":\"605149a9-12b4-4cf0-af7a-3b3842728a5f\",\"preview_storage_path\":\"orders\\/4\\/sessions\\/1674181c-1f00-4e96-9ea2-1914671e4b74\\/photos\\/previews\\/605149a9-12b4-4cf0-af7a-3b3842728a5f_605149a9-12b4-4cf0-af7a-3b3842728a5f.jpg\",\"original_storage_path\":\"orders\\/4\\/sessions\\/1674181c-1f00-4e96-9ea2-1914671e4b74\\/photos\\/originals\\/605149a9-12b4-4cf0-af7a-3b3842728a5f_605149a9-12b4-4cf0-af7a-3b3842728a5f.jpg\"}'),
(101,1778613194984170,'2026-05-12 22:13:14.984643',2,'VIDEO_UPLOADED','TOUR_ORDER',4,'84.166.208.159','okhttp/4.12.0','Загружен video scan','{\"ip\":\"84.166.208.159\",\"user_agent\":\"okhttp\\/4.12.0\",\"method\":\"POST\",\"uri\":\"\\/api\\/mobile.php?action=upload_video_scan\",\"capture_session_id\":12,\"app_scan_uuid\":\"25be3d10-beda-480b-b1c3-bb33ef7a2971\",\"storage_path\":\"orders\\/4\\/sessions\\/1674181c-1f00-4e96-9ea2-1914671e4b74\\/videos\\/25be3d10-beda-480b-b1c3-bb33ef7a2971_VID_20260512_200830_00_131.mp4\",\"size_bytes\":null,\"duration_sec\":5,\"local_camera_url\":\"http:\\/\\/192.168.42.1:80\\/DCIM\\/Camera01\\/VID_20260512_200830_00_131.mp4\"}'),
(102,1778613209634977,'2026-05-12 22:13:29.635344',2,'MOBILE_APP_OPEN','USER',2,'84.166.208.159','okhttp/4.12.0','Открытие мобильного приложения','{\"ip\":\"84.166.208.159\",\"user_agent\":\"okhttp\\/4.12.0\",\"method\":\"POST\",\"uri\":\"\\/api\\/mobile.php?action=ping\"}'),
(103,1778613209636064,'2026-05-12 22:13:29.636668',2,'VIDEO_UPLOADED','TOUR_ORDER',4,'84.166.208.159','okhttp/4.12.0','Загружен video scan','{\"ip\":\"84.166.208.159\",\"user_agent\":\"okhttp\\/4.12.0\",\"method\":\"POST\",\"uri\":\"\\/api\\/mobile.php?action=upload_video_scan\",\"capture_session_id\":12,\"app_scan_uuid\":\"25be3d10-beda-480b-b1c3-bb33ef7a2971\",\"storage_path\":\"orders\\/4\\/sessions\\/1674181c-1f00-4e96-9ea2-1914671e4b74\\/videos\\/25be3d10-beda-480b-b1c3-bb33ef7a2971_VID_20260512_200830_00_131.mp4\",\"size_bytes\":170315002,\"duration_sec\":5,\"local_camera_url\":\"http:\\/\\/192.168.42.1:80\\/DCIM\\/Camera01\\/VID_20260512_200830_00_131.mp4\"}'),
(104,1778613210684637,'2026-05-12 22:13:30.685099',2,'PHOTO_UPLOADED','TOUR_ORDER',4,'84.166.208.159','okhttp/4.12.0','Загружен photo point','{\"ip\":\"84.166.208.159\",\"user_agent\":\"okhttp\\/4.12.0\",\"method\":\"POST\",\"uri\":\"\\/api\\/mobile.php?action=upload_photo_point\",\"capture_session_id\":12,\"app_point_uuid\":\"2d999854-e210-4cd9-adc4-67eaef8457c6\",\"preview_storage_path\":\"orders\\/4\\/sessions\\/1674181c-1f00-4e96-9ea2-1914671e4b74\\/photos\\/previews\\/2d999854-e210-4cd9-adc4-67eaef8457c6_2d999854-e210-4cd9-adc4-67eaef8457c6.jpg\",\"original_storage_path\":\"orders\\/4\\/sessions\\/1674181c-1f00-4e96-9ea2-1914671e4b74\\/photos\\/originals\\/2d999854-e210-4cd9-adc4-67eaef8457c6_2d999854-e210-4cd9-adc4-67eaef8457c6.jpg\"}'),
(105,1778613287969763,'2026-05-12 22:14:47.970199',2,'MOBILE_APP_OPEN','USER',2,'84.166.208.159','okhttp/4.12.0','Открытие мобильного приложения','{\"ip\":\"84.166.208.159\",\"user_agent\":\"okhttp\\/4.12.0\",\"method\":\"POST\",\"uri\":\"\\/api\\/mobile.php?action=ping\"}'),
(106,1778613777661112,'2026-05-12 22:22:57.661409',2,'VIDEO_UPLOADED','TOUR_ORDER',4,'84.166.208.159','okhttp/4.12.0','Загружен video scan','{\"ip\":\"84.166.208.159\",\"user_agent\":\"okhttp\\/4.12.0\",\"method\":\"POST\",\"uri\":\"\\/api\\/mobile.php?action=upload_video_scan\",\"capture_session_id\":12,\"app_scan_uuid\":\"25be3d10-beda-480b-b1c3-bb33ef7a2971\",\"storage_path\":\"orders\\/4\\/sessions\\/1674181c-1f00-4e96-9ea2-1914671e4b74\\/videos\\/25be3d10-beda-480b-b1c3-bb33ef7a2971_VID_20260512_200830_00_131.mp4\",\"size_bytes\":170315002,\"duration_sec\":5,\"local_camera_url\":\"http:\\/\\/192.168.42.1:80\\/DCIM\\/Camera01\\/VID_20260512_200830_00_131.mp4\"}'),
(107,1778613786885979,'2026-05-12 22:23:06.886191',2,'VIDEO_UPLOADED','TOUR_ORDER',4,'84.166.208.159','okhttp/4.12.0','Загружен video scan','{\"ip\":\"84.166.208.159\",\"user_agent\":\"okhttp\\/4.12.0\",\"method\":\"POST\",\"uri\":\"\\/api\\/mobile.php?action=upload_video_scan\",\"capture_session_id\":12,\"app_scan_uuid\":\"25be3d10-beda-480b-b1c3-bb33ef7a2971\",\"storage_path\":\"orders\\/4\\/sessions\\/1674181c-1f00-4e96-9ea2-1914671e4b74\\/videos\\/25be3d10-beda-480b-b1c3-bb33ef7a2971_VID_20260512_200830_00_131.mp4\",\"size_bytes\":170315002,\"duration_sec\":5,\"local_camera_url\":\"http:\\/\\/192.168.42.1:80\\/DCIM\\/Camera01\\/VID_20260512_200830_00_131.mp4\"}'),
(108,1778613796063800,'2026-05-12 22:23:16.064044',2,'VIDEO_UPLOADED','TOUR_ORDER',4,'84.166.208.159','okhttp/4.12.0','Загружен video scan','{\"ip\":\"84.166.208.159\",\"user_agent\":\"okhttp\\/4.12.0\",\"method\":\"POST\",\"uri\":\"\\/api\\/mobile.php?action=upload_video_scan\",\"capture_session_id\":12,\"app_scan_uuid\":\"25be3d10-beda-480b-b1c3-bb33ef7a2971\",\"storage_path\":\"orders\\/4\\/sessions\\/1674181c-1f00-4e96-9ea2-1914671e4b74\\/videos\\/25be3d10-beda-480b-b1c3-bb33ef7a2971_VID_20260512_200830_00_131.mp4\",\"size_bytes\":170315002,\"duration_sec\":5,\"local_camera_url\":\"http:\\/\\/192.168.42.1:80\\/DCIM\\/Camera01\\/VID_20260512_200830_00_131.mp4\"}'),
(109,1778613802362814,'2026-05-12 22:23:22.363128',2,'VIDEO_UPLOADED','TOUR_ORDER',4,'84.166.208.159','okhttp/4.12.0','Загружен video scan','{\"ip\":\"84.166.208.159\",\"user_agent\":\"okhttp\\/4.12.0\",\"method\":\"POST\",\"uri\":\"\\/api\\/mobile.php?action=upload_video_scan\",\"capture_session_id\":12,\"app_scan_uuid\":\"25be3d10-beda-480b-b1c3-bb33ef7a2971\",\"storage_path\":\"orders\\/4\\/sessions\\/1674181c-1f00-4e96-9ea2-1914671e4b74\\/videos\\/25be3d10-beda-480b-b1c3-bb33ef7a2971_VID_20260512_200830_00_131.mp4\",\"size_bytes\":170315002,\"duration_sec\":5,\"local_camera_url\":\"http:\\/\\/192.168.42.1:80\\/DCIM\\/Camera01\\/VID_20260512_200830_00_131.mp4\"}'),
(110,1778613806745216,'2026-05-12 22:23:26.745495',2,'VIDEO_UPLOADED','TOUR_ORDER',4,'84.166.208.159','okhttp/4.12.0','Загружен video scan','{\"ip\":\"84.166.208.159\",\"user_agent\":\"okhttp\\/4.12.0\",\"method\":\"POST\",\"uri\":\"\\/api\\/mobile.php?action=upload_video_scan\",\"capture_session_id\":12,\"app_scan_uuid\":\"25be3d10-beda-480b-b1c3-bb33ef7a2971\",\"storage_path\":\"orders\\/4\\/sessions\\/1674181c-1f00-4e96-9ea2-1914671e4b74\\/videos\\/25be3d10-beda-480b-b1c3-bb33ef7a2971_VID_20260512_200830_00_131.mp4\",\"size_bytes\":170315002,\"duration_sec\":5,\"local_camera_url\":\"http:\\/\\/192.168.42.1:80\\/DCIM\\/Camera01\\/VID_20260512_200830_00_131.mp4\"}'),
(111,1778613810668194,'2026-05-12 22:23:30.668501',2,'VIDEO_UPLOADED','TOUR_ORDER',4,'84.166.208.159','okhttp/4.12.0','Загружен video scan','{\"ip\":\"84.166.208.159\",\"user_agent\":\"okhttp\\/4.12.0\",\"method\":\"POST\",\"uri\":\"\\/api\\/mobile.php?action=upload_video_scan\",\"capture_session_id\":12,\"app_scan_uuid\":\"25be3d10-beda-480b-b1c3-bb33ef7a2971\",\"storage_path\":\"orders\\/4\\/sessions\\/1674181c-1f00-4e96-9ea2-1914671e4b74\\/videos\\/25be3d10-beda-480b-b1c3-bb33ef7a2971_VID_20260512_200830_00_131.mp4\",\"size_bytes\":170315002,\"duration_sec\":5,\"local_camera_url\":\"http:\\/\\/192.168.42.1:80\\/DCIM\\/Camera01\\/VID_20260512_200830_00_131.mp4\"}'),
(112,1778613814809676,'2026-05-12 22:23:34.809931',2,'VIDEO_UPLOADED','TOUR_ORDER',4,'84.166.208.159','okhttp/4.12.0','Загружен video scan','{\"ip\":\"84.166.208.159\",\"user_agent\":\"okhttp\\/4.12.0\",\"method\":\"POST\",\"uri\":\"\\/api\\/mobile.php?action=upload_video_scan\",\"capture_session_id\":12,\"app_scan_uuid\":\"25be3d10-beda-480b-b1c3-bb33ef7a2971\",\"storage_path\":\"orders\\/4\\/sessions\\/1674181c-1f00-4e96-9ea2-1914671e4b74\\/videos\\/25be3d10-beda-480b-b1c3-bb33ef7a2971_VID_20260512_200830_00_131.mp4\",\"size_bytes\":170315002,\"duration_sec\":5,\"local_camera_url\":\"http:\\/\\/192.168.42.1:80\\/DCIM\\/Camera01\\/VID_20260512_200830_00_131.mp4\"}'),
(113,1778613817199386,'2026-05-12 22:23:37.199911',2,'VIDEO_UPLOADED','TOUR_ORDER',4,'84.166.208.159','okhttp/4.12.0','Загружен video scan','{\"ip\":\"84.166.208.159\",\"user_agent\":\"okhttp\\/4.12.0\",\"method\":\"POST\",\"uri\":\"\\/api\\/mobile.php?action=upload_video_scan\",\"capture_session_id\":12,\"app_scan_uuid\":\"25be3d10-beda-480b-b1c3-bb33ef7a2971\",\"storage_path\":\"orders\\/4\\/sessions\\/1674181c-1f00-4e96-9ea2-1914671e4b74\\/videos\\/25be3d10-beda-480b-b1c3-bb33ef7a2971_VID_20260512_200830_00_131.mp4\",\"size_bytes\":170315002,\"duration_sec\":5,\"local_camera_url\":\"http:\\/\\/192.168.42.1:80\\/DCIM\\/Camera01\\/VID_20260512_200830_00_131.mp4\"}'),
(114,1778613817480851,'2026-05-12 22:23:37.481225',2,'VIDEO_UPLOADED','TOUR_ORDER',4,'84.166.208.159','okhttp/4.12.0','Загружен video scan','{\"ip\":\"84.166.208.159\",\"user_agent\":\"okhttp\\/4.12.0\",\"method\":\"POST\",\"uri\":\"\\/api\\/mobile.php?action=upload_video_scan\",\"capture_session_id\":12,\"app_scan_uuid\":\"25be3d10-beda-480b-b1c3-bb33ef7a2971\",\"storage_path\":\"orders\\/4\\/sessions\\/1674181c-1f00-4e96-9ea2-1914671e4b74\\/videos\\/25be3d10-beda-480b-b1c3-bb33ef7a2971_VID_20260512_200830_00_131.mp4\",\"size_bytes\":170315002,\"duration_sec\":5,\"local_camera_url\":\"http:\\/\\/192.168.42.1:80\\/DCIM\\/Camera01\\/VID_20260512_200830_00_131.mp4\"}'),
(115,1778613818981214,'2026-05-12 22:23:38.981556',2,'VIDEO_UPLOADED','TOUR_ORDER',4,'84.166.208.159','okhttp/4.12.0','Загружен video scan','{\"ip\":\"84.166.208.159\",\"user_agent\":\"okhttp\\/4.12.0\",\"method\":\"POST\",\"uri\":\"\\/api\\/mobile.php?action=upload_video_scan\",\"capture_session_id\":12,\"app_scan_uuid\":\"25be3d10-beda-480b-b1c3-bb33ef7a2971\",\"storage_path\":\"orders\\/4\\/sessions\\/1674181c-1f00-4e96-9ea2-1914671e4b74\\/videos\\/25be3d10-beda-480b-b1c3-bb33ef7a2971_VID_20260512_200830_00_131.mp4\",\"size_bytes\":170315002,\"duration_sec\":5,\"local_camera_url\":\"http:\\/\\/192.168.42.1:80\\/DCIM\\/Camera01\\/VID_20260512_200830_00_131.mp4\"}'),
(116,1778613821356683,'2026-05-12 22:23:41.357018',2,'VIDEO_UPLOADED','TOUR_ORDER',4,'84.166.208.159','okhttp/4.12.0','Загружен video scan','{\"ip\":\"84.166.208.159\",\"user_agent\":\"okhttp\\/4.12.0\",\"method\":\"POST\",\"uri\":\"\\/api\\/mobile.php?action=upload_video_scan\",\"capture_session_id\":12,\"app_scan_uuid\":\"25be3d10-beda-480b-b1c3-bb33ef7a2971\",\"storage_path\":\"orders\\/4\\/sessions\\/1674181c-1f00-4e96-9ea2-1914671e4b74\\/videos\\/25be3d10-beda-480b-b1c3-bb33ef7a2971_VID_20260512_200830_00_131.mp4\",\"size_bytes\":170315002,\"duration_sec\":5,\"local_camera_url\":\"http:\\/\\/192.168.42.1:80\\/DCIM\\/Camera01\\/VID_20260512_200830_00_131.mp4\"}'),
(117,1778613829934277,'2026-05-12 22:23:49.934645',2,'VIDEO_UPLOADED','TOUR_ORDER',4,'84.166.208.159','okhttp/4.12.0','Загружен video scan','{\"ip\":\"84.166.208.159\",\"user_agent\":\"okhttp\\/4.12.0\",\"method\":\"POST\",\"uri\":\"\\/api\\/mobile.php?action=upload_video_scan\",\"capture_session_id\":12,\"app_scan_uuid\":\"25be3d10-beda-480b-b1c3-bb33ef7a2971\",\"storage_path\":\"orders\\/4\\/sessions\\/1674181c-1f00-4e96-9ea2-1914671e4b74\\/videos\\/25be3d10-beda-480b-b1c3-bb33ef7a2971_VID_20260512_200830_00_131.mp4\",\"size_bytes\":170315002,\"duration_sec\":5,\"local_camera_url\":\"http:\\/\\/192.168.42.1:80\\/DCIM\\/Camera01\\/VID_20260512_200830_00_131.mp4\"}'),
(118,1778613842746085,'2026-05-12 22:24:02.748979',2,'VIDEO_UPLOADED','TOUR_ORDER',4,'84.166.208.159','okhttp/4.12.0','Загружен video scan','{\"ip\":\"84.166.208.159\",\"user_agent\":\"okhttp\\/4.12.0\",\"method\":\"POST\",\"uri\":\"\\/api\\/mobile.php?action=upload_video_scan\",\"capture_session_id\":12,\"app_scan_uuid\":\"25be3d10-beda-480b-b1c3-bb33ef7a2971\",\"storage_path\":\"orders\\/4\\/sessions\\/1674181c-1f00-4e96-9ea2-1914671e4b74\\/videos\\/25be3d10-beda-480b-b1c3-bb33ef7a2971_VID_20260512_200830_00_131.mp4\",\"size_bytes\":170315002,\"duration_sec\":5,\"local_camera_url\":\"http:\\/\\/192.168.42.1:80\\/DCIM\\/Camera01\\/VID_20260512_200830_00_131.mp4\"}'),
(119,1778613842960814,'2026-05-12 22:24:02.961015',2,'PHOTO_UPLOADED','TOUR_ORDER',4,'84.166.208.159','okhttp/4.12.0','Загружен photo point','{\"ip\":\"84.166.208.159\",\"user_agent\":\"okhttp\\/4.12.0\",\"method\":\"POST\",\"uri\":\"\\/api\\/mobile.php?action=upload_photo_point\",\"capture_session_id\":12,\"app_point_uuid\":\"2d999854-e210-4cd9-adc4-67eaef8457c6\",\"preview_storage_path\":null,\"original_storage_path\":null}'),
(120,1778613842960864,'2026-05-12 22:24:02.961132',2,'PHOTO_UPLOADED','TOUR_ORDER',4,'84.166.208.159','okhttp/4.12.0','Загружен photo point','{\"ip\":\"84.166.208.159\",\"user_agent\":\"okhttp\\/4.12.0\",\"method\":\"POST\",\"uri\":\"\\/api\\/mobile.php?action=upload_photo_point\",\"capture_session_id\":12,\"app_point_uuid\":\"2d999854-e210-4cd9-adc4-67eaef8457c6\",\"preview_storage_path\":null,\"original_storage_path\":null}'),
(121,1778613842960847,'2026-05-12 22:24:02.961256',2,'PHOTO_UPLOADED','TOUR_ORDER',4,'84.166.208.159','okhttp/4.12.0','Загружен photo point','{\"ip\":\"84.166.208.159\",\"user_agent\":\"okhttp\\/4.12.0\",\"method\":\"POST\",\"uri\":\"\\/api\\/mobile.php?action=upload_photo_point\",\"capture_session_id\":12,\"app_point_uuid\":\"2d999854-e210-4cd9-adc4-67eaef8457c6\",\"preview_storage_path\":null,\"original_storage_path\":null}'),
(122,1778613842960917,'2026-05-12 22:24:02.961369',2,'PHOTO_UPLOADED','TOUR_ORDER',4,'84.166.208.159','okhttp/4.12.0','Загружен photo point','{\"ip\":\"84.166.208.159\",\"user_agent\":\"okhttp\\/4.12.0\",\"method\":\"POST\",\"uri\":\"\\/api\\/mobile.php?action=upload_photo_point\",\"capture_session_id\":12,\"app_point_uuid\":\"2d999854-e210-4cd9-adc4-67eaef8457c6\",\"preview_storage_path\":null,\"original_storage_path\":null}'),
(123,1778613842951008,'2026-05-12 22:24:02.961468',2,'PHOTO_UPLOADED','TOUR_ORDER',4,'84.166.208.159','okhttp/4.12.0','Загружен photo point','{\"ip\":\"84.166.208.159\",\"user_agent\":\"okhttp\\/4.12.0\",\"method\":\"POST\",\"uri\":\"\\/api\\/mobile.php?action=upload_photo_point\",\"capture_session_id\":12,\"app_point_uuid\":\"2d999854-e210-4cd9-adc4-67eaef8457c6\",\"preview_storage_path\":null,\"original_storage_path\":null}'),
(124,1778613842961324,'2026-05-12 22:24:02.961467',2,'PHOTO_UPLOADED','TOUR_ORDER',4,'84.166.208.159','okhttp/4.12.0','Загружен photo point','{\"ip\":\"84.166.208.159\",\"user_agent\":\"okhttp\\/4.12.0\",\"method\":\"POST\",\"uri\":\"\\/api\\/mobile.php?action=upload_photo_point\",\"capture_session_id\":12,\"app_point_uuid\":\"2d999854-e210-4cd9-adc4-67eaef8457c6\",\"preview_storage_path\":null,\"original_storage_path\":null}'),
(125,1778613842962584,'2026-05-12 22:24:02.962792',2,'PHOTO_UPLOADED','TOUR_ORDER',4,'84.166.208.159','okhttp/4.12.0','Загружен photo point','{\"ip\":\"84.166.208.159\",\"user_agent\":\"okhttp\\/4.12.0\",\"method\":\"POST\",\"uri\":\"\\/api\\/mobile.php?action=upload_photo_point\",\"capture_session_id\":12,\"app_point_uuid\":\"2d999854-e210-4cd9-adc4-67eaef8457c6\",\"preview_storage_path\":\"orders\\/4\\/sessions\\/1674181c-1f00-4e96-9ea2-1914671e4b74\\/photos\\/previews\\/2d999854-e210-4cd9-adc4-67eaef8457c6_2d999854-e210-4cd9-adc4-67eaef8457c6.jpg\",\"original_storage_path\":null}'),
(126,1778613842962702,'2026-05-12 22:24:02.963061',2,'PHOTO_UPLOADED','TOUR_ORDER',4,'84.166.208.159','okhttp/4.12.0','Загружен photo point','{\"ip\":\"84.166.208.159\",\"user_agent\":\"okhttp\\/4.12.0\",\"method\":\"POST\",\"uri\":\"\\/api\\/mobile.php?action=upload_photo_point\",\"capture_session_id\":12,\"app_point_uuid\":\"2d999854-e210-4cd9-adc4-67eaef8457c6\",\"preview_storage_path\":\"orders\\/4\\/sessions\\/1674181c-1f00-4e96-9ea2-1914671e4b74\\/photos\\/previews\\/2d999854-e210-4cd9-adc4-67eaef8457c6_2d999854-e210-4cd9-adc4-67eaef8457c6.jpg\",\"original_storage_path\":null}'),
(127,1778613843201228,'2026-05-12 22:24:03.201721',2,'PHOTO_UPLOADED','TOUR_ORDER',4,'84.166.208.159','okhttp/4.12.0','Загружен photo point','{\"ip\":\"84.166.208.159\",\"user_agent\":\"okhttp\\/4.12.0\",\"method\":\"POST\",\"uri\":\"\\/api\\/mobile.php?action=upload_photo_point\",\"capture_session_id\":12,\"app_point_uuid\":\"2d999854-e210-4cd9-adc4-67eaef8457c6\",\"preview_storage_path\":\"orders\\/4\\/sessions\\/1674181c-1f00-4e96-9ea2-1914671e4b74\\/photos\\/previews\\/2d999854-e210-4cd9-adc4-67eaef8457c6_2d999854-e210-4cd9-adc4-67eaef8457c6.jpg\",\"original_storage_path\":null}'),
(128,1778613843217789,'2026-05-12 22:24:03.218204',2,'PHOTO_UPLOADED','TOUR_ORDER',4,'84.166.208.159','okhttp/4.12.0','Загружен photo point','{\"ip\":\"84.166.208.159\",\"user_agent\":\"okhttp\\/4.12.0\",\"method\":\"POST\",\"uri\":\"\\/api\\/mobile.php?action=upload_photo_point\",\"capture_session_id\":12,\"app_point_uuid\":\"2d999854-e210-4cd9-adc4-67eaef8457c6\",\"preview_storage_path\":\"orders\\/4\\/sessions\\/1674181c-1f00-4e96-9ea2-1914671e4b74\\/photos\\/previews\\/2d999854-e210-4cd9-adc4-67eaef8457c6_2d999854-e210-4cd9-adc4-67eaef8457c6.jpg\",\"original_storage_path\":null}'),
(129,1778613843217820,'2026-05-12 22:24:03.218221',2,'PHOTO_UPLOADED','TOUR_ORDER',4,'84.166.208.159','okhttp/4.12.0','Загружен photo point','{\"ip\":\"84.166.208.159\",\"user_agent\":\"okhttp\\/4.12.0\",\"method\":\"POST\",\"uri\":\"\\/api\\/mobile.php?action=upload_photo_point\",\"capture_session_id\":12,\"app_point_uuid\":\"2d999854-e210-4cd9-adc4-67eaef8457c6\",\"preview_storage_path\":\"orders\\/4\\/sessions\\/1674181c-1f00-4e96-9ea2-1914671e4b74\\/photos\\/previews\\/2d999854-e210-4cd9-adc4-67eaef8457c6_2d999854-e210-4cd9-adc4-67eaef8457c6.jpg\",\"original_storage_path\":null}'),
(130,1778613843217823,'2026-05-12 22:24:03.218208',2,'PHOTO_UPLOADED','TOUR_ORDER',4,'84.166.208.159','okhttp/4.12.0','Загружен photo point','{\"ip\":\"84.166.208.159\",\"user_agent\":\"okhttp\\/4.12.0\",\"method\":\"POST\",\"uri\":\"\\/api\\/mobile.php?action=upload_photo_point\",\"capture_session_id\":12,\"app_point_uuid\":\"2d999854-e210-4cd9-adc4-67eaef8457c6\",\"preview_storage_path\":\"orders\\/4\\/sessions\\/1674181c-1f00-4e96-9ea2-1914671e4b74\\/photos\\/previews\\/2d999854-e210-4cd9-adc4-67eaef8457c6_2d999854-e210-4cd9-adc4-67eaef8457c6.jpg\",\"original_storage_path\":null}'),
(131,1778616018731033,'2026-05-12 23:00:18.731370',2,'MOBILE_APP_OPEN','USER',2,'84.166.208.159','okhttp/4.12.0','Открытие мобильного приложения','{\"ip\":\"84.166.208.159\",\"user_agent\":\"okhttp\\/4.12.0\",\"method\":\"POST\",\"uri\":\"\\/api\\/mobile.php?action=ping\"}'),
(132,1778616077790459,'2026-05-12 23:01:17.790872',2,'VIDEO_UPLOADED','TOUR_ORDER',4,'84.166.208.159','okhttp/4.12.0','Загружен video scan','{\"ip\":\"84.166.208.159\",\"user_agent\":\"okhttp\\/4.12.0\",\"method\":\"POST\",\"uri\":\"\\/api\\/mobile.php?action=upload_video_scan\",\"capture_session_id\":12,\"app_scan_uuid\":\"25be3d10-beda-480b-b1c3-bb33ef7a2971\",\"storage_path\":\"orders\\/4\\/sessions\\/1674181c-1f00-4e96-9ea2-1914671e4b74\\/videos\\/25be3d10-beda-480b-b1c3-bb33ef7a2971_VID_20260512_200830_00_131.mp4\",\"size_bytes\":170315002,\"duration_sec\":5,\"local_camera_url\":\"http:\\/\\/192.168.42.1:80\\/DCIM\\/Camera01\\/VID_20260512_200830_00_131.mp4\"}'),
(133,1778616083124748,'2026-05-12 23:01:23.125197',2,'PHOTO_UPLOADED','TOUR_ORDER',4,'84.166.208.159','okhttp/4.12.0','Загружен photo point','{\"ip\":\"84.166.208.159\",\"user_agent\":\"okhttp\\/4.12.0\",\"method\":\"POST\",\"uri\":\"\\/api\\/mobile.php?action=upload_photo_point\",\"capture_session_id\":12,\"app_point_uuid\":\"2d999854-e210-4cd9-adc4-67eaef8457c6\",\"preview_storage_path\":\"orders\\/4\\/sessions\\/1674181c-1f00-4e96-9ea2-1914671e4b74\\/photos\\/previews\\/2d999854-e210-4cd9-adc4-67eaef8457c6_2d999854-e210-4cd9-adc4-67eaef8457c6.jpg\",\"original_storage_path\":\"orders\\/4\\/sessions\\/1674181c-1f00-4e96-9ea2-1914671e4b74\\/photos\\/originals\\/2d999854-e210-4cd9-adc4-67eaef8457c6_2d999854-e210-4cd9-adc4-67eaef8457c6.jpg\"}'),
(134,1778616088406060,'2026-05-12 23:01:28.416768',2,'PHOTO_UPLOADED','TOUR_ORDER',4,'84.166.208.159','okhttp/4.12.0','Загружен photo point','{\"ip\":\"84.166.208.159\",\"user_agent\":\"okhttp\\/4.12.0\",\"method\":\"POST\",\"uri\":\"\\/api\\/mobile.php?action=upload_photo_point\",\"capture_session_id\":12,\"app_point_uuid\":\"605149a9-12b4-4cf0-af7a-3b3842728a5f\",\"preview_storage_path\":\"orders\\/4\\/sessions\\/1674181c-1f00-4e96-9ea2-1914671e4b74\\/photos\\/previews\\/605149a9-12b4-4cf0-af7a-3b3842728a5f_605149a9-12b4-4cf0-af7a-3b3842728a5f.jpg\",\"original_storage_path\":\"orders\\/4\\/sessions\\/1674181c-1f00-4e96-9ea2-1914671e4b74\\/photos\\/originals\\/605149a9-12b4-4cf0-af7a-3b3842728a5f_605149a9-12b4-4cf0-af7a-3b3842728a5f.jpg\"}'),
(135,1778616311426258,'2026-05-12 23:05:11.426548',2,'ORDER_TAKEN','TOUR_ORDER',2,'84.166.208.159','okhttp/4.12.0','Заявка взята в работу',NULL),
(136,1778616587169863,'2026-05-12 23:09:47.170056',2,'VIDEO_UPLOADED','TOUR_ORDER',2,'84.166.208.159','okhttp/4.12.0','Загружен video scan','{\"ip\":\"84.166.208.159\",\"user_agent\":\"okhttp\\/4.12.0\",\"method\":\"POST\",\"uri\":\"\\/api\\/mobile.php?action=upload_video_scan\",\"capture_session_id\":29,\"app_scan_uuid\":\"c28c048f-cd78-4207-bcbf-bf4e0da7725c\",\"storage_path\":\"orders\\/2\\/sessions\\/86476880-f49d-4755-ba71-6b1f8e9b9072\\/videos\\/c28c048f-cd78-4207-bcbf-bf4e0da7725c_VID_20260512_210641_00_133.mp4\",\"size_bytes\":126274810,\"duration_sec\":2,\"local_camera_url\":\"http:\\/\\/192.168.42.1:80\\/DCIM\\/Camera01\\/VID_20260512_210641_00_133.mp4\"}'),
(137,1778616592369697,'2026-05-12 23:09:52.369939',2,'PHOTO_UPLOADED','TOUR_ORDER',2,'84.166.208.159','okhttp/4.12.0','Загружен photo point','{\"ip\":\"84.166.208.159\",\"user_agent\":\"okhttp\\/4.12.0\",\"method\":\"POST\",\"uri\":\"\\/api\\/mobile.php?action=upload_photo_point\",\"capture_session_id\":29,\"app_point_uuid\":\"ca5d2b74-2d79-4630-886c-9103cfa0acde\",\"preview_storage_path\":\"orders\\/2\\/sessions\\/86476880-f49d-4755-ba71-6b1f8e9b9072\\/photos\\/previews\\/ca5d2b74-2d79-4630-886c-9103cfa0acde_ca5d2b74-2d79-4630-886c-9103cfa0acde.jpg\",\"original_storage_path\":\"orders\\/2\\/sessions\\/86476880-f49d-4755-ba71-6b1f8e9b9072\\/photos\\/originals\\/ca5d2b74-2d79-4630-886c-9103cfa0acde_ca5d2b74-2d79-4630-886c-9103cfa0acde.jpg\"}'),
(138,1778655343750764,'2026-05-13 09:55:43.751107',2,'MOBILE_APP_OPEN','USER',2,'84.166.208.159','okhttp/4.12.0','Открытие мобильного приложения','{\"ip\":\"84.166.208.159\",\"user_agent\":\"okhttp\\/4.12.0\",\"method\":\"POST\",\"uri\":\"\\/api\\/mobile.php?action=ping\"}'),
(139,1778661697946527,'2026-05-13 11:41:37.946925',2,'VIDEO_UPLOADED','TOUR_ORDER',2,'84.166.208.159','okhttp/4.12.0','Загружен video scan','{\"ip\":\"84.166.208.159\",\"user_agent\":\"okhttp\\/4.12.0\",\"method\":\"POST\",\"uri\":\"\\/api\\/mobile.php?action=upload_video_scan\",\"capture_session_id\":29,\"app_scan_uuid\":\"c28c048f-cd78-4207-bcbf-bf4e0da7725c\",\"storage_path\":\"orders\\/2\\/sessions\\/86476880-f49d-4755-ba71-6b1f8e9b9072\\/videos\\/c28c048f-cd78-4207-bcbf-bf4e0da7725c_VID_20260512_210641_00_133.mp4\",\"size_bytes\":126274810,\"duration_sec\":2,\"local_camera_url\":\"http:\\/\\/192.168.42.1:80\\/DCIM\\/Camera01\\/VID_20260512_210641_00_133.mp4\"}'),
(140,1778661700702912,'2026-05-13 11:41:40.744749',2,'PHOTO_UPLOADED','TOUR_ORDER',2,'84.166.208.159','okhttp/4.12.0','Загружен photo point','{\"ip\":\"84.166.208.159\",\"user_agent\":\"okhttp\\/4.12.0\",\"method\":\"POST\",\"uri\":\"\\/api\\/mobile.php?action=upload_photo_point\",\"capture_session_id\":29,\"app_point_uuid\":\"ca5d2b74-2d79-4630-886c-9103cfa0acde\",\"preview_storage_path\":\"orders\\/2\\/sessions\\/86476880-f49d-4755-ba71-6b1f8e9b9072\\/photos\\/previews\\/ca5d2b74-2d79-4630-886c-9103cfa0acde_ca5d2b74-2d79-4630-886c-9103cfa0acde.jpg\",\"original_storage_path\":null}'),
(141,1778665811039617,'2026-05-13 12:50:11.039910',2,'MOBILE_APP_OPEN','USER',2,'84.166.208.159','okhttp/4.12.0','Открытие мобильного приложения','{\"ip\":\"84.166.208.159\",\"user_agent\":\"okhttp\\/4.12.0\",\"method\":\"POST\",\"uri\":\"\\/api\\/mobile.php?action=ping\"}'),
(142,1778665846869853,'2026-05-13 12:50:46.870365',2,'VIDEO_UPLOADED','TOUR_ORDER',4,'84.166.208.159','okhttp/4.12.0','Загружен video scan','{\"ip\":\"84.166.208.159\",\"user_agent\":\"okhttp\\/4.12.0\",\"method\":\"POST\",\"uri\":\"\\/api\\/mobile.php?action=upload_video_scan\",\"capture_session_id\":12,\"app_scan_uuid\":\"25be3d10-beda-480b-b1c3-bb33ef7a2971\",\"storage_path\":\"orders\\/4\\/sessions\\/1674181c-1f00-4e96-9ea2-1914671e4b74\\/videos\\/25be3d10-beda-480b-b1c3-bb33ef7a2971_VID_20260512_200830_00_131.mp4\",\"size_bytes\":170315002,\"duration_sec\":5,\"local_camera_url\":\"http:\\/\\/192.168.42.1:80\\/DCIM\\/Camera01\\/VID_20260512_200830_00_131.mp4\"}'),
(143,1778665852346103,'2026-05-13 12:50:52.346451',2,'PHOTO_UPLOADED','TOUR_ORDER',4,'84.166.208.159','okhttp/4.12.0','Загружен photo point','{\"ip\":\"84.166.208.159\",\"user_agent\":\"okhttp\\/4.12.0\",\"method\":\"POST\",\"uri\":\"\\/api\\/mobile.php?action=upload_photo_point\",\"capture_session_id\":12,\"app_point_uuid\":\"2d999854-e210-4cd9-adc4-67eaef8457c6\",\"preview_storage_path\":\"orders\\/4\\/sessions\\/1674181c-1f00-4e96-9ea2-1914671e4b74\\/photos\\/previews\\/2d999854-e210-4cd9-adc4-67eaef8457c6_2d999854-e210-4cd9-adc4-67eaef8457c6.jpg\",\"original_storage_path\":\"orders\\/4\\/sessions\\/1674181c-1f00-4e96-9ea2-1914671e4b74\\/photos\\/originals\\/2d999854-e210-4cd9-adc4-67eaef8457c6_2d999854-e210-4cd9-adc4-67eaef8457c6.jpg\"}'),
(144,1778665857621670,'2026-05-13 12:50:57.622914',2,'PHOTO_UPLOADED','TOUR_ORDER',4,'84.166.208.159','okhttp/4.12.0','Загружен photo point','{\"ip\":\"84.166.208.159\",\"user_agent\":\"okhttp\\/4.12.0\",\"method\":\"POST\",\"uri\":\"\\/api\\/mobile.php?action=upload_photo_point\",\"capture_session_id\":12,\"app_point_uuid\":\"605149a9-12b4-4cf0-af7a-3b3842728a5f\",\"preview_storage_path\":\"orders\\/4\\/sessions\\/1674181c-1f00-4e96-9ea2-1914671e4b74\\/photos\\/previews\\/605149a9-12b4-4cf0-af7a-3b3842728a5f_605149a9-12b4-4cf0-af7a-3b3842728a5f.jpg\",\"original_storage_path\":\"orders\\/4\\/sessions\\/1674181c-1f00-4e96-9ea2-1914671e4b74\\/photos\\/originals\\/605149a9-12b4-4cf0-af7a-3b3842728a5f_605149a9-12b4-4cf0-af7a-3b3842728a5f.jpg\"}'),
(145,1778667151131461,'2026-05-13 13:12:31.131837',1,'LOGIN',NULL,NULL,'84.166.208.159','Mozilla/5.0 (X11; Linux x86_64; rv:145.0) Gecko/20100101 Firefox/145.0','Пользователь вошёл в систему',NULL),
(146,1778670423890624,'2026-05-13 14:07:03.891265',2,'MOBILE_APP_OPEN','USER',2,'84.166.208.159','okhttp/4.12.0','Открытие мобильного приложения','{\"ip\":\"84.166.208.159\",\"user_agent\":\"okhttp\\/4.12.0\",\"method\":\"POST\",\"uri\":\"\\/api\\/mobile.php?action=ping\"}'),
(147,1778674671604893,'2026-05-13 15:17:51.605163',2,'MOBILE_APP_OPEN','USER',2,'61.8.135.202','okhttp/4.12.0','Открытие мобильного приложения','{\"ip\":\"61.8.135.202\",\"user_agent\":\"okhttp\\/4.12.0\",\"method\":\"POST\",\"uri\":\"\\/api\\/mobile.php?action=ping\"}'),
(148,1778675206700122,'2026-05-13 15:26:46.700594',2,'VIDEO_UPLOADED','TOUR_ORDER',4,'61.8.135.202','okhttp/4.12.0','Загружен video scan','{\"ip\":\"61.8.135.202\",\"user_agent\":\"okhttp\\/4.12.0\",\"method\":\"POST\",\"uri\":\"\\/api\\/mobile.php?action=upload_video_scan\",\"capture_session_id\":30,\"app_scan_uuid\":\"8930d2b2-040e-4000-b165-023dad4f9a85\",\"storage_path\":\"orders\\/4\\/sessions\\/075674c9-1715-44b0-b014-d8e10a935350\\/videos\\/8930d2b2-040e-4000-b165-023dad4f9a85_VID_20260513_120807_00_135.mp4\",\"size_bytes\":356699388,\"duration_sec\":17,\"local_camera_url\":\"http:\\/\\/192.168.42.1:80\\/DCIM\\/Camera01\\/VID_20260513_120807_00_135.mp4\"}'),
(149,1778675212656240,'2026-05-13 15:26:52.656447',2,'PHOTO_UPLOADED','TOUR_ORDER',4,'61.8.135.202','okhttp/4.12.0','Загружен photo point','{\"ip\":\"61.8.135.202\",\"user_agent\":\"okhttp\\/4.12.0\",\"method\":\"POST\",\"uri\":\"\\/api\\/mobile.php?action=upload_photo_point\",\"capture_session_id\":30,\"app_point_uuid\":\"8d02f0d7-2db1-42a9-8a49-166913ecd7ce\",\"preview_storage_path\":\"orders\\/4\\/sessions\\/075674c9-1715-44b0-b014-d8e10a935350\\/photos\\/previews\\/8d02f0d7-2db1-42a9-8a49-166913ecd7ce_8d02f0d7-2db1-42a9-8a49-166913ecd7ce.jpg\",\"original_storage_path\":\"orders\\/4\\/sessions\\/075674c9-1715-44b0-b014-d8e10a935350\\/photos\\/originals\\/8d02f0d7-2db1-42a9-8a49-166913ecd7ce_8d02f0d7-2db1-42a9-8a49-166913ecd7ce.jpg\"}'),
(150,1778675230965698,'2026-05-13 15:27:10.965973',1,'LOGIN',NULL,NULL,'84.166.208.159','Mozilla/5.0 (X11; Linux x86_64; rv:145.0) Gecko/20100101 Firefox/145.0','Пользователь вошёл в систему',NULL),
(151,1778675550880976,'2026-05-13 15:32:30.881240',2,'MOBILE_APP_OPEN','USER',2,'61.8.135.202','okhttp/4.12.0','Открытие мобильного приложения','{\"ip\":\"61.8.135.202\",\"user_agent\":\"okhttp\\/4.12.0\",\"method\":\"POST\",\"uri\":\"\\/api\\/mobile.php?action=ping\"}'),
(152,1778676669289146,'2026-05-13 15:51:09.289451',2,'MOBILE_APP_OPEN','USER',2,'61.8.131.250','okhttp/4.12.0','Открытие мобильного приложения','{\"ip\":\"61.8.131.250\",\"user_agent\":\"okhttp\\/4.12.0\",\"method\":\"POST\",\"uri\":\"\\/api\\/mobile.php?action=ping\"}'),
(153,1778679052948712,'2026-05-13 16:30:52.949695',2,'PHOTO_UPLOADED','TOUR_ORDER',3,'84.166.208.159','okhttp/4.12.0','Загружен photo point','{\"ip\":\"84.166.208.159\",\"user_agent\":\"okhttp\\/4.12.0\",\"method\":\"POST\",\"uri\":\"\\/api\\/mobile.php?action=upload_photo_point\",\"capture_session_id\":31,\"app_point_uuid\":\"07d23fbc-a181-4532-822f-f9a6ed9b39e7\",\"preview_storage_path\":\"orders\\/3\\/sessions\\/0a4d3b10-341d-463f-b25b-ac1f9e0c5e02\\/photos\\/previews\\/07d23fbc-a181-4532-822f-f9a6ed9b39e7_07d23fbc-a181-4532-822f-f9a6ed9b39e7.jpg\",\"original_storage_path\":\"orders\\/3\\/sessions\\/0a4d3b10-341d-463f-b25b-ac1f9e0c5e02\\/photos\\/originals\\/07d23fbc-a181-4532-822f-f9a6ed9b39e7_07d23fbc-a181-4532-822f-f9a6ed9b39e7.jpg\"}'),
(154,1778679058154867,'2026-05-13 16:30:58.155465',2,'PHOTO_UPLOADED','TOUR_ORDER',3,'84.166.208.159','okhttp/4.12.0','Загружен photo point','{\"ip\":\"84.166.208.159\",\"user_agent\":\"okhttp\\/4.12.0\",\"method\":\"POST\",\"uri\":\"\\/api\\/mobile.php?action=upload_photo_point\",\"capture_session_id\":31,\"app_point_uuid\":\"14feebb2-9f5f-4ff8-87ad-ff9c4b972892\",\"preview_storage_path\":\"orders\\/3\\/sessions\\/0a4d3b10-341d-463f-b25b-ac1f9e0c5e02\\/photos\\/previews\\/14feebb2-9f5f-4ff8-87ad-ff9c4b972892_14feebb2-9f5f-4ff8-87ad-ff9c4b972892.jpg\",\"original_storage_path\":\"orders\\/3\\/sessions\\/0a4d3b10-341d-463f-b25b-ac1f9e0c5e02\\/photos\\/originals\\/14feebb2-9f5f-4ff8-87ad-ff9c4b972892_14feebb2-9f5f-4ff8-87ad-ff9c4b972892.jpg\"}'),
(155,1778683059151892,'2026-05-13 17:37:39.152177',2,'MOBILE_APP_OPEN','USER',2,'84.166.208.159','okhttp/4.12.0','Открытие мобильного приложения','{\"ip\":\"84.166.208.159\",\"user_agent\":\"okhttp\\/4.12.0\",\"method\":\"POST\",\"uri\":\"\\/api\\/mobile.php?action=ping\"}'),
(156,1778685254374345,'2026-05-13 18:14:14.374778',1,'LOGIN',NULL,NULL,'84.166.208.159','Mozilla/5.0 (X11; Linux x86_64; rv:145.0) Gecko/20100101 Firefox/145.0','Пользователь вошёл в систему',NULL),
(157,1778689643184113,'2026-05-13 19:27:23.184597',1,'LOGIN',NULL,NULL,'84.166.208.159','Mozilla/5.0 (X11; Linux x86_64; rv:145.0) Gecko/20100101 Firefox/145.0','Пользователь вошёл в систему',NULL),
(158,1778700145742329,'2026-05-13 22:22:25.742811',1,'LOGIN',NULL,NULL,'84.166.208.159','Mozilla/5.0 (X11; Linux x86_64; rv:145.0) Gecko/20100101 Firefox/145.0','Пользователь вошёл в систему',NULL),
(159,1778702950784657,'2026-05-13 23:09:10.785076',1,'LOGIN',NULL,NULL,'84.166.208.159','Mozilla/5.0 (X11; Linux x86_64; rv:145.0) Gecko/20100101 Firefox/145.0','Пользователь вошёл в систему',NULL),
(160,1778752628665788,'2026-05-14 12:57:08.666348',1,'LOGIN',NULL,NULL,'84.166.208.159','Mozilla/5.0 (X11; Linux x86_64; rv:145.0) Gecko/20100101 Firefox/145.0','Пользователь вошёл в систему',NULL),
(161,1778755584143998,'2026-05-14 13:46:24.145952',1,'PROCESSING_JOB_CREATED_WEB','TOUR_ORDER',4,'84.166.208.159','Mozilla/5.0 (X11; Linux x86_64; rv:145.0) Gecko/20100101 Firefox/145.0','Создана задача обработки marker detection из web','{\"capture_session_id\":3,\"job_type\":\"MARKER_DETECTION\"}'),
(162,1778755596556723,'2026-05-14 13:46:36.557025',1,'PROCESSING_JOB_CREATED_WEB','TOUR_ORDER',4,'84.166.208.159','Mozilla/5.0 (X11; Linux x86_64; rv:145.0) Gecko/20100101 Firefox/145.0','Создана задача обработки marker detection из web','{\"capture_session_id\":12,\"job_type\":\"MARKER_DETECTION\"}'),
(163,1778757497870771,'2026-05-14 14:18:17.870997',1,'LOGIN',NULL,NULL,'84.166.208.159','Mozilla/5.0 (X11; Linux x86_64; rv:145.0) Gecko/20100101 Firefox/145.0','Пользователь вошёл в систему',NULL),
(164,1778764238904408,'2026-05-14 16:10:38.967241',1,'ORDER_CREATED','TOUR_ORDER',5,'84.166.208.159','Mozilla/5.0 (X11; Linux x86_64; rv:145.0) Gecko/20100101 Firefox/145.0','Создана заявка','{\"title\":\"Brunhildensteg 16D\",\"address\":\"Brunhildensteg 16D\",\"area_m2\":99,\"is_published\":1}'),
(165,1778764267466572,'2026-05-14 16:11:07.466880',2,'ORDER_TAKEN','TOUR_ORDER',5,'61.8.134.56','okhttp/4.12.0','Заявка взята в работу',NULL),
(166,1778765063554415,'2026-05-14 16:24:23.557297',2,'VIDEO_UPLOADED','TOUR_ORDER',5,'84.166.208.159','okhttp/4.12.0','Загружен video scan','{\"ip\":\"84.166.208.159\",\"user_agent\":\"okhttp\\/4.12.0\",\"method\":\"POST\",\"uri\":\"\\/api\\/mobile.php?action=upload_video_scan\",\"capture_session_id\":32,\"app_scan_uuid\":\"2144e047-f718-402b-88da-77d6485ba18c\",\"storage_path\":\"orders\\/5\\/sessions\\/6c81ff4c-3cbc-4808-a168-75c9048bec14\\/videos\\/2144e047-f718-402b-88da-77d6485ba18c_VID_20260514_141105_00_138.mp4\",\"size_bytes\":1115081980,\"duration_sec\":60,\"local_camera_url\":\"http:\\/\\/192.168.42.1:80\\/DCIM\\/Camera01\\/VID_20260514_141105_00_138.mp4\"}'),
(167,1778765063558529,'2026-05-14 16:24:23.558917',2,'VIDEO_UPLOADED','TOUR_ORDER',5,'84.166.208.159','okhttp/4.12.0','Загружен video scan','{\"ip\":\"84.166.208.159\",\"user_agent\":\"okhttp\\/4.12.0\",\"method\":\"POST\",\"uri\":\"\\/api\\/mobile.php?action=upload_video_scan\",\"capture_session_id\":32,\"app_scan_uuid\":\"2144e047-f718-402b-88da-77d6485ba18c\",\"storage_path\":\"orders\\/5\\/sessions\\/6c81ff4c-3cbc-4808-a168-75c9048bec14\\/videos\\/2144e047-f718-402b-88da-77d6485ba18c_VID_20260514_141105_00_138.mp4\",\"size_bytes\":1115081980,\"duration_sec\":60,\"local_camera_url\":\"http:\\/\\/192.168.42.1:80\\/DCIM\\/Camera01\\/VID_20260514_141105_00_138.mp4\"}'),
(168,1778765068726741,'2026-05-14 16:24:28.728733',2,'PHOTO_UPLOADED','TOUR_ORDER',5,'84.166.208.159','okhttp/4.12.0','Загружен photo point','{\"ip\":\"84.166.208.159\",\"user_agent\":\"okhttp\\/4.12.0\",\"method\":\"POST\",\"uri\":\"\\/api\\/mobile.php?action=upload_photo_point\",\"capture_session_id\":32,\"app_point_uuid\":\"2ae7d953-1ac2-4749-b79c-42a9dd783ab2\",\"preview_storage_path\":\"orders\\/5\\/sessions\\/6c81ff4c-3cbc-4808-a168-75c9048bec14\\/photos\\/previews\\/2ae7d953-1ac2-4749-b79c-42a9dd783ab2_2ae7d953-1ac2-4749-b79c-42a9dd783ab2.jpg\",\"original_storage_path\":\"orders\\/5\\/sessions\\/6c81ff4c-3cbc-4808-a168-75c9048bec14\\/photos\\/originals\\/2ae7d953-1ac2-4749-b79c-42a9dd783ab2_2ae7d953-1ac2-4749-b79c-42a9dd783ab2.jpg\"}'),
(169,1778765073840081,'2026-05-14 16:24:33.840306',2,'PHOTO_UPLOADED','TOUR_ORDER',5,'84.166.208.159','okhttp/4.12.0','Загружен photo point','{\"ip\":\"84.166.208.159\",\"user_agent\":\"okhttp\\/4.12.0\",\"method\":\"POST\",\"uri\":\"\\/api\\/mobile.php?action=upload_photo_point\",\"capture_session_id\":32,\"app_point_uuid\":\"aa339941-49d4-402c-820a-187cf26364f0\",\"preview_storage_path\":\"orders\\/5\\/sessions\\/6c81ff4c-3cbc-4808-a168-75c9048bec14\\/photos\\/previews\\/aa339941-49d4-402c-820a-187cf26364f0_aa339941-49d4-402c-820a-187cf26364f0.jpg\",\"original_storage_path\":\"orders\\/5\\/sessions\\/6c81ff4c-3cbc-4808-a168-75c9048bec14\\/photos\\/originals\\/aa339941-49d4-402c-820a-187cf26364f0_aa339941-49d4-402c-820a-187cf26364f0.jpg\"}'),
(170,1778765079041813,'2026-05-14 16:24:39.042274',2,'PHOTO_UPLOADED','TOUR_ORDER',5,'84.166.208.159','okhttp/4.12.0','Загружен photo point','{\"ip\":\"84.166.208.159\",\"user_agent\":\"okhttp\\/4.12.0\",\"method\":\"POST\",\"uri\":\"\\/api\\/mobile.php?action=upload_photo_point\",\"capture_session_id\":32,\"app_point_uuid\":\"69a5da20-988a-46e9-84fa-cc91f7915cf8\",\"preview_storage_path\":\"orders\\/5\\/sessions\\/6c81ff4c-3cbc-4808-a168-75c9048bec14\\/photos\\/previews\\/69a5da20-988a-46e9-84fa-cc91f7915cf8_69a5da20-988a-46e9-84fa-cc91f7915cf8.jpg\",\"original_storage_path\":\"orders\\/5\\/sessions\\/6c81ff4c-3cbc-4808-a168-75c9048bec14\\/photos\\/originals\\/69a5da20-988a-46e9-84fa-cc91f7915cf8_69a5da20-988a-46e9-84fa-cc91f7915cf8.jpg\"}'),
(171,1778765084146566,'2026-05-14 16:24:44.146753',2,'PHOTO_UPLOADED','TOUR_ORDER',5,'84.166.208.159','okhttp/4.12.0','Загружен photo point','{\"ip\":\"84.166.208.159\",\"user_agent\":\"okhttp\\/4.12.0\",\"method\":\"POST\",\"uri\":\"\\/api\\/mobile.php?action=upload_photo_point\",\"capture_session_id\":32,\"app_point_uuid\":\"ac65595b-6a32-4066-a8f8-6d77cf017b2f\",\"preview_storage_path\":\"orders\\/5\\/sessions\\/6c81ff4c-3cbc-4808-a168-75c9048bec14\\/photos\\/previews\\/ac65595b-6a32-4066-a8f8-6d77cf017b2f_ac65595b-6a32-4066-a8f8-6d77cf017b2f.jpg\",\"original_storage_path\":\"orders\\/5\\/sessions\\/6c81ff4c-3cbc-4808-a168-75c9048bec14\\/photos\\/originals\\/ac65595b-6a32-4066-a8f8-6d77cf017b2f_ac65595b-6a32-4066-a8f8-6d77cf017b2f.jpg\"}'),
(172,1778765089318645,'2026-05-14 16:24:49.318851',2,'PHOTO_UPLOADED','TOUR_ORDER',5,'84.166.208.159','okhttp/4.12.0','Загружен photo point','{\"ip\":\"84.166.208.159\",\"user_agent\":\"okhttp\\/4.12.0\",\"method\":\"POST\",\"uri\":\"\\/api\\/mobile.php?action=upload_photo_point\",\"capture_session_id\":32,\"app_point_uuid\":\"2db840c4-3e28-4cea-92b9-157544994178\",\"preview_storage_path\":\"orders\\/5\\/sessions\\/6c81ff4c-3cbc-4808-a168-75c9048bec14\\/photos\\/previews\\/2db840c4-3e28-4cea-92b9-157544994178_2db840c4-3e28-4cea-92b9-157544994178.jpg\",\"original_storage_path\":\"orders\\/5\\/sessions\\/6c81ff4c-3cbc-4808-a168-75c9048bec14\\/photos\\/originals\\/2db840c4-3e28-4cea-92b9-157544994178_2db840c4-3e28-4cea-92b9-157544994178.jpg\"}'),
(173,1778765094461277,'2026-05-14 16:24:54.461722',2,'PHOTO_UPLOADED','TOUR_ORDER',5,'84.166.208.159','okhttp/4.12.0','Загружен photo point','{\"ip\":\"84.166.208.159\",\"user_agent\":\"okhttp\\/4.12.0\",\"method\":\"POST\",\"uri\":\"\\/api\\/mobile.php?action=upload_photo_point\",\"capture_session_id\":32,\"app_point_uuid\":\"99032573-6d7d-434a-af6b-a65a80ce9922\",\"preview_storage_path\":\"orders\\/5\\/sessions\\/6c81ff4c-3cbc-4808-a168-75c9048bec14\\/photos\\/previews\\/99032573-6d7d-434a-af6b-a65a80ce9922_99032573-6d7d-434a-af6b-a65a80ce9922.jpg\",\"original_storage_path\":\"orders\\/5\\/sessions\\/6c81ff4c-3cbc-4808-a168-75c9048bec14\\/photos\\/originals\\/99032573-6d7d-434a-af6b-a65a80ce9922_99032573-6d7d-434a-af6b-a65a80ce9922.jpg\"}'),
(174,1778765099695937,'2026-05-14 16:24:59.696152',2,'PHOTO_UPLOADED','TOUR_ORDER',5,'84.166.208.159','okhttp/4.12.0','Загружен photo point','{\"ip\":\"84.166.208.159\",\"user_agent\":\"okhttp\\/4.12.0\",\"method\":\"POST\",\"uri\":\"\\/api\\/mobile.php?action=upload_photo_point\",\"capture_session_id\":32,\"app_point_uuid\":\"cee6d76b-85e1-4b69-bdb9-a33be7cd26eb\",\"preview_storage_path\":\"orders\\/5\\/sessions\\/6c81ff4c-3cbc-4808-a168-75c9048bec14\\/photos\\/previews\\/cee6d76b-85e1-4b69-bdb9-a33be7cd26eb_cee6d76b-85e1-4b69-bdb9-a33be7cd26eb.jpg\",\"original_storage_path\":\"orders\\/5\\/sessions\\/6c81ff4c-3cbc-4808-a168-75c9048bec14\\/photos\\/originals\\/cee6d76b-85e1-4b69-bdb9-a33be7cd26eb_cee6d76b-85e1-4b69-bdb9-a33be7cd26eb.jpg\"}'),
(175,1778829549679058,'2026-05-15 10:19:09.679477',1,'LOGIN',NULL,NULL,'84.166.208.159','Mozilla/5.0 (X11; Linux x86_64; rv:145.0) Gecko/20100101 Firefox/145.0','Пользователь вошёл в систему',NULL),
(176,1778833744091924,'2026-05-15 11:29:04.092154',1,'LOGIN',NULL,NULL,'84.166.208.159','Mozilla/5.0 (X11; Linux x86_64; rv:145.0) Gecko/20100101 Firefox/145.0','Пользователь вошёл в систему',NULL),
(177,1778834294142369,'2026-05-15 11:38:14.142600',2,'LOGIN',NULL,NULL,'84.166.208.159','Mozilla/5.0 (X11; Linux x86_64; rv:145.0) Gecko/20100101 Firefox/145.0','Пользователь вошёл в систему',NULL);
/*!40000 ALTER TABLE `audit_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `capture_points`
--

DROP TABLE IF EXISTS `capture_points`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `capture_points` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `session_id` bigint(20) unsigned NOT NULL,
  `app_point_uuid` varchar(64) NOT NULL,
  `title` varchar(190) DEFAULT NULL,
  `room_name` varchar(190) DEFAULT NULL,
  `sequence_number` int(11) NOT NULL DEFAULT 0,
  `preview_path` varchar(500) DEFAULT NULL,
  `original_path` varchar(500) DEFAULT NULL,
  `upload_state` enum('LOCAL_ONLY','QUEUED','UPLOADING','UPLOADED','FAILED') NOT NULL DEFAULT 'LOCAL_ONLY',
  `created_at` datetime(6) NOT NULL DEFAULT current_timestamp(6),
  `updated_at` datetime(6) NOT NULL DEFAULT current_timestamp(6) ON UPDATE current_timestamp(6),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_capture_point_app_uuid` (`app_point_uuid`),
  KEY `idx_capture_points_session` (`session_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `capture_points`
--

LOCK TABLES `capture_points` WRITE;
/*!40000 ALTER TABLE `capture_points` DISABLE KEYS */;
/*!40000 ALTER TABLE `capture_points` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `capture_sessions`
--

DROP TABLE IF EXISTS `capture_sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `capture_sessions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `order_id` bigint(20) unsigned NOT NULL,
  `operator_id` bigint(20) unsigned NOT NULL,
  `app_session_uuid` varchar(64) NOT NULL,
  `camera_model` varchar(128) DEFAULT NULL,
  `status` enum('LOCAL_ONLY','CAPTURED','UPLOADING','UPLOADED','PROCESSING','READY','FAILED') NOT NULL DEFAULT 'LOCAL_ONLY',
  `started_at` datetime(6) DEFAULT NULL,
  `completed_at` datetime(6) DEFAULT NULL,
  `created_at` datetime(6) NOT NULL DEFAULT current_timestamp(6),
  `updated_at` datetime(6) NOT NULL DEFAULT current_timestamp(6) ON UPDATE current_timestamp(6),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_capture_session_app_uuid` (`app_session_uuid`),
  KEY `idx_capture_sessions_order` (`order_id`)
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `capture_sessions`
--

LOCK TABLES `capture_sessions` WRITE;
/*!40000 ALTER TABLE `capture_sessions` DISABLE KEYS */;
INSERT INTO `capture_sessions` VALUES
(1,1,1,'test-session-001','Insta360 X4','CAPTURED','2026-05-10 16:44:48.869484',NULL,'2026-05-10 16:44:48.869484','2026-05-10 16:45:44.326718'),
(3,4,2,'test-app-session-001','Insta360 X4','CAPTURED','2026-05-11 15:20:21.690343',NULL,'2026-05-11 15:20:21.690343','2026-05-11 15:20:21.690343'),
(4,4,2,'192c4533-fe07-45e1-881b-c3c41f95a563','','CAPTURED','2026-05-11 16:13:40.465465',NULL,'2026-05-11 16:13:40.465465','2026-05-12 10:22:35.568933'),
(12,4,2,'1674181c-1f00-4e96-9ea2-1914671e4b74','','CAPTURED','2026-05-12 22:11:17.619111',NULL,'2026-05-12 22:11:17.619111','2026-05-12 23:00:41.830156'),
(29,2,2,'86476880-f49d-4755-ba71-6b1f8e9b9072','','CAPTURED','2026-05-12 23:09:21.027778',NULL,'2026-05-12 23:09:21.027778','2026-05-12 23:09:21.027778'),
(30,4,2,'075674c9-1715-44b0-b014-d8e10a935350','','CAPTURED','2026-05-13 15:25:13.136985',NULL,'2026-05-13 15:25:13.136985','2026-05-13 15:25:13.136985'),
(31,3,2,'0a4d3b10-341d-463f-b25b-ac1f9e0c5e02','','CAPTURED','2026-05-13 16:30:47.486042',NULL,'2026-05-13 16:30:47.486042','2026-05-13 16:30:47.486042'),
(32,5,2,'6c81ff4c-3cbc-4808-a168-75c9048bec14','','CAPTURED','2026-05-14 16:19:55.418488',NULL,'2026-05-14 16:19:55.418488','2026-05-14 16:19:55.418488');
/*!40000 ALTER TABLE `capture_sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `form_tokens`
--

DROP TABLE IF EXISTS `form_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `form_tokens` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `token` char(64) NOT NULL,
  `form_name` varchar(64) NOT NULL,
  `is_used` tinyint(1) NOT NULL DEFAULT 0,
  `used_at` datetime(6) DEFAULT NULL,
  `expires_at` datetime(6) NOT NULL,
  `created_at` datetime(6) NOT NULL DEFAULT current_timestamp(6),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_form_token` (`token`),
  KEY `idx_form_tokens_user_form` (`user_id`,`form_name`),
  KEY `idx_form_tokens_expires` (`expires_at`)
) ENGINE=InnoDB AUTO_INCREMENT=125 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `form_tokens`
--

LOCK TABLES `form_tokens` WRITE;
/*!40000 ALTER TABLE `form_tokens` DISABLE KEYS */;
INSERT INTO `form_tokens` VALUES
(1,1,'70e39c97619720617c27858239263787ea88438e93038a65272420ca7682742f','create_order',0,NULL,'2026-05-11 10:48:26.744921','2026-05-11 10:18:26.744921'),
(2,1,'bb7f3708e067321de456b52fa1337cafc2f646bf0df28739874c4c6f00e5ce75','create_order',0,NULL,'2026-05-11 10:48:34.658302','2026-05-11 10:18:34.658302'),
(3,1,'d0f7b88a462d2bff1037197f1733dd099b12c045b3f6b1af9e3991854ee73706','create_order',1,'2026-05-11 10:18:55.503335','2026-05-11 10:48:39.110331','2026-05-11 10:18:39.110331'),
(4,1,'53604655fdc436b64576f9e2d8b68dcec707d6f3a59b44fb04b156573f24ab1f','create_order',0,NULL,'2026-05-11 10:48:55.535303','2026-05-11 10:18:55.535303'),
(5,1,'171b0e07d4604d8203d5636f6576092c8d42e4737041ac5fe3fefbc4fe908ae2','create_order',0,NULL,'2026-05-11 10:49:00.330561','2026-05-11 10:19:00.330561'),
(6,2,'e4d53434d2b75826c9aa53b4514c9bfe2d8cd80e785a421f9df09625ffded036','create_order',0,NULL,'2026-05-11 10:49:32.694566','2026-05-11 10:19:32.694566'),
(7,2,'e36ffba3a473a8f4a0b0cef627df9b497fa47253b0c138bbbdbd1d004b747c7f','create_order',0,NULL,'2026-05-11 10:49:45.257856','2026-05-11 10:19:45.257856'),
(8,1,'1a8dc9ace72f72656cb0def4750899e86707ea358f79f40659a0b9c6d7fad34b','create_order',0,NULL,'2026-05-11 11:28:27.129675','2026-05-11 10:58:27.129675'),
(9,1,'a95be7055096e7f52e947c0e2e68b831611ee87aba22d957bfa5ca0f66f06235','create_order',1,'2026-05-11 10:58:53.542038','2026-05-11 11:28:49.801959','2026-05-11 10:58:49.801959'),
(10,1,'1d9bd1914dfa191e35d0dfe27a1c187072999da2fbfb73ff4147c7f6b6721418','create_order',0,NULL,'2026-05-11 11:28:53.572974','2026-05-11 10:58:53.572974'),
(11,2,'2d98338572ea4af0afb9d46d354c0a9908f7be5393ee4c8ee97378fdcbf5d58b','create_order',0,NULL,'2026-05-11 11:29:23.455463','2026-05-11 10:59:23.455463'),
(12,2,'d280b32ec2f86e110763983dcbe4e27a10f3cdb17fab9a3fe76a417e6ebf8ddc','create_order',0,NULL,'2026-05-11 11:29:26.951611','2026-05-11 10:59:26.951611'),
(13,2,'59ced9aa724bfdd5cb25f2e69ae075fa1285db0b1834433668ac071ba2236f21','create_order',0,NULL,'2026-05-11 11:29:53.561637','2026-05-11 10:59:53.561637'),
(14,2,'fe0364a87bf5d997bf44b272abab54784daa8e60924ede4a8ee8394e56963f08','create_order',1,'2026-05-11 11:00:11.461205','2026-05-11 11:29:59.392220','2026-05-11 10:59:59.392220'),
(15,2,'ba71c7f2c74165cb700876eb831e72ee505efde126637affe1f3da12bc399261','create_order',0,NULL,'2026-05-11 11:30:11.536377','2026-05-11 11:00:11.536377'),
(16,2,'cb19e1cf28ed57db5ccfb23768297b5f4e96daa380110029d0d968a917552c7e','create_order',0,NULL,'2026-05-11 11:30:13.757356','2026-05-11 11:00:13.757356'),
(17,2,'711e72788d0adcdeb9eb86d068858740869bc5b118aa682146816dcd79dd6869','create_order',0,NULL,'2026-05-11 11:30:19.580552','2026-05-11 11:00:19.580552'),
(18,2,'b80573a687f5fc7d9b78f17c6d6832b672d9847217f0ef395980d3c6b63d79cd','create_order',0,NULL,'2026-05-11 11:33:13.835913','2026-05-11 11:03:13.835913'),
(19,2,'31d21d2668662013036ddf13a7b1a402e05e9237356495fafd53c08b37b2c3bb','create_order',0,NULL,'2026-05-11 11:33:16.511969','2026-05-11 11:03:16.511969'),
(20,2,'4a0af1255a97fcb688fdb1cef8711be1953e8f6945b60dd261af4384b4c7cd1c','create_order',0,NULL,'2026-05-11 11:33:19.569949','2026-05-11 11:03:19.569949'),
(21,1,'fe0d5cc50a25fff068765a1916c6f569dcdbef667dfcfa7de47e6f8267cf8559','create_order',0,NULL,'2026-05-11 11:33:30.403187','2026-05-11 11:03:30.403187'),
(22,1,'3dd9bc9460f23eef2642ea32db228c34dc5e43650178d0e873111af24364499a','create_order',0,NULL,'2026-05-11 11:50:55.817247','2026-05-11 11:20:55.817247'),
(23,1,'aa04cf623791f7c16650a997d3c8d94cd0c499a15a5adb49cbe4d04d142354e4','create_order',0,NULL,'2026-05-11 11:51:28.873644','2026-05-11 11:21:28.873644'),
(24,1,'eb8ce33287c20c4fff474b209c514d078aea65703deb90c90cd78b8577207d6b','create_order',0,NULL,'2026-05-11 12:03:30.451218','2026-05-11 11:33:30.451218'),
(25,1,'e3a7fb0a57c912385d358635c4e79fdb0a544cf386def9f6581eb02b2610f9d7','create_order',0,NULL,'2026-05-11 12:03:32.012810','2026-05-11 11:33:32.012810'),
(26,1,'1c7d3ca84a7d06036f78c6f3db61852d2c9e8b20816aeb3b8841598d60f18c15','create_order',0,NULL,'2026-05-11 12:03:53.794214','2026-05-11 11:33:53.794214'),
(27,2,'cd18a2e8946f49f9279475e6973b5bae8de7e072001ff79d41006e5afb637c56','create_order',0,NULL,'2026-05-11 12:09:41.726443','2026-05-11 11:39:41.726443'),
(28,2,'3fac7e3d4055a13c3fc459318e74e18b6a87477544fd1d6f41dcd455f9680924','create_order',0,NULL,'2026-05-11 12:10:19.107012','2026-05-11 11:40:19.107012'),
(29,2,'6cd2842ef8e38dd300017a57e7545b5a4a2a990f8fc628d3e1bb95554f64b4e8','create_order',0,NULL,'2026-05-11 12:10:40.572051','2026-05-11 11:40:40.572051'),
(30,2,'9eca51598ec3a62a285382fe05ad06d0c61fd55c93273faa52002685e38917a8','create_order',0,NULL,'2026-05-11 12:16:11.013727','2026-05-11 11:46:11.013727'),
(31,2,'a5a3014e9359884c6ca02bd0460f2a3495564ab3179e5e8aade983995b8f08c4','create_order',0,NULL,'2026-05-11 12:16:28.263348','2026-05-11 11:46:28.263348'),
(32,2,'719662fa8d295669ae27b1ea048471eb881b4aafb5b5aeeef8e464c1a5076905','create_order',0,NULL,'2026-05-11 12:16:32.286150','2026-05-11 11:46:32.286150'),
(33,1,'6c39a9222f3ae224bca73feb6c367dffaceed556abd37f031e48da1d6e88a8c4','create_order',1,'2026-05-11 11:49:49.322877','2026-05-11 12:19:26.709710','2026-05-11 11:49:26.709710'),
(34,1,'068409b06082c9260f5d493ec0ebc3b6cc718f39cac2902daf4156ab7b61bd5f','create_order',1,'2026-05-11 11:50:29.330789','2026-05-11 12:19:49.354909','2026-05-11 11:49:49.354909'),
(35,2,'67fdd026cd31fd873ade50e6fb625f8d73c4f07b45a416252e0b902cc74db01a','create_order',0,NULL,'2026-05-11 12:19:56.135742','2026-05-11 11:49:56.135742'),
(36,2,'1f371f4b4c81d4ed6a58acb02eb7daaaf98c875f744d261846460f732c8ed7db','create_order',0,NULL,'2026-05-11 12:19:58.204169','2026-05-11 11:49:58.204169'),
(37,2,'309ad7aa37146af051c2be6072c2172f9cba1df62397db88fb85fa56755c2466','create_order',1,'2026-05-11 11:51:12.686531','2026-05-11 12:20:01.754696','2026-05-11 11:50:01.754696'),
(38,1,'c73d16c1ad94d78f0589fa9183ca4a9a187746ae6032eda51a4fbe119dce76d2','create_order',0,NULL,'2026-05-11 12:20:29.395784','2026-05-11 11:50:29.395784'),
(39,1,'02069ddaa520c21e27b6a0b976fea711de32d89f1e06d9a0e5f5e3ba9537fc51','create_order',0,NULL,'2026-05-11 12:20:39.814126','2026-05-11 11:50:39.814126'),
(40,2,'49b236b49ffb1359faa715f7bd92e20552d6cfcd9bb17e88c6e53862817fbdd1','create_order',1,'2026-05-11 11:51:31.388478','2026-05-11 12:21:12.719419','2026-05-11 11:51:12.719419'),
(41,2,'e2c9d2bd3c1aa71df93304907ae92a420fc64118e361d985f3e9c2410046bb57','create_order',0,NULL,'2026-05-11 12:21:31.421720','2026-05-11 11:51:31.421720'),
(42,2,'07be86f9d5a4081b5007b0e26436ef739058507bf0a0fb1e31f6ca069b575554','create_order',0,NULL,'2026-05-11 12:21:36.076399','2026-05-11 11:51:36.076399'),
(43,2,'625c0807c9c565fd0a5e0632e78cab0957da0475db2c1080fd0ed0b057e3cebe','create_order',0,NULL,'2026-05-11 12:25:19.246969','2026-05-11 11:55:19.246969'),
(44,1,'5f7f8d44fdc0debb37c238ac027b3201b8362b4c20816fca42b6cf0deb81d0cd','create_order',0,NULL,'2026-05-11 12:48:25.707832','2026-05-11 12:18:25.707832'),
(45,1,'362ca6e15943f87fdef3317088c49254765f44859220dc90b53972071d01c46d','create_order',0,NULL,'2026-05-11 13:27:54.279913','2026-05-11 12:57:54.279913'),
(46,1,'826ee190120d6002beae5e87174ffbb5f57970f138949145603e1429b33248d4','create_order',0,NULL,'2026-05-11 13:28:09.246035','2026-05-11 12:58:09.246035'),
(47,1,'871d152b0143ae2842053f5d12e5b66bc1231f96fbb44313fa0593709bc8a99c','create_order',0,NULL,'2026-05-11 13:28:27.380566','2026-05-11 12:58:27.380566'),
(48,1,'c16960ae7f95f202784a414e8591ff03153e1beb399e7dcf3d81fd62d0030ab7','create_order',0,NULL,'2026-05-11 13:28:37.959039','2026-05-11 12:58:37.959039'),
(49,1,'e5f58009f2d7c4ab718737e8416ecdadcdb2421f9d5e8d83eeb2f312a60828a2','create_order',0,NULL,'2026-05-11 13:29:33.237348','2026-05-11 12:59:33.237348'),
(50,1,'35c63d1aa374cf4f4302f96cf69d9c708b9f03d1711928b513285ff0f489ed22','create_order',0,NULL,'2026-05-11 13:42:38.040621','2026-05-11 13:12:38.040621'),
(51,2,'56e0db8ea8250c6212b7ab4a47ba6459e1e9423963d285c5940239b2e84a51e4','create_order',0,NULL,'2026-05-11 13:42:42.486034','2026-05-11 13:12:42.486034'),
(52,2,'6bfe37caa3a41124a7d677d50a8201468cf0121f66f848703ad026393f788b64','create_order',0,NULL,'2026-05-11 13:42:50.878303','2026-05-11 13:12:50.878303'),
(53,2,'82c6b9a15943a0a3732e4a74e7cc567fad2bf1f09cc24551f95fd6076c4181ef','create_order',0,NULL,'2026-05-11 13:42:52.836850','2026-05-11 13:12:52.836850'),
(54,2,'7b766fe2085d8b5beaa062e72dae5a71d24e9fa6324b877e9e4f2ede83ec7a2f','create_order',0,NULL,'2026-05-11 13:43:05.459457','2026-05-11 13:13:05.459457'),
(55,2,'8c394190c9df13c1b6f7506620aa42e0275aafe92a763420966e9804d5002013','create_order',0,NULL,'2026-05-11 13:43:19.288015','2026-05-11 13:13:19.288015'),
(56,1,'be02bad87d57cb275c23076ef7888a7ace110d1072fa9e04bad898d8f73edc5d','create_order',0,NULL,'2026-05-11 13:43:20.938531','2026-05-11 13:13:20.938531'),
(57,2,'baceae95ab427e7bb4e054f3ec86ca6948032889fb22a3d1476e9894fb0fe2ea','create_order',0,NULL,'2026-05-11 13:43:49.914599','2026-05-11 13:13:49.914599'),
(58,2,'d07bc23a1a03efcb417a4532f2309d596dfbc610331b24448278623ee7e9c6cb','create_order',0,NULL,'2026-05-11 13:48:47.016550','2026-05-11 13:18:47.016550'),
(59,2,'0c0de6755bb7cb49f39bd732002bd17d0febd4aa4abb4148583d3bdff247bbed','create_order',0,NULL,'2026-05-11 13:48:58.165879','2026-05-11 13:18:58.165879'),
(60,2,'5368b05dd358f8bcf489d094c8b88e193440ee06e7d3a54299d72c531a281125','create_order',0,NULL,'2026-05-11 13:49:06.764003','2026-05-11 13:19:06.764003'),
(61,2,'64f02988cfc86e55a02e83281e5b4fede8988be5fb9c7678c88bde994be8bfa7','create_order',0,NULL,'2026-05-11 13:49:29.543809','2026-05-11 13:19:29.543809'),
(62,2,'c4a58da6cf36fc3dc5f1c4846f585a8787d82eced4cb65539714f6ed6a296598','create_order',0,NULL,'2026-05-11 13:49:33.529416','2026-05-11 13:19:33.529416'),
(63,1,'2f594f798a4bd647dbd3ea458136849b01f5f30f89662a4f257872d78e6956d5','create_order',0,NULL,'2026-05-11 14:06:01.483892','2026-05-11 13:36:01.483892'),
(64,2,'d9c009731e6ed70c3224d8e931a3b5fd5163c6509e8f8ecb19175a5e5b902842','create_order',0,NULL,'2026-05-11 14:06:13.147790','2026-05-11 13:36:13.147790'),
(65,2,'dfb348e52f8cb20c31e111d2667010e1e4c06bd3628000f830eaf4286dc6ed5e','create_order',0,NULL,'2026-05-11 14:50:19.490832','2026-05-11 14:20:19.490832'),
(66,1,'18e52c78f76e11efbcdbb95d555184d9e3bad9da30c9586336b2060ba2e41575','create_order',0,NULL,'2026-05-11 21:21:47.907856','2026-05-11 20:51:47.907856'),
(67,1,'5ccb1c630d38b04a45f19481af5b4455956f55a7ee3c3a0a5fbe2bff6f92198a','create_order',0,NULL,'2026-05-11 21:25:58.266142','2026-05-11 20:55:58.266142'),
(68,1,'4da0269373f15defea7b48b1ec4b53f648c8a0a0dd64f66f99682ecbe981cc8f','create_order',0,NULL,'2026-05-11 23:30:26.352095','2026-05-11 23:00:26.352095'),
(69,1,'e9070b173ae411f220fb2781be6456ab9983217d07ab8624e90a1fc46321160c','create_order',0,NULL,'2026-05-11 23:30:33.895540','2026-05-11 23:00:33.895540'),
(70,1,'a737ba74707ac6969742e718b95b39e60409946ee8f5cff03abbba4fd0ee4144','create_order',0,NULL,'2026-05-12 00:00:04.285745','2026-05-11 23:30:04.285745'),
(71,2,'7469023d45d39dc30932bac460bcb8fc7b4f91015528c226c20b0720e3c000d1','create_order',0,NULL,'2026-05-12 00:05:10.901104','2026-05-11 23:35:10.901104'),
(72,1,'96d826e1f0b835f72b3c69da95fad5a6b1cb8c9ac5a76bceaf721b39f0ebdf72','create_order',0,NULL,'2026-05-12 00:08:02.517465','2026-05-11 23:38:02.517465'),
(73,1,'bfe0592850a4e4888f357436739d8382614cac8b0e9901159a011984e434430e','create_order',0,NULL,'2026-05-12 00:08:05.312539','2026-05-11 23:38:05.312539'),
(74,1,'8911b106a55159a1b6e157b16ec02e99438f7de358ef4ecd9f5da21bb8c7bd80','create_order',0,NULL,'2026-05-12 23:31:46.432079','2026-05-12 23:01:46.432079'),
(75,1,'fb261a2873f41e21d633425e93f16b7f18db05794341f74518c8ae3f01b52e59','create_order',0,NULL,'2026-05-12 23:39:59.322336','2026-05-12 23:09:59.322336'),
(76,1,'be58c01891e6173f6da9c16dfb0fed432d47cceacba43905edff68c4873cf5e7','create_order',0,NULL,'2026-05-13 13:43:45.956621','2026-05-13 13:13:45.956621'),
(77,1,'c9294901c25ce22b2555c49ba0822039ec609c01164da82d2680eb1f709e3046','create_order',0,NULL,'2026-05-13 13:43:51.709225','2026-05-13 13:13:51.709225'),
(78,1,'0c11dd43a1e16dfa13982a315edd1e1d5b0f7fcb5915b8e8c8399fb8e49d3c23','create_order',0,NULL,'2026-05-13 13:44:30.926714','2026-05-13 13:14:30.926714'),
(79,1,'7377e6971bff351dbdc3240f916e9d42e3b970f33c7d3272d82b9e9c10d9c5ff','create_order',0,NULL,'2026-05-13 15:57:12.849906','2026-05-13 15:27:12.849906'),
(80,1,'5cb8f40ae0268d7b69c3268b3aafc99b49cc6f8620cbc56a13dc81400a32bc0b','create_order',0,NULL,'2026-05-13 15:57:23.143103','2026-05-13 15:27:23.143103'),
(81,1,'4640ea74d69614b9805d5ba8f676c61cd0216b09e6978df44ab38526fd3318ce','create_order',0,NULL,'2026-05-13 15:57:29.974790','2026-05-13 15:27:29.974790'),
(82,1,'09ce16c6cd248e4933fb1eab3fdda8a978c5620c400c73ee8fa51835d10ccdee','create_order',0,NULL,'2026-05-13 15:57:47.922525','2026-05-13 15:27:47.922525'),
(83,1,'c94e633351908f802c660753f970d20b95c8302d418354979fc5c6a5c46fa20f','create_order',0,NULL,'2026-05-13 17:01:17.535089','2026-05-13 16:31:17.535089'),
(84,1,'abbe2f8c581f3b7d4b95f70f69dead9b6511bc9ca4de058b43d398d3401397ec','create_order',0,NULL,'2026-05-13 17:01:27.719280','2026-05-13 16:31:27.719280'),
(85,1,'d9beb938c069ba29c284840bc19cdac28ec08cc7de5f84e391fcf916d85bcd0d','create_order',0,NULL,'2026-05-13 19:57:28.693326','2026-05-13 19:27:28.693326'),
(86,1,'dacae1297ecf3a6c531c7f589213d56ae28039b6f781b929835de39585af6a79','create_order',0,NULL,'2026-05-13 23:39:17.008355','2026-05-13 23:09:17.008355'),
(87,1,'fd0f0cfe84b167202f301538c0a657a9779bbaf5b5693df5950b333836bb8735','create_order',0,NULL,'2026-05-14 13:27:35.113024','2026-05-14 12:57:35.113024'),
(88,1,'b93a97605f0b223dedbc7198c2c796dd4cd7f3f1f8b09e8736b795671c5eff2f','create_order',0,NULL,'2026-05-14 13:27:38.551401','2026-05-14 12:57:38.551401'),
(89,1,'a595e126584f0698e58e41d4de37e47ad097619c790de3862e6c77a9a4e8ac8a','create_order',0,NULL,'2026-05-14 14:48:36.933616','2026-05-14 14:18:36.933616'),
(90,1,'08df7ae6561950e0d6e64b9e1c655ea4ae02cd7f931f972605f577455634d2e9','create_order',0,NULL,'2026-05-14 15:39:42.541288','2026-05-14 15:09:42.541288'),
(91,1,'ff45d16b477ad8359dd44e251b4efc0c7d39a889938b3bad1a4ec6f7e293a815','create_order',1,'2026-05-14 16:10:38.694650','2026-05-14 16:40:22.709954','2026-05-14 16:10:22.709954'),
(92,1,'a43cef39ed72adc2aef6cb50b3b44f0a9d2b9aeac227ed8721bdab7ce7b31331','create_order',0,NULL,'2026-05-14 16:40:39.146269','2026-05-14 16:10:39.146269'),
(93,1,'3f426ad5085a386c17ea0d05c2fd0033d1091b12de4c91b85bbdc055e3f4817f','create_order',0,NULL,'2026-05-14 16:51:45.750879','2026-05-14 16:21:45.750879'),
(94,1,'33248f34e315e806f2c4fa2ef5fe3c46db8cf44795ecc408cf5824f214fcb121','create_order',0,NULL,'2026-05-14 16:51:52.493386','2026-05-14 16:21:52.493386'),
(95,1,'97c9444d95b662cf93be98d7c6ac75762e65a3e18460490e7b3d05d20794bba9','create_order',0,NULL,'2026-05-14 16:54:09.782231','2026-05-14 16:24:09.782231'),
(96,1,'57e65babce61a6bb5ed59bb360ad09820e0d7d6ec637729158fa13a44e0ca78c','create_order',0,NULL,'2026-05-14 16:54:11.800889','2026-05-14 16:24:11.800889'),
(97,1,'467160ded19050b02fc700890424d021b7f9ffaa60edb651e8e2a6e2b7328b7c','create_order',0,NULL,'2026-05-14 16:54:12.297908','2026-05-14 16:24:12.297908'),
(98,1,'cd189d26fe2283868ddb95971a71c684e5c3b053e3940947d2eca6dcaef05a37','create_order',0,NULL,'2026-05-14 16:54:12.760068','2026-05-14 16:24:12.760068'),
(99,1,'0230bde84c2cd37c035f951d568be10031052a077079417c1fb547b0905b0994','create_order',0,NULL,'2026-05-14 16:54:24.436830','2026-05-14 16:24:24.436830'),
(100,1,'a7cc27b68c9dfa9a098bfa146473c8fb4215f6a9b208f4d16075faae61749a04','create_order',0,NULL,'2026-05-14 16:54:25.474762','2026-05-14 16:24:25.474762'),
(101,1,'405452c570969ec6a3bb2319eca73f54831c51ba7f6e4ccf9ed14c6494d07fb1','create_order',0,NULL,'2026-05-14 16:55:17.511597','2026-05-14 16:25:17.511597'),
(102,1,'3935ae369b89c03072f4c40a89813bc71f4e06f76f55b36a1202c57abe207a8c','create_order',0,NULL,'2026-05-14 16:55:18.471300','2026-05-14 16:25:18.471300'),
(103,1,'52e7e4cf91f87f82008031f69297f91af912663873c09684e098fe1db1eb388c','create_order',0,NULL,'2026-05-14 17:53:21.820183','2026-05-14 17:23:21.820183'),
(104,1,'ca11093704af037293c977df2cbe50c99669fac22792bda3fde998d91f046a81','create_order',0,NULL,'2026-05-14 18:14:50.775403','2026-05-14 17:44:50.775403'),
(105,1,'7615cff66a1960a2b1c903c9026f0398a6a4b4c1b7dd207ac2e615acabada1bb','create_order',0,NULL,'2026-05-14 18:15:08.705706','2026-05-14 17:45:08.705706'),
(106,1,'a4788663f842d2055b1fcc0c9a631830667ff12206bdecef6976fe387c8b1222','create_order',0,NULL,'2026-05-14 18:15:14.090629','2026-05-14 17:45:14.090629'),
(107,1,'06aa5d92db22aab7ee313f718d194569811043fe21dd1cc251461e58ea755afa','create_order',0,NULL,'2026-05-14 18:31:10.727856','2026-05-14 18:01:10.727856'),
(108,1,'8a19748f85e3d54bbde3daae83bfea09adb25eaac61801543a3bdadc5ee26a39','create_order',0,NULL,'2026-05-14 18:55:12.446326','2026-05-14 18:25:12.446326'),
(109,1,'d9bd34991dfab15ca723f6d032ba09aa19ce09012a5038a1f1055b445fb7559d','create_order',0,NULL,'2026-05-14 19:12:10.464634','2026-05-14 18:42:10.464634'),
(110,1,'3e8175d05fd99387976bf851eac8ed1ce4b844d9b9dba04b561489e77f36b72f','create_order',0,NULL,'2026-05-14 19:12:40.035550','2026-05-14 18:42:40.035550'),
(111,1,'d2526aeb3f4ab3b6f3583f17581dfefaa16bf5dafb5c94898b6345d77309b97b','create_order',0,NULL,'2026-05-14 19:13:27.804305','2026-05-14 18:43:27.804305'),
(112,1,'69e0fcde2c83636f9b01dbe11d8f9cebdfa927f2afe3b9b44b56b0c450cc42b8','create_order',0,NULL,'2026-05-14 19:42:22.428031','2026-05-14 19:12:22.428031'),
(113,1,'260372ee6e6785720d48e7e8f27a8a724bafdda36bf14cf322dfa350ee202d58','create_order',0,NULL,'2026-05-14 19:42:22.820719','2026-05-14 19:12:22.820719'),
(114,1,'95ac26a9366081c2568cce82ba0e06cac2a77f8cf128f27cb02b143063bb3c42','create_order',0,NULL,'2026-05-14 19:42:23.030056','2026-05-14 19:12:23.030056'),
(115,1,'bd494a02d55a5ce4e981829dbe8a5b0559ba781d051475edfe78932d0395c11c','create_order',0,NULL,'2026-05-14 19:42:23.448771','2026-05-14 19:12:23.448771'),
(116,1,'12210525f614aba3d1a0b1deb1c32c38fc4b915ad3a3adf7b5da086fe62548ed','create_order',0,NULL,'2026-05-14 19:42:23.604707','2026-05-14 19:12:23.604707'),
(117,1,'16ce4a8bd80633c4c37b36c1e47605d3912eda476f8623ef29d2a7c16e9ac3ff','create_order',0,NULL,'2026-05-14 19:42:23.998602','2026-05-14 19:12:23.998602'),
(118,1,'e8df65960b7a18cbc9c0cd1b582d83c673d2cb5ea07d0e580081538aa396b00b','create_order',0,NULL,'2026-05-14 20:29:47.347496','2026-05-14 19:59:47.347496'),
(119,1,'19335e8562d1bb047ad907b437813ed622d38b65445fe47a89e57efcc2ea4fd3','create_order',0,NULL,'2026-05-15 11:59:07.008122','2026-05-15 11:29:07.008122'),
(120,1,'dbb9fce73103976b370e22a01dcf48061311620a0c9d83ec57603bddd25049a7','create_order',0,NULL,'2026-05-15 11:59:27.992181','2026-05-15 11:29:27.992181'),
(121,2,'ba568648e36531e9a7d1096f2aeba9a8e9ba1ef26d22aadcee171fb3007cfa0b','create_order',0,NULL,'2026-05-15 12:08:17.227183','2026-05-15 11:38:17.227183'),
(122,2,'ca237145a98918662f16d9d408aa2770929a04f034a8ca223dabc263ace4ba16','create_order',0,NULL,'2026-05-15 12:08:21.045091','2026-05-15 11:38:21.045091'),
(123,2,'7dff11e935c818c7358c74636e24dc99c483eb39c2b507b019fb0c6057d678ee','create_order',0,NULL,'2026-05-15 13:48:23.807114','2026-05-15 13:18:23.807114'),
(124,2,'7a7c20213f26fb69f51db1eecacd535799e3edc61630fa6e0164942aee5fbcab','create_order',0,NULL,'2026-05-15 13:48:52.588071','2026-05-15 13:18:52.588071');
/*!40000 ALTER TABLE `form_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `marker_detections`
--

DROP TABLE IF EXISTS `marker_detections`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `marker_detections` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `session_id` bigint(20) unsigned NOT NULL,
  `source_type` varchar(32) NOT NULL,
  `source_id` bigint(20) unsigned DEFAULT NULL,
  `source_path` varchar(1024) DEFAULT NULL,
  `frame_index` int(11) DEFAULT NULL,
  `timestamp_ms` bigint(20) DEFAULT NULL,
  `marker_kit_id` varchar(64) NOT NULL DEFAULT 'maklertour_kit_v1',
  `marker_dictionary` varchar(64) NOT NULL DEFAULT 'APRILTAG_36H11',
  `marker_id` int(11) NOT NULL,
  `marker_size_m` decimal(8,4) NOT NULL DEFAULT 0.1600,
  `corners_json` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`corners_json`)),
  `center_x` decimal(12,6) DEFAULT NULL,
  `center_y` decimal(12,6) DEFAULT NULL,
  `confidence` double DEFAULT NULL,
  `created_at` datetime(6) NOT NULL DEFAULT current_timestamp(6),
  PRIMARY KEY (`id`),
  KEY `idx_marker_detections_session_id` (`session_id`),
  KEY `idx_marker_detections_marker_id` (`marker_id`),
  KEY `idx_marker_detections_source` (`source_type`,`source_id`)
) ENGINE=InnoDB AUTO_INCREMENT=132 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `marker_detections`
--

LOCK TABLES `marker_detections` WRITE;
/*!40000 ALTER TABLE `marker_detections` DISABLE KEYS */;
INSERT INTO `marker_detections` VALUES
(2,32,'PHOTO_POINT',27,'orders/5/sessions/6c81ff4c-3cbc-4808-a168-75c9048bec14/photos/originals/2ae7d953-1ac2-4749-b79c-42a9dd783ab2_2ae7d953-1ac2-4749-b79c-42a9dd783ab2.jpg',NULL,NULL,'maklertour_kit_v1','APRILTAG_36H11',1,0.1600,'[[4834.68115234375,2426.3989257812495],[4929.594726562499,2399.366455078125],[4895.3857421875,2327.546875],[4806.585449218751,2349.8134765624995]]',4866.812779,2374.075416,60.06483840942383,'2026-05-14 17:13:41.961997'),
(3,32,'PHOTO_POINT',27,'orders/5/sessions/6c81ff4c-3cbc-4808-a168-75c9048bec14/photos/originals/2ae7d953-1ac2-4749-b79c-42a9dd783ab2_2ae7d953-1ac2-4749-b79c-42a9dd783ab2.jpg',NULL,NULL,'maklertour_kit_v1','APRILTAG_36H11',5,0.1600,'[[1362.2076416015623,1520.4366455078127],[1500.4523925781248,1525.7200927734375],[1505.6627197265625,1388.4829101562498],[1369.3704833984377,1382.4481201171875]]',1434.651944,1453.800480,119.67739868164062,'2026-05-14 17:13:41.985230'),
(4,32,'PHOTO_POINT',28,'orders/5/sessions/6c81ff4c-3cbc-4808-a168-75c9048bec14/photos/originals/aa339941-49d4-402c-820a-187cf26364f0_aa339941-49d4-402c-820a-187cf26364f0.jpg',NULL,NULL,'maklertour_kit_v1','APRILTAG_36H11',4,0.1600,'[[4614.87060546875,1416.0751953125],[4695.64599609375,1415.1622314453125],[4693.30859375,1329.2984619140623],[4613.043945312499,1328.5374755859373]]',4654.602257,1372.119670,91.19190979003906,'2026-05-14 17:13:41.989224'),
(5,32,'PHOTO_POINT',28,'orders/5/sessions/6c81ff4c-3cbc-4808-a168-75c9048bec14/photos/originals/aa339941-49d4-402c-820a-187cf26364f0_aa339941-49d4-402c-820a-187cf26364f0.jpg',NULL,NULL,'maklertour_kit_v1','APRILTAG_36H11',5,0.1600,'[[5536.62744140625,1466.3923339843748],[5583.292968749999,1469.6658935546873],[5583.67333984375,1407.0035400390627],[5537.71728515625,1405.9403076171875]]',5559.921435,1436.986961,83.138671875,'2026-05-14 17:13:41.990606'),
(6,32,'PHOTO_POINT',29,'orders/5/sessions/6c81ff4c-3cbc-4808-a168-75c9048bec14/photos/originals/69a5da20-988a-46e9-84fa-cc91f7915cf8_69a5da20-988a-46e9-84fa-cc91f7915cf8.jpg',NULL,NULL,'maklertour_kit_v1','APRILTAG_36H11',1,0.1600,'[[5135.99951171875,1439.9208984375002],[5162.331054687499,1438.9267578125],[5161.3857421875,1409.5051269531248],[5134.832519531251,1411.0731201171875]]',5148.512079,1424.929331,138.4319305419922,'2026-05-14 17:13:41.991848'),
(7,32,'PHOTO_POINT',29,'orders/5/sessions/6c81ff4c-3cbc-4808-a168-75c9048bec14/photos/originals/69a5da20-988a-46e9-84fa-cc91f7915cf8_69a5da20-988a-46e9-84fa-cc91f7915cf8.jpg',NULL,NULL,'maklertour_kit_v1','APRILTAG_36H11',4,0.1600,'[[435.1523742675782,1466.8729248046873],[462.39511108398443,1467.738037109375],[465.1962890625,1423.0305175781252],[437.7644958496093,1420.32177734375]]',450.392936,1444.632717,56.97556686401367,'2026-05-14 17:13:41.993132'),
(8,32,'PHOTO_POINT',30,'orders/5/sessions/6c81ff4c-3cbc-4808-a168-75c9048bec14/photos/originals/ac65595b-6a32-4066-a8f8-6d77cf017b2f_ac65595b-6a32-4066-a8f8-6d77cf017b2f.jpg',NULL,NULL,'maklertour_kit_v1','APRILTAG_36H11',1,0.1600,'[[3638.2587890625,1463.4282226562498],[3664.509521484375,1462.6253662109375],[3664.047119140625,1428.4195556640625],[3637.790771484375,1429.5234374999998]]',3651.093646,1446.004403,104.63263702392578,'2026-05-14 17:13:41.994397'),
(9,32,'PHOTO_POINT',30,'orders/5/sessions/6c81ff4c-3cbc-4808-a168-75c9048bec14/photos/originals/ac65595b-6a32-4066-a8f8-6d77cf017b2f_ac65595b-6a32-4066-a8f8-6d77cf017b2f.jpg',NULL,NULL,'maklertour_kit_v1','APRILTAG_36H11',4,0.1600,'[[4822.02880859375,1431.6513671874995],[4860.260253906251,1432.2017822265625],[4860.716796875,1372.7927246093752],[4821.642089843751,1370.3125]]',4841.465378,1402.081205,63.40109634399414,'2026-05-14 17:13:41.995853'),
(10,32,'PHOTO_POINT',30,'orders/5/sessions/6c81ff4c-3cbc-4808-a168-75c9048bec14/photos/originals/ac65595b-6a32-4066-a8f8-6d77cf017b2f_ac65595b-6a32-4066-a8f8-6d77cf017b2f.jpg',NULL,NULL,'maklertour_kit_v1','APRILTAG_36H11',5,0.1600,'[[5330.709960937499,1468.9957275390625],[5365.470214843748,1470.6999511718748],[5365.984863281251,1430.6781005859377],[5331.899902343752,1429.924438476563]]',5348.319090,1449.867679,79.53858947753906,'2026-05-14 17:13:41.997361'),
(11,32,'PHOTO_POINT',31,'orders/5/sessions/6c81ff4c-3cbc-4808-a168-75c9048bec14/photos/originals/2db840c4-3e28-4cea-92b9-157544994178_2db840c4-3e28-4cea-92b9-157544994178.jpg',NULL,NULL,'maklertour_kit_v1','APRILTAG_36H11',1,0.1600,'[[1279.5123291015627,1331.8640136718748],[1449.98583984375,1346.8013916015623],[1451.37060546875,1180.6507568359377],[1287.662841796875,1148.1370849609377]]',1371.586855,1250.850232,96.64240264892578,'2026-05-14 17:13:41.998801'),
(12,32,'PHOTO_POINT',31,'orders/5/sessions/6c81ff4c-3cbc-4808-a168-75c9048bec14/photos/originals/2db840c4-3e28-4cea-92b9-157544994178_2db840c4-3e28-4cea-92b9-157544994178.jpg',NULL,NULL,'maklertour_kit_v1','APRILTAG_36H11',2,0.1600,'[[4017.5471191406255,1442.9945068359377],[4043.100830078124,1441.8621826171873],[4041.7448730468755,1415.4259033203125],[4015.8786621093755,1416.8394775390627]]',4029.507910,1429.367527,137.8025360107422,'2026-05-14 17:13:42.000032'),
(13,32,'PHOTO_POINT',31,'orders/5/sessions/6c81ff4c-3cbc-4808-a168-75c9048bec14/photos/originals/2db840c4-3e28-4cea-92b9-157544994178_2db840c4-3e28-4cea-92b9-157544994178.jpg',NULL,NULL,'maklertour_kit_v1','APRILTAG_36H11',3,0.1600,'[[3044.761474609375,1470.959228515625],[3077.142822265625,1478.39404296875],[3081.900390625,1405.7282714843748],[3049.9433593750005,1395.0350341796875]]',3063.803730,1437.513327,111.79931640625,'2026-05-14 17:13:42.001146'),
(14,32,'PHOTO_POINT',31,'orders/5/sessions/6c81ff4c-3cbc-4808-a168-75c9048bec14/photos/originals/2db840c4-3e28-4cea-92b9-157544994178_2db840c4-3e28-4cea-92b9-157544994178.jpg',NULL,NULL,'maklertour_kit_v1','APRILTAG_36H11',3,0.1600,'[[2781.364990234375,1436.4505615234375],[2817.279541015625,1442.664306640625],[2816.125,1369.0177001953123],[2780.3527832031245,1363.3724365234375]]',2798.712840,1402.796511,130.14108276367188,'2026-05-14 17:13:42.002627'),
(15,32,'PHOTO_POINT',32,'orders/5/sessions/6c81ff4c-3cbc-4808-a168-75c9048bec14/photos/originals/99032573-6d7d-434a-af6b-a65a80ce9922_99032573-6d7d-434a-af6b-a65a80ce9922.jpg',NULL,NULL,'maklertour_kit_v1','APRILTAG_36H11',1,0.1600,'[[2471.6867675781245,1437.6159667968745],[2522.4169921875,1434.7065429687502],[2518.7412109375,1372.7811279296875],[2468.356689453125,1377.6160888671873]]',2494.893425,1405.640243,100.90987396240234,'2026-05-14 17:13:42.003862'),
(16,32,'PHOTO_POINT',32,'orders/5/sessions/6c81ff4c-3cbc-4808-a168-75c9048bec14/photos/originals/99032573-6d7d-434a-af6b-a65a80ce9922_99032573-6d7d-434a-af6b-a65a80ce9922.jpg',NULL,NULL,'maklertour_kit_v1','APRILTAG_36H11',2,0.1600,'[[219.65621948242188,1382.258178710937],[263.26525878906256,1384.7474365234373],[268.3197631835937,1318.6315917968752],[225.54020690917966,1313.476318359375]]',244.650094,1349.579199,129.5512237548828,'2026-05-14 17:13:42.005212'),
(17,32,'PHOTO_POINT',32,'orders/5/sessions/6c81ff4c-3cbc-4808-a168-75c9048bec14/photos/originals/99032573-6d7d-434a-af6b-a65a80ce9922_99032573-6d7d-434a-af6b-a65a80ce9922.jpg',NULL,NULL,'maklertour_kit_v1','APRILTAG_36H11',3,0.1600,'[[3863.6909179687495,1445.8374023437502],[3928.7927246093755,1450.296875],[3934.2802734375005,1379.051025390625],[3869.379394531249,1375.6768798828125]]',3898.796462,1412.623158,126.26841735839844,'2026-05-14 17:13:42.006331'),
(18,32,'PHOTO_POINT',32,'orders/5/sessions/6c81ff4c-3cbc-4808-a168-75c9048bec14/photos/originals/99032573-6d7d-434a-af6b-a65a80ce9922_99032573-6d7d-434a-af6b-a65a80ce9922.jpg',NULL,NULL,'maklertour_kit_v1','APRILTAG_36H11',5,0.1600,'[[4260.894531249999,1481.7218017578125],[4280.918945312498,1481.984130859375],[4281.56787109375,1461.85546875],[4261.123046875002,1461.1038818359373]]',4271.242566,1471.777714,34.99311828613281,'2026-05-14 17:13:42.007493'),
(19,32,'PHOTO_POINT',33,'orders/5/sessions/6c81ff4c-3cbc-4808-a168-75c9048bec14/photos/originals/cee6d76b-85e1-4b69-bdb9-a33be7cd26eb_cee6d76b-85e1-4b69-bdb9-a33be7cd26eb.jpg',NULL,NULL,'maklertour_kit_v1','APRILTAG_36H11',1,0.1600,'[[2809.6755371093755,1441.8798828125],[2838.5156249999995,1440.5354003906248],[2836.02734375,1386.8599853515625],[2807.497802734376,1389.4765625000002]]',2822.749553,1414.582665,73.10324096679688,'2026-05-14 17:13:42.008764'),
(20,32,'PHOTO_POINT',33,'orders/5/sessions/6c81ff4c-3cbc-4808-a168-75c9048bec14/photos/originals/cee6d76b-85e1-4b69-bdb9-a33be7cd26eb_cee6d76b-85e1-4b69-bdb9-a33be7cd26eb.jpg',NULL,NULL,'maklertour_kit_v1','APRILTAG_36H11',1,0.1600,'[[3072.5341796875005,1477.49365234375],[3101.607421875,1476.8543701171877],[3102.384765625,1425.83349609375],[3073.618896484376,1424.8768310546873]]',3087.761443,1451.140978,64.57844543457031,'2026-05-14 17:13:42.009990'),
(21,32,'PHOTO_POINT',33,'orders/5/sessions/6c81ff4c-3cbc-4808-a168-75c9048bec14/photos/originals/cee6d76b-85e1-4b69-bdb9-a33be7cd26eb_cee6d76b-85e1-4b69-bdb9-a33be7cd26eb.jpg',NULL,NULL,'maklertour_kit_v1','APRILTAG_36H11',2,0.1600,'[[132.74841308593747,1270.6165771484377],[214.88587951660156,1281.112548828125],[236.95590209960938,1154.4361572265623],[158.76734924316406,1134.836181640625]]',187.458273,1209.620822,117.09941864013672,'2026-05-14 17:13:42.011134'),
(22,32,'PHOTO_POINT',33,'orders/5/sessions/6c81ff4c-3cbc-4808-a168-75c9048bec14/photos/originals/cee6d76b-85e1-4b69-bdb9-a33be7cd26eb_cee6d76b-85e1-4b69-bdb9-a33be7cd26eb.jpg',NULL,NULL,'maklertour_kit_v1','APRILTAG_36H11',3,0.1600,'[[3787.8337402343745,1468.4434814453123],[3822.818603515625,1470.5166015625],[3825.2119140625005,1426.9587402343755],[3790.7373046875005,1425.175903320313]]',3806.608208,1447.606349,98.22271728515625,'2026-05-14 17:13:42.012360'),
(23,32,'PHOTO_POINT',33,'orders/5/sessions/6c81ff4c-3cbc-4808-a168-75c9048bec14/photos/originals/cee6d76b-85e1-4b69-bdb9-a33be7cd26eb_cee6d76b-85e1-4b69-bdb9-a33be7cd26eb.jpg',NULL,NULL,'maklertour_kit_v1','APRILTAG_36H11',5,0.1600,'[[4224.2666015625,1485.004028320312],[4241.596191406249,1485.5268554687498],[4242.3330078125,1467.590454101563],[4224.334472656251,1467.2711181640623]]',4233.074482,1476.514422,19.229167938232422,'2026-05-14 17:13:42.013312'),
(24,32,'VIDEO_FRAME',26,'orders/5/sessions/6c81ff4c-3cbc-4808-a168-75c9048bec14/videos/2144e047-f718-402b-88da-77d6485ba18c_VID_20260514_141105_00_138.mp4',1,1000,'maklertour_kit_v1','APRILTAG_36H11',1,0.1600,'[[2022.2030029296873,1883.7512207031245],[2061.328125,1882.7465820312498],[2060.6022949218755,1843.1768798828127],[2021.3614501953127,1843.8719482421873]]',2041.451190,1863.412760,124.46175384521484,'2026-05-14 17:13:42.014152'),
(25,32,'VIDEO_FRAME',26,'orders/5/sessions/6c81ff4c-3cbc-4808-a168-75c9048bec14/videos/2144e047-f718-402b-88da-77d6485ba18c_VID_20260514_141105_00_138.mp4',1,1000,'maklertour_kit_v1','APRILTAG_36H11',3,0.1600,'[[2884.2019042968745,1868.3483886718745],[2928.1857910156245,1871.4930419921875],[2930.0908203125,1814.4991455078127],[2885.708740234375,1813.9230957031248]]',2906.531783,1842.144957,131.57632446289062,'2026-05-14 17:13:42.015008'),
(26,32,'VIDEO_FRAME',26,'orders/5/sessions/6c81ff4c-3cbc-4808-a168-75c9048bec14/videos/2144e047-f718-402b-88da-77d6485ba18c_VID_20260514_141105_00_138.mp4',1,1000,'maklertour_kit_v1','APRILTAG_36H11',5,0.1600,'[[3489.1818847656245,1903.8188476562502],[3515.1403808593745,1905.4283447265625],[3515.7958984375005,1870.287841796875],[3489.580078125,1868.44921875]]',3502.462446,1887.086663,37.30503845214844,'2026-05-14 17:13:42.015803'),
(27,32,'VIDEO_FRAME',26,'orders/5/sessions/6c81ff4c-3cbc-4808-a168-75c9048bec14/videos/2144e047-f718-402b-88da-77d6485ba18c_VID_20260514_141105_00_138.mp4',2,2000,'maklertour_kit_v1','APRILTAG_36H11',1,0.1600,'[[2022.2343750000002,1883.5904541015627],[2061.368896484375,1882.7644042968752],[2060.556640625,1843.1728515625],[2021.4510498046877,1843.9608154296875]]',2041.411842,1863.364426,130.43560791015625,'2026-05-14 17:13:42.016625'),
(28,32,'VIDEO_FRAME',26,'orders/5/sessions/6c81ff4c-3cbc-4808-a168-75c9048bec14/videos/2144e047-f718-402b-88da-77d6485ba18c_VID_20260514_141105_00_138.mp4',2,2000,'maklertour_kit_v1','APRILTAG_36H11',3,0.1600,'[[2884.279296875,1868.3332519531248],[2928.2570800781245,1871.428466796875],[2930.0920410156255,1814.625366210938],[2885.814697265626,1813.7459716796877]]',2906.667589,1842.086672,130.04249572753906,'2026-05-14 17:13:42.019145'),
(29,32,'VIDEO_FRAME',26,'orders/5/sessions/6c81ff4c-3cbc-4808-a168-75c9048bec14/videos/2144e047-f718-402b-88da-77d6485ba18c_VID_20260514_141105_00_138.mp4',2,2000,'maklertour_kit_v1','APRILTAG_36H11',5,0.1600,'[[3489.37841796875,1903.6525878906252],[3515.207275390625,1905.0732421875],[3515.1572265625,1869.9151611328127],[3488.8825683593745,1869.9176025390627]]',3501.886147,1887.283384,38.2381591796875,'2026-05-14 17:13:42.020527'),
(30,32,'VIDEO_FRAME',26,'orders/5/sessions/6c81ff4c-3cbc-4808-a168-75c9048bec14/videos/2144e047-f718-402b-88da-77d6485ba18c_VID_20260514_141105_00_138.mp4',3,3000,'maklertour_kit_v1','APRILTAG_36H11',1,0.1600,'[[2022.1794433593748,1883.6785888671877],[2061.415283203125,1882.7281494140627],[2060.6201171875005,1843.238037109375],[2021.2866210937505,1843.73193359375]]',2041.489127,1863.364317,127.97472381591797,'2026-05-14 17:13:42.021733'),
(31,32,'VIDEO_FRAME',26,'orders/5/sessions/6c81ff4c-3cbc-4808-a168-75c9048bec14/videos/2144e047-f718-402b-88da-77d6485ba18c_VID_20260514_141105_00_138.mp4',3,3000,'maklertour_kit_v1','APRILTAG_36H11',3,0.1600,'[[2884.3139648437495,1868.315673828125],[2928.2651367187495,1871.404541015625],[2930.052001953125,1814.5960693359375],[2885.746826171875,1813.6131591796875]]',2906.672444,1842.055503,126.95767974853516,'2026-05-14 17:13:42.022709'),
(32,32,'VIDEO_FRAME',26,'orders/5/sessions/6c81ff4c-3cbc-4808-a168-75c9048bec14/videos/2144e047-f718-402b-88da-77d6485ba18c_VID_20260514_141105_00_138.mp4',3,3000,'maklertour_kit_v1','APRILTAG_36H11',5,0.1600,'[[3488.8728027343745,1904.2443847656255],[3515.8566894531245,1904.8223876953125],[3515.7614746093755,1869.9888916015625],[3490.0429687500005,1868.3635253906255]]',3502.844724,1886.444508,38.305213928222656,'2026-05-14 17:13:42.023684'),
(33,32,'VIDEO_FRAME',26,'orders/5/sessions/6c81ff4c-3cbc-4808-a168-75c9048bec14/videos/2144e047-f718-402b-88da-77d6485ba18c_VID_20260514_141105_00_138.mp4',4,4000,'maklertour_kit_v1','APRILTAG_36H11',1,0.1600,'[[2022.1346435546873,1883.5537109375005],[2061.453125,1882.8338623046877],[2060.5969238281255,1843.0208740234373],[2021.4373779296877,1843.8150634765625]]',2041.385655,1863.266351,125.09390258789062,'2026-05-14 17:13:42.024776'),
(34,32,'VIDEO_FRAME',26,'orders/5/sessions/6c81ff4c-3cbc-4808-a168-75c9048bec14/videos/2144e047-f718-402b-88da-77d6485ba18c_VID_20260514_141105_00_138.mp4',4,4000,'maklertour_kit_v1','APRILTAG_36H11',3,0.1600,'[[2884.2565917968755,1868.1038818359377],[2928.220947265625,1871.5106201171875],[2930.199951171875,1814.4798583984377],[2885.8208007812505,1813.7528076171875]]',2906.586866,1842.040504,130.241455078125,'2026-05-14 17:13:42.025714'),
(35,32,'VIDEO_FRAME',26,'orders/5/sessions/6c81ff4c-3cbc-4808-a168-75c9048bec14/videos/2144e047-f718-402b-88da-77d6485ba18c_VID_20260514_141105_00_138.mp4',4,4000,'maklertour_kit_v1','APRILTAG_36H11',5,0.1600,'[[3488.6123046875,1903.6759033203127],[3515.01611328125,1904.974609375],[3515.971923828125,1869.3931884765623],[3490.0915527343755,1868.6520996093752]]',3502.329967,1886.487115,38.40590286254883,'2026-05-14 17:13:42.026969'),
(36,32,'VIDEO_FRAME',26,'orders/5/sessions/6c81ff4c-3cbc-4808-a168-75c9048bec14/videos/2144e047-f718-402b-88da-77d6485ba18c_VID_20260514_141105_00_138.mp4',5,5000,'maklertour_kit_v1','APRILTAG_36H11',1,0.1600,'[[2022.3034667968752,1883.608154296875],[2061.4953613281255,1882.8825683593748],[2060.5402832031245,1843.2034912109373],[2021.4504394531248,1843.7171630859373]]',2041.498476,1863.324879,121.04776763916016,'2026-05-14 17:13:42.028259'),
(37,32,'VIDEO_FRAME',26,'orders/5/sessions/6c81ff4c-3cbc-4808-a168-75c9048bec14/videos/2144e047-f718-402b-88da-77d6485ba18c_VID_20260514_141105_00_138.mp4',5,5000,'maklertour_kit_v1','APRILTAG_36H11',3,0.1600,'[[2884.274658203125,1868.3900146484375],[2928.3488769531245,1871.477783203125],[2930.110107421875,1814.4256591796873],[2885.7749023437505,1813.696044921875]]',2906.657306,1842.037810,125.67156219482422,'2026-05-14 17:13:42.029653'),
(38,32,'VIDEO_FRAME',26,'orders/5/sessions/6c81ff4c-3cbc-4808-a168-75c9048bec14/videos/2144e047-f718-402b-88da-77d6485ba18c_VID_20260514_141105_00_138.mp4',5,5000,'maklertour_kit_v1','APRILTAG_36H11',5,0.1600,'[[3489.0568847656245,1903.99072265625],[3515.443359375,1905.173828125],[3515.896484375,1869.6270751953125],[3489.7243652343745,1868.9761962890625]]',3502.433798,1886.863808,33.2452392578125,'2026-05-14 17:13:42.034162'),
(39,32,'VIDEO_FRAME',26,'orders/5/sessions/6c81ff4c-3cbc-4808-a168-75c9048bec14/videos/2144e047-f718-402b-88da-77d6485ba18c_VID_20260514_141105_00_138.mp4',6,6000,'maklertour_kit_v1','APRILTAG_36H11',1,0.1600,'[[2022.1794433593752,1883.53662109375],[2061.3652343750005,1882.8790283203125],[2060.7678222656245,1843.1973876953125],[2021.4615478515623,1843.7750244140625]]',2041.464224,1863.376840,116.75767517089844,'2026-05-14 17:13:42.035382'),
(40,32,'VIDEO_FRAME',26,'orders/5/sessions/6c81ff4c-3cbc-4808-a168-75c9048bec14/videos/2144e047-f718-402b-88da-77d6485ba18c_VID_20260514_141105_00_138.mp4',6,6000,'maklertour_kit_v1','APRILTAG_36H11',3,0.1600,'[[2884.2724609375,1868.3341064453125],[2928.33935546875,1871.517578125],[2930.1376953125,1814.4058837890625],[2885.657958984375,1813.5361328125]]',2906.637941,1842.036833,128.47799682617188,'2026-05-14 17:13:42.036569'),
(41,32,'VIDEO_FRAME',26,'orders/5/sessions/6c81ff4c-3cbc-4808-a168-75c9048bec14/videos/2144e047-f718-402b-88da-77d6485ba18c_VID_20260514_141105_00_138.mp4',6,6000,'maklertour_kit_v1','APRILTAG_36H11',5,0.1600,'[[3488.9577636718755,1903.5266113281252],[3515.0151367187505,1905.5338134765627],[3516.3320312499995,1869.5407714843745],[3489.8974609374995,1869.1831054687495]]',3502.236635,1887.040559,35.230987548828125,'2026-05-14 17:13:42.037309'),
(42,32,'VIDEO_FRAME',26,'orders/5/sessions/6c81ff4c-3cbc-4808-a168-75c9048bec14/videos/2144e047-f718-402b-88da-77d6485ba18c_VID_20260514_141105_00_138.mp4',7,7000,'maklertour_kit_v1','APRILTAG_36H11',1,0.1600,'[[2022.218994140625,1883.6541748046873],[2061.5996093750005,1882.826904296875],[2060.576904296875,1843.0751953125002],[2021.376953125,1843.7941894531252]]',2041.467858,1863.290728,117.35844421386719,'2026-05-14 17:13:42.038212'),
(43,32,'VIDEO_FRAME',26,'orders/5/sessions/6c81ff4c-3cbc-4808-a168-75c9048bec14/videos/2144e047-f718-402b-88da-77d6485ba18c_VID_20260514_141105_00_138.mp4',8,8000,'maklertour_kit_v1','APRILTAG_36H11',1,0.1600,'[[2022.2449951171875,1883.6507568359373],[2061.6298828125,1882.8037109375],[2060.5913085937505,1843.0434570312502],[2021.28466796875,1843.7752685546873]]',2041.465264,1863.297217,114.405029296875,'2026-05-14 17:13:42.039128'),
(44,32,'VIDEO_FRAME',26,'orders/5/sessions/6c81ff4c-3cbc-4808-a168-75c9048bec14/videos/2144e047-f718-402b-88da-77d6485ba18c_VID_20260514_141105_00_138.mp4',8,8000,'maklertour_kit_v1','APRILTAG_36H11',5,0.1600,'[[3489.234619140625,1903.746215820313],[3515.7646484375,1905.09912109375],[3515.6806640625,1869.8150634765625],[3489.6142578125,1867.7674560546877]]',3502.707873,1886.459584,35.56077194213867,'2026-05-14 17:13:42.040232'),
(45,32,'VIDEO_FRAME',26,'orders/5/sessions/6c81ff4c-3cbc-4808-a168-75c9048bec14/videos/2144e047-f718-402b-88da-77d6485ba18c_VID_20260514_141105_00_138.mp4',9,9000,'maklertour_kit_v1','APRILTAG_36H11',3,0.1600,'[[2884.2751464843745,1868.3081054687498],[2928.3715820312505,1871.6134033203125],[2930.27099609375,1814.4436035156252],[2885.84619140625,1813.7720947265625]]',2906.664588,1842.088432,129.19712829589844,'2026-05-14 17:13:42.041186'),
(46,32,'VIDEO_FRAME',26,'orders/5/sessions/6c81ff4c-3cbc-4808-a168-75c9048bec14/videos/2144e047-f718-402b-88da-77d6485ba18c_VID_20260514_141105_00_138.mp4',9,9000,'maklertour_kit_v1','APRILTAG_36H11',5,0.1600,'[[3488.7497558593755,1903.0093994140625],[3515.41259765625,1905.1024169921873],[3515.41943359375,1869.422607421875],[3489.9282226562505,1868.9606933593752]]',3502.090289,1886.208832,32.02135467529297,'2026-05-14 17:13:42.042190'),
(47,32,'VIDEO_FRAME',26,'orders/5/sessions/6c81ff4c-3cbc-4808-a168-75c9048bec14/videos/2144e047-f718-402b-88da-77d6485ba18c_VID_20260514_141105_00_138.mp4',10,10000,'maklertour_kit_v1','APRILTAG_36H11',3,0.1600,'[[2884.5056152343745,1868.39404296875],[2928.4848632812505,1871.56982421875],[2930.399658203125,1814.835205078125],[2886.0959472656245,1813.8935546875002]]',2906.923370,1842.232284,129.7541046142578,'2026-05-14 17:13:42.043606'),
(48,32,'VIDEO_FRAME',26,'orders/5/sessions/6c81ff4c-3cbc-4808-a168-75c9048bec14/videos/2144e047-f718-402b-88da-77d6485ba18c_VID_20260514_141105_00_138.mp4',10,10000,'maklertour_kit_v1','APRILTAG_36H11',5,0.1600,'[[3488.8381347656245,1903.1811523437498],[3515.330078125001,1905.6829833984375],[3516.4204101562495,1870.371826171875],[3490.1198730468736,1868.8071289062498]]',3502.505385,1886.923854,41.511966705322266,'2026-05-14 17:13:42.044851'),
(49,32,'VIDEO_FRAME',26,'orders/5/sessions/6c81ff4c-3cbc-4808-a168-75c9048bec14/videos/2144e047-f718-402b-88da-77d6485ba18c_VID_20260514_141105_00_138.mp4',11,11000,'maklertour_kit_v1','APRILTAG_36H11',3,0.1600,'[[2883.4792480468745,1875.837646484375],[2927.6279296875005,1879.408447265625],[2929.466796875,1822.3572998046877],[2885.0314941406245,1821.2543945312502]]',2905.907553,1849.755075,130.00189208984375,'2026-05-14 17:13:42.045871'),
(50,32,'VIDEO_FRAME',26,'orders/5/sessions/6c81ff4c-3cbc-4808-a168-75c9048bec14/videos/2144e047-f718-402b-88da-77d6485ba18c_VID_20260514_141105_00_138.mp4',11,11000,'maklertour_kit_v1','APRILTAG_36H11',5,0.1600,'[[3490.060058593751,1907.5297851562505],[3515.945068359375,1908.7652587890625],[3516.703857421875,1874.1389160156248],[3490.245361328125,1872.8526611328125]]',3503.240368,1891.011796,50.62308120727539,'2026-05-14 17:13:42.046773'),
(51,32,'VIDEO_FRAME',26,'orders/5/sessions/6c81ff4c-3cbc-4808-a168-75c9048bec14/videos/2144e047-f718-402b-88da-77d6485ba18c_VID_20260514_141105_00_138.mp4',12,12000,'maklertour_kit_v1','APRILTAG_36H11',3,0.1600,'[[2701.9960937500005,1872.1268310546868],[2747.0947265625005,1878.1142578125],[2751.630859375,1821.1119384765632],[2705.7365722656255,1817.4121093750005]]',2726.121158,1847.330953,133.5362091064453,'2026-05-14 17:13:42.047832'),
(52,32,'VIDEO_FRAME',26,'orders/5/sessions/6c81ff4c-3cbc-4808-a168-75c9048bec14/videos/2144e047-f718-402b-88da-77d6485ba18c_VID_20260514_141105_00_138.mp4',13,13000,'maklertour_kit_v1','APRILTAG_36H11',1,0.1600,'[[1458.1163330078125,1912.66015625],[1502.2387695312495,1911.8566894531252],[1501.89990234375,1867.1141357421875],[1458.026733398438,1867.9029541015623]]',1480.072623,1889.820044,119.76280975341797,'2026-05-14 17:13:42.050069'),
(53,32,'VIDEO_FRAME',26,'orders/5/sessions/6c81ff4c-3cbc-4808-a168-75c9048bec14/videos/2144e047-f718-402b-88da-77d6485ba18c_VID_20260514_141105_00_138.mp4',13,13000,'maklertour_kit_v1','APRILTAG_36H11',3,0.1600,'[[2366.49658203125,1917.7973632812505],[2411.6433105468745,1923.3199462890625],[2416.314208984375,1869.586791992187],[2370.118896484375,1866.0129394531248]]',2390.682202,1894.391942,130.75413513183594,'2026-05-14 17:13:42.051108'),
(54,32,'VIDEO_FRAME',26,'orders/5/sessions/6c81ff4c-3cbc-4808-a168-75c9048bec14/videos/2144e047-f718-402b-88da-77d6485ba18c_VID_20260514_141105_00_138.mp4',13,13000,'maklertour_kit_v1','APRILTAG_36H11',5,0.1600,'[[2914.544921875,1934.866088867188],[2941.814453125,1937.2893066406252],[2942.8530273437505,1907.8433837890623],[2916.2773437500005,1905.7878417968748]]',2928.810536,1921.248241,39.763118743896484,'2026-05-14 17:13:42.052047'),
(55,32,'VIDEO_FRAME',26,'orders/5/sessions/6c81ff4c-3cbc-4808-a168-75c9048bec14/videos/2144e047-f718-402b-88da-77d6485ba18c_VID_20260514_141105_00_138.mp4',14,14000,'maklertour_kit_v1','APRILTAG_36H11',1,0.1600,'[[1369.640869140625,1912.2235107421875],[1416.8699951171875,1911.7325439453125],[1417.1434326171875,1863.4180908203125],[1369.6088867187502,1862.9091796875002]]',1393.558219,1887.650178,127.15675354003906,'2026-05-14 17:13:42.054633'),
(56,32,'VIDEO_FRAME',26,'orders/5/sessions/6c81ff4c-3cbc-4808-a168-75c9048bec14/videos/2144e047-f718-402b-88da-77d6485ba18c_VID_20260514_141105_00_138.mp4',14,14000,'maklertour_kit_v1','APRILTAG_36H11',3,0.1600,'[[2346.155029296875,1934.0240478515627],[2395.3364257812495,1940.6646728515625],[2400.758056640625,1885.0806884765625],[2351.3088378906255,1880.0463867187502]]',2373.022113,1909.941769,129.56829833984375,'2026-05-14 17:13:42.055642'),
(57,32,'VIDEO_FRAME',26,'orders/5/sessions/6c81ff4c-3cbc-4808-a168-75c9048bec14/videos/2144e047-f718-402b-88da-77d6485ba18c_VID_20260514_141105_00_138.mp4',14,14000,'maklertour_kit_v1','APRILTAG_36H11',5,0.1600,'[[2850.0693359375005,1954.907348632813],[2878.6459960937505,1957.5009765625002],[2878.281005859375,1929.234130859375],[2852.6804199218745,1926.537353515625]]',2865.043676,1941.280381,39.38043212890625,'2026-05-14 17:13:42.056478'),
(58,32,'VIDEO_FRAME',26,'orders/5/sessions/6c81ff4c-3cbc-4808-a168-75c9048bec14/videos/2144e047-f718-402b-88da-77d6485ba18c_VID_20260514_141105_00_138.mp4',15,15000,'maklertour_kit_v1','APRILTAG_36H11',1,0.1600,'[[1507.5208740234373,1885.2871093749998],[1557.9138183593745,1885.2479248046873],[1558.59765625,1834.4332275390627],[1508.3421630859377,1833.6007080078127]]',1533.308322,1859.612198,123.44499969482422,'2026-05-14 17:13:42.057371'),
(59,32,'VIDEO_FRAME',26,'orders/5/sessions/6c81ff4c-3cbc-4808-a168-75c9048bec14/videos/2144e047-f718-402b-88da-77d6485ba18c_VID_20260514_141105_00_138.mp4',15,15000,'maklertour_kit_v1','APRILTAG_36H11',3,0.1600,'[[2561.007080078125,1914.4427490234375],[2616.0336914062505,1921.6424560546877],[2622.5424804687495,1860.1285400390623],[2566.7124023437495,1854.8171386718748]]',2591.109561,1887.872800,127.58299255371094,'2026-05-14 17:13:42.058515'),
(60,32,'VIDEO_FRAME',26,'orders/5/sessions/6c81ff4c-3cbc-4808-a168-75c9048bec14/videos/2144e047-f718-402b-88da-77d6485ba18c_VID_20260514_141105_00_138.mp4',15,15000,'maklertour_kit_v1','APRILTAG_36H11',5,0.1600,'[[3050.9687499999995,1951.248168945312],[3078.217773437501,1954.4449462890625],[3080.891357421875,1923.5474853515627],[3052.975341796874,1921.4666748046875]]',3065.484896,1937.809929,48.8650016784668,'2026-05-14 17:13:42.059399'),
(61,32,'VIDEO_FRAME',26,'orders/5/sessions/6c81ff4c-3cbc-4808-a168-75c9048bec14/videos/2144e047-f718-402b-88da-77d6485ba18c_VID_20260514_141105_00_138.mp4',16,16000,'maklertour_kit_v1','APRILTAG_36H11',1,0.1600,'[[1391.7895507812502,1892.3287353515625],[1444.6353759765625,1892.99267578125],[1445.300048828125,1839.56689453125],[1392.5772705078125,1838.236083984375]]',1418.740177,1865.755172,120.29802703857422,'2026-05-14 17:13:42.060309'),
(62,32,'VIDEO_FRAME',26,'orders/5/sessions/6c81ff4c-3cbc-4808-a168-75c9048bec14/videos/2144e047-f718-402b-88da-77d6485ba18c_VID_20260514_141105_00_138.mp4',16,16000,'maklertour_kit_v1','APRILTAG_36H11',3,0.1600,'[[2487.6777343750005,1906.3526611328123],[2545.2026367187505,1911.5987548828125],[2550.0178222656245,1848.39794921875],[2492.0815429687495,1845.1381835937498]]',2518.274355,1877.908391,127.49637603759766,'2026-05-14 17:13:42.061090'),
(63,32,'VIDEO_FRAME',26,'orders/5/sessions/6c81ff4c-3cbc-4808-a168-75c9048bec14/videos/2144e047-f718-402b-88da-77d6485ba18c_VID_20260514_141105_00_138.mp4',16,16000,'maklertour_kit_v1','APRILTAG_36H11',5,0.1600,'[[2968.573974609375,1947.630981445313],[2996.2707519531255,1949.7498779296873],[2997.8815917968745,1919.1552734374995],[2970.174072265624,1918.0029296875002]]',2983.003934,1933.610622,54.91380310058594,'2026-05-14 17:13:42.072873'),
(64,32,'VIDEO_FRAME',26,'orders/5/sessions/6c81ff4c-3cbc-4808-a168-75c9048bec14/videos/2144e047-f718-402b-88da-77d6485ba18c_VID_20260514_141105_00_138.mp4',17,17000,'maklertour_kit_v1','APRILTAG_36H11',1,0.1600,'[[1380.4561767578125,1885.426635742188],[1433.1976318359373,1885.2199707031252],[1432.9620361328125,1831.864379882812],[1380.720092773438,1831.6004638671875]]',1406.949317,1858.400464,125.72187805175781,'2026-05-14 17:13:42.073985'),
(65,32,'VIDEO_FRAME',26,'orders/5/sessions/6c81ff4c-3cbc-4808-a168-75c9048bec14/videos/2144e047-f718-402b-88da-77d6485ba18c_VID_20260514_141105_00_138.mp4',17,17000,'maklertour_kit_v1','APRILTAG_36H11',3,0.1600,'[[2477.906982421875,1876.9291992187498],[2535.607666015625,1880.8608398437498],[2539.18115234375,1817.6564941406252],[2481.04833984375,1816.3369140625002]]',2507.817753,1847.995436,126.72074127197266,'2026-05-14 17:13:42.074876'),
(66,32,'VIDEO_FRAME',26,'orders/5/sessions/6c81ff4c-3cbc-4808-a168-75c9048bec14/videos/2144e047-f718-402b-88da-77d6485ba18c_VID_20260514_141105_00_138.mp4',17,17000,'maklertour_kit_v1','APRILTAG_36H11',5,0.1600,'[[2960.145751953125,1917.1251220703125],[2988.0617675781255,1918.3861083984373],[2988.694580078125,1888.6412353515625],[2961.0537109374995,1887.7684326171873]]',2974.402275,1902.901029,65.8541030883789,'2026-05-14 17:13:42.075602'),
(67,32,'VIDEO_FRAME',26,'orders/5/sessions/6c81ff4c-3cbc-4808-a168-75c9048bec14/videos/2144e047-f718-402b-88da-77d6485ba18c_VID_20260514_141105_00_138.mp4',18,18000,'maklertour_kit_v1','APRILTAG_36H11',1,0.1600,'[[1378.0958251953127,1886.3081054687505],[1430.8206787109377,1885.3543701171875],[1430.7569580078125,1832.1662597656248],[1377.9820556640623,1831.9829101562502]]',1404.692933,1858.963146,127.5439682006836,'2026-05-14 17:13:42.076350'),
(68,32,'VIDEO_FRAME',26,'orders/5/sessions/6c81ff4c-3cbc-4808-a168-75c9048bec14/videos/2144e047-f718-402b-88da-77d6485ba18c_VID_20260514_141105_00_138.mp4',18,18000,'maklertour_kit_v1','APRILTAG_36H11',3,0.1600,'[[2476.4648437499995,1872.6859130859373],[2534.1428222656245,1876.228515625],[2537.4536132812505,1812.9562988281252],[2479.357177734375,1811.3800048828127]]',2506.390206,1843.378380,126.7870864868164,'2026-05-14 17:13:42.077141'),
(69,32,'VIDEO_FRAME',26,'orders/5/sessions/6c81ff4c-3cbc-4808-a168-75c9048bec14/videos/2144e047-f718-402b-88da-77d6485ba18c_VID_20260514_141105_00_138.mp4',18,18000,'maklertour_kit_v1','APRILTAG_36H11',5,0.1600,'[[2960.802001953125,1911.2836914062498],[2988.5180664062505,1912.2758789062502],[2989.7485351562495,1882.808349609375],[2961.9401855468745,1881.4061279296875]]',2975.345855,1896.976583,67.18016052246094,'2026-05-14 17:13:42.077905'),
(70,32,'VIDEO_FRAME',26,'orders/5/sessions/6c81ff4c-3cbc-4808-a168-75c9048bec14/videos/2144e047-f718-402b-88da-77d6485ba18c_VID_20260514_141105_00_138.mp4',19,19000,'maklertour_kit_v1','APRILTAG_36H11',1,0.1600,'[[1376.9808349609375,1886.81884765625],[1429.719970703125,1886.1192626953125],[1429.315673828125,1832.741455078125],[1376.8106689453123,1832.6356201171873]]',1403.403150,1859.516768,111.09268951416016,'2026-05-14 17:13:42.079764'),
(71,32,'VIDEO_FRAME',26,'orders/5/sessions/6c81ff4c-3cbc-4808-a168-75c9048bec14/videos/2144e047-f718-402b-88da-77d6485ba18c_VID_20260514_141105_00_138.mp4',19,19000,'maklertour_kit_v1','APRILTAG_36H11',3,0.1600,'[[2474.916259765625,1873.1326904296875],[2532.911376953125,1876.510498046875],[2536.04052734375,1813.0487060546873],[2478.0546875,1811.5970458984373]]',2505.036358,1843.525210,116.87342834472656,'2026-05-14 17:13:42.080672'),
(72,32,'VIDEO_FRAME',26,'orders/5/sessions/6c81ff4c-3cbc-4808-a168-75c9048bec14/videos/2144e047-f718-402b-88da-77d6485ba18c_VID_20260514_141105_00_138.mp4',19,19000,'maklertour_kit_v1','APRILTAG_36H11',5,0.1600,'[[2959.6044921875,1911.3079833984373],[2987.202880859375,1912.100830078125],[2987.9912109375,1882.4726562500002],[2960.145263671875,1881.634765625]]',2973.743294,1896.945740,81.6458740234375,'2026-05-14 17:13:42.081612'),
(73,32,'VIDEO_FRAME',26,'orders/5/sessions/6c81ff4c-3cbc-4808-a168-75c9048bec14/videos/2144e047-f718-402b-88da-77d6485ba18c_VID_20260514_141105_00_138.mp4',20,20000,'maklertour_kit_v1','APRILTAG_36H11',1,0.1600,'[[1304.607177734375,1891.0175781249998],[1357.3371582031248,1890.2904052734377],[1356.8765869140627,1835.8426513671877],[1304.1452636718755,1835.81884765625]]',1330.922106,1863.239873,114.53279876708984,'2026-05-14 17:13:42.082391'),
(74,32,'VIDEO_FRAME',26,'orders/5/sessions/6c81ff4c-3cbc-4808-a168-75c9048bec14/videos/2144e047-f718-402b-88da-77d6485ba18c_VID_20260514_141105_00_138.mp4',20,20000,'maklertour_kit_v1','APRILTAG_36H11',3,0.1600,'[[2408.34033203125,1884.0402832031255],[2466.0981445312505,1888.44287109375],[2469.8625488281255,1825.4150390624998],[2412.32373046875,1823.157470703125]]',2438.667852,1855.140832,120.55147552490234,'2026-05-14 17:13:42.083111'),
(75,32,'VIDEO_FRAME',26,'orders/5/sessions/6c81ff4c-3cbc-4808-a168-75c9048bec14/videos/2144e047-f718-402b-88da-77d6485ba18c_VID_20260514_141105_00_138.mp4',20,20000,'maklertour_kit_v1','APRILTAG_36H11',5,0.1600,'[[2886.794677734375,1915.5949707031248],[2914.1335449218755,1916.391845703125],[2915.39208984375,1887.6923828125002],[2888.0251464843745,1886.2406005859375]]',2901.239469,1901.501141,72.82836151123047,'2026-05-14 17:13:42.083881'),
(76,32,'VIDEO_FRAME',26,'orders/5/sessions/6c81ff4c-3cbc-4808-a168-75c9048bec14/videos/2144e047-f718-402b-88da-77d6485ba18c_VID_20260514_141105_00_138.mp4',21,21000,'maklertour_kit_v1','APRILTAG_36H11',1,0.1600,'[[804.4848022460938,1946.4798583984375],[864.0292968750001,1941.9569091796877],[861.6246948242188,1877.0063476562498],[802.702392578125,1881.096435546875]]',833.292567,1911.453952,70.73395538330078,'2026-05-14 17:13:42.084591'),
(77,32,'VIDEO_FRAME',26,'orders/5/sessions/6c81ff4c-3cbc-4808-a168-75c9048bec14/videos/2144e047-f718-402b-88da-77d6485ba18c_VID_20260514_141105_00_138.mp4',21,21000,'maklertour_kit_v1','APRILTAG_36H11',3,0.1600,'[[2001.24462890625,1947.8333740234373],[2057.785400390625,1957.2952880859373],[2065.2626953125005,1894.6391601562502],[2009.4671630859373,1886.8466796875002]]',2033.126340,1921.342062,123.85444641113281,'2026-05-14 17:13:42.085150'),
(78,32,'VIDEO_FRAME',26,'orders/5/sessions/6c81ff4c-3cbc-4808-a168-75c9048bec14/videos/2144e047-f718-402b-88da-77d6485ba18c_VID_20260514_141105_00_138.mp4',22,22000,'maklertour_kit_v1','APRILTAG_36H11',1,0.1600,'[[651.4785156249999,2049.5666503906255],[713.537658691406,2042.3402099609375],[707.6259765625,1973.2302246093745],[645.1370239257814,1978.59130859375]]',679.871848,2010.963916,73.1799545288086,'2026-05-14 17:13:42.085778'),
(79,32,'VIDEO_FRAME',26,'orders/5/sessions/6c81ff4c-3cbc-4808-a168-75c9048bec14/videos/2144e047-f718-402b-88da-77d6485ba18c_VID_20260514_141105_00_138.mp4',22,22000,'maklertour_kit_v1','APRILTAG_36H11',3,0.1600,'[[1935.16845703125,2010.528198242188],[2000.797119140625,2019.3635253906252],[2005.79052734375,1948.1384277343748],[1939.7475585937498,1941.2104492187498]]',1969.916140,1979.830996,119.09175109863281,'2026-05-14 17:13:42.086359'),
(80,32,'VIDEO_FRAME',26,'orders/5/sessions/6c81ff4c-3cbc-4808-a168-75c9048bec14/videos/2144e047-f718-402b-88da-77d6485ba18c_VID_20260514_141105_00_138.mp4',22,22000,'maklertour_kit_v1','APRILTAG_36H11',5,0.1600,'[[2445.8520507812495,1945.7237548828125],[2473.2939453124995,1947.92333984375],[2475.322998046875,1919.35107421875],[2447.4252929687505,1917.6192626953127]]',2460.345129,1932.754327,57.08277893066406,'2026-05-14 17:13:42.087041'),
(81,32,'VIDEO_FRAME',26,'orders/5/sessions/6c81ff4c-3cbc-4808-a168-75c9048bec14/videos/2144e047-f718-402b-88da-77d6485ba18c_VID_20260514_141105_00_138.mp4',23,23000,'maklertour_kit_v1','APRILTAG_36H11',1,0.1600,'[[275.7822570800781,2125.3540039062495],[338.35235595703125,2117.15869140625],[328.65795898437506,2030.4622802734375],[266.4065246582032,2035.792358398437]]',302.771392,2076.918798,63.0968132019043,'2026-05-14 17:13:42.087903'),
(82,32,'VIDEO_FRAME',26,'orders/5/sessions/6c81ff4c-3cbc-4808-a168-75c9048bec14/videos/2144e047-f718-402b-88da-77d6485ba18c_VID_20260514_141105_00_138.mp4',23,23000,'maklertour_kit_v1','APRILTAG_36H11',3,0.1600,'[[1739.107421875,2069.135498046875],[1817.2723388671873,2078.80908203125],[1821.9290771484373,1992.8131103515623],[1742.739501953125,1985.0129394531248]]',1779.792808,2031.642818,116.38641357421875,'2026-05-14 17:13:42.089052'),
(83,32,'VIDEO_FRAME',26,'orders/5/sessions/6c81ff4c-3cbc-4808-a168-75c9048bec14/videos/2144e047-f718-402b-88da-77d6485ba18c_VID_20260514_141105_00_138.mp4',23,23000,'maklertour_kit_v1','APRILTAG_36H11',5,0.1600,'[[2272.036621093749,1968.0589599609373],[2300.725830078124,1969.822265625],[2302.2429199218755,1940.6527099609373],[2273.5908203125005,1939.9141845703123]]',2286.894963,1954.577949,63.482994079589844,'2026-05-14 17:13:42.090040'),
(84,32,'VIDEO_FRAME',26,'orders/5/sessions/6c81ff4c-3cbc-4808-a168-75c9048bec14/videos/2144e047-f718-402b-88da-77d6485ba18c_VID_20260514_141105_00_138.mp4',24,24000,'maklertour_kit_v1','APRILTAG_36H11',1,0.1600,'[[27.767370223999023,2151.2448730468755],[67.82230377197266,2145.197021484375],[57.33789825439452,2048.531494140625],[17.82613945007324,2054.1066894531255]]',42.690705,2099.408595,88.50209045410156,'2026-05-14 17:13:42.091055'),
(85,32,'VIDEO_FRAME',26,'orders/5/sessions/6c81ff4c-3cbc-4808-a168-75c9048bec14/videos/2144e047-f718-402b-88da-77d6485ba18c_VID_20260514_141105_00_138.mp4',24,24000,'maklertour_kit_v1','APRILTAG_36H11',3,0.1600,'[[1497.0399169921875,2110.875976562501],[1592.4023437499995,2123.486328125],[1595.1689453125,2014.2561035156245],[1499.1977539062505,2004.6857910156252]]',1545.259904,2063.397579,107.06077575683594,'2026-05-14 17:13:42.091980'),
(86,32,'VIDEO_FRAME',26,'orders/5/sessions/6c81ff4c-3cbc-4808-a168-75c9048bec14/videos/2144e047-f718-402b-88da-77d6485ba18c_VID_20260514_141105_00_138.mp4',24,24000,'maklertour_kit_v1','APRILTAG_36H11',5,0.1600,'[[2158.6401367187505,1975.215454101563],[2189.0732421875,1976.1597900390625],[2189.708740234375,1945.744750976562],[2159.92431640625,1945.001220703125]]',2174.296519,1960.364301,70.58719635009766,'2026-05-14 17:13:42.092847'),
(87,32,'VIDEO_FRAME',26,'orders/5/sessions/6c81ff4c-3cbc-4808-a168-75c9048bec14/videos/2144e047-f718-402b-88da-77d6485ba18c_VID_20260514_141105_00_138.mp4',25,25000,'maklertour_kit_v1','APRILTAG_36H11',3,0.1600,'[[1103.9956054687498,2188.264160156249],[1214.7341308593752,2208.474365234375],[1211.935546875,2064.9213867187505],[1099.9796142578123,2049.674072265625]]',1156.650020,2128.096057,113.8744125366211,'2026-05-14 17:13:42.093752'),
(88,32,'VIDEO_FRAME',26,'orders/5/sessions/6c81ff4c-3cbc-4808-a168-75c9048bec14/videos/2144e047-f718-402b-88da-77d6485ba18c_VID_20260514_141105_00_138.mp4',25,25000,'maklertour_kit_v1','APRILTAG_36H11',5,0.1600,'[[1952.923095703125,1989.0852050781255],[1984.6912841796877,1990.0684814453125],[1985.60888671875,1958.45556640625],[1954.5922851562498,1957.240966796875]]',1969.525157,1973.527524,92.67532348632812,'2026-05-14 17:13:42.094703'),
(89,32,'VIDEO_FRAME',26,'orders/5/sessions/6c81ff4c-3cbc-4808-a168-75c9048bec14/videos/2144e047-f718-402b-88da-77d6485ba18c_VID_20260514_141105_00_138.mp4',26,26000,'maklertour_kit_v1','APRILTAG_36H11',3,0.1600,'[[562.9036865234374,2259.15234375],[654.1700439453127,2293.352783203125],[636.2955932617188,2116.978027343749],[545.0172119140623,2089.97509765625]]',598.649759,2189.905288,74.10603332519531,'2026-05-14 17:13:42.095480'),
(90,32,'VIDEO_FRAME',26,'orders/5/sessions/6c81ff4c-3cbc-4808-a168-75c9048bec14/videos/2144e047-f718-402b-88da-77d6485ba18c_VID_20260514_141105_00_138.mp4',26,26000,'maklertour_kit_v1','APRILTAG_36H11',5,0.1600,'[[1732.1817626953125,2005.1322021484373],[1765.6893310546875,2006.5683593749998],[1767.252197265625,1972.89306640625],[1733.3421630859375,1971.4781494140625]]',1749.602754,1989.117639,79.22614288330078,'2026-05-14 17:13:42.098123'),
(91,32,'VIDEO_FRAME',26,'orders/5/sessions/6c81ff4c-3cbc-4808-a168-75c9048bec14/videos/2144e047-f718-402b-88da-77d6485ba18c_VID_20260514_141105_00_138.mp4',27,27000,'maklertour_kit_v1','APRILTAG_36H11',3,0.1600,'[[125.93891906738281,2302.3354492187505],[166.96899414062494,2353.193359375],[129.3352508544922,2146.4155273437495],[94.00279998779301,2107.28515625]]',127.712923,2220.893875,80.20612335205078,'2026-05-14 17:13:42.099049'),
(92,32,'VIDEO_FRAME',26,'orders/5/sessions/6c81ff4c-3cbc-4808-a168-75c9048bec14/videos/2144e047-f718-402b-88da-77d6485ba18c_VID_20260514_141105_00_138.mp4',27,27000,'maklertour_kit_v1','APRILTAG_36H11',5,0.1600,'[[1598.9632568359373,2011.73876953125],[1635.8536376953123,2013.5582275390625],[1636.6783447265627,1976.698974609375],[1600.4942626953123,1975.0657958984373]]',1617.965176,1994.084738,89.92501831054688,'2026-05-14 17:13:42.099996'),
(93,32,'VIDEO_FRAME',26,'orders/5/sessions/6c81ff4c-3cbc-4808-a168-75c9048bec14/videos/2144e047-f718-402b-88da-77d6485ba18c_VID_20260514_141105_00_138.mp4',28,28000,'maklertour_kit_v1','APRILTAG_36H11',5,0.1600,'[[1790.0198974609377,2018.6798095703125],[1828.8287353515623,2021.5263671875],[1831.099609375,1982.0168457031252],[1792.735717773438,1979.415283203125]]',1810.626318,2000.288920,104.49246215820312,'2026-05-14 17:13:42.100882'),
(94,32,'VIDEO_FRAME',26,'orders/5/sessions/6c81ff4c-3cbc-4808-a168-75c9048bec14/videos/2144e047-f718-402b-88da-77d6485ba18c_VID_20260514_141105_00_138.mp4',29,29000,'maklertour_kit_v1','APRILTAG_36H11',4,0.1600,'[[1491.0484619140625,2114.0861816406245],[1552.271728515625,2098.9812011718745],[1551.0400390624998,2014.4766845703125],[1488.5113525390623,2022.774169921875]]',1521.963014,2062.755926,68.79419708251953,'2026-05-14 17:13:42.101728'),
(95,32,'VIDEO_FRAME',26,'orders/5/sessions/6c81ff4c-3cbc-4808-a168-75c9048bec14/videos/2144e047-f718-402b-88da-77d6485ba18c_VID_20260514_141105_00_138.mp4',29,29000,'maklertour_kit_v1','APRILTAG_36H11',5,0.1600,'[[2217.7636718749995,2029.2192382812502],[2261.9067382812495,2031.780029296875],[2262.75341796875,1987.129272460937],[2219.8974609375005,1984.8922119140627]]',2240.529750,2007.920530,84.4946060180664,'2026-05-14 17:13:42.102609'),
(96,32,'VIDEO_FRAME',26,'orders/5/sessions/6c81ff4c-3cbc-4808-a168-75c9048bec14/videos/2144e047-f718-402b-88da-77d6485ba18c_VID_20260514_141105_00_138.mp4',30,30000,'maklertour_kit_v1','APRILTAG_36H11',1,0.1600,'[[133.64074707031253,2046.5594482421877],[159.96649169921878,2046.685791015625],[155.96473693847653,1986.9374999999998],[129.08175659179685,1988.2711181640625]]',144.527224,2017.484317,90.50789642333984,'2026-05-14 17:13:42.103228'),
(97,32,'VIDEO_FRAME',26,'orders/5/sessions/6c81ff4c-3cbc-4808-a168-75c9048bec14/videos/2144e047-f718-402b-88da-77d6485ba18c_VID_20260514_141105_00_138.mp4',30,30000,'maklertour_kit_v1','APRILTAG_36H11',4,0.1600,'[[1683.345947265625,2128.9511718749995],[1762.90283203125,2115.0888671875],[1764.545654296875,2018.6763916015623],[1684.000244140625,2026.192749023437]]',1724.998677,2072.383903,88.15470886230469,'2026-05-14 17:13:42.103898'),
(98,32,'VIDEO_FRAME',26,'orders/5/sessions/6c81ff4c-3cbc-4808-a168-75c9048bec14/videos/2144e047-f718-402b-88da-77d6485ba18c_VID_20260514_141105_00_138.mp4',30,30000,'maklertour_kit_v1','APRILTAG_36H11',5,0.1600,'[[2571.15576171875,2065.260498046875],[2622.322509765625,2071.364990234375],[2627.017822265625,2018.6011962890625],[2576.23388671875,2013.3165283203125]]',2599.006192,2041.998169,93.1980209350586,'2026-05-14 17:13:42.104593'),
(99,32,'VIDEO_FRAME',26,'orders/5/sessions/6c81ff4c-3cbc-4808-a168-75c9048bec14/videos/2144e047-f718-402b-88da-77d6485ba18c_VID_20260514_141105_00_138.mp4',31,31000,'maklertour_kit_v1','APRILTAG_36H11',4,0.1600,'[[1678.2165527343748,2174.8864746093755],[1790.6075439453125,2153.883544921875],[1786.630859375,2032.1040039062498],[1672.8540039062498,2045.175170898438]]',1733.908478,2101.539783,88.60124969482422,'2026-05-14 17:13:42.105630'),
(100,32,'VIDEO_FRAME',26,'orders/5/sessions/6c81ff4c-3cbc-4808-a168-75c9048bec14/videos/2144e047-f718-402b-88da-77d6485ba18c_VID_20260514_141105_00_138.mp4',31,31000,'maklertour_kit_v1','APRILTAG_36H11',5,0.1600,'[[2825.1130371093745,2057.366455078125],[2885.6394042968745,2063.14599609375],[2890.3554687500005,1998.3354492187502],[2830.5634765625014,1992.8684082031255]]',2857.877450,2027.721388,92.6289291381836,'2026-05-14 17:13:42.106458'),
(101,32,'VIDEO_FRAME',26,'orders/5/sessions/6c81ff4c-3cbc-4808-a168-75c9048bec14/videos/2144e047-f718-402b-88da-77d6485ba18c_VID_20260514_141105_00_138.mp4',32,32000,'maklertour_kit_v1','APRILTAG_36H11',4,0.1600,'[[1204.5104980468752,2260.7255859375005],[1365.267333984375,2233.244873046875],[1356.7036132812498,2066.4514160156245],[1191.616455078125,2083.005126953125]]',1282.283422,2161.448623,88.97300720214844,'2026-05-14 17:13:42.107195'),
(102,32,'VIDEO_FRAME',26,'orders/5/sessions/6c81ff4c-3cbc-4808-a168-75c9048bec14/videos/2144e047-f718-402b-88da-77d6485ba18c_VID_20260514_141105_00_138.mp4',32,32000,'maklertour_kit_v1','APRILTAG_36H11',5,0.1600,'[[2649.0998535156255,2101.89111328125],[2714.7573242187505,2109.84716796875],[2722.547607421875,2040.5295410156255],[2657.9416503906245,2033.6240234374998]]',2685.906448,2071.141221,88.87615203857422,'2026-05-14 17:13:42.107853'),
(103,32,'VIDEO_FRAME',26,'orders/5/sessions/6c81ff4c-3cbc-4808-a168-75c9048bec14/videos/2144e047-f718-402b-88da-77d6485ba18c_VID_20260514_141105_00_138.mp4',33,33000,'maklertour_kit_v1','APRILTAG_36H11',4,0.1600,'[[501.65478515624994,2333.41845703125],[693.537353515625,2301.6677246093755],[655.4622802734376,2078.621826171875],[458.1364440917969,2098.2548828124995]]',580.029168,2203.583895,62.41667556762695,'2026-05-14 17:13:42.108612'),
(104,32,'VIDEO_FRAME',26,'orders/5/sessions/6c81ff4c-3cbc-4808-a168-75c9048bec14/videos/2144e047-f718-402b-88da-77d6485ba18c_VID_20260514_141105_00_138.mp4',33,33000,'maklertour_kit_v1','APRILTAG_36H11',5,0.1600,'[[2450.2934570312495,2083.173095703125],[2527.9130859375,2089.614990234375],[2534.1040039062505,2011.4970703124998],[2457.3103027343745,2005.54833984375]]',2492.318547,2047.232614,82.1010971069336,'2026-05-14 17:13:42.109255'),
(105,32,'VIDEO_FRAME',26,'orders/5/sessions/6c81ff4c-3cbc-4808-a168-75c9048bec14/videos/2144e047-f718-402b-88da-77d6485ba18c_VID_20260514_141105_00_138.mp4',34,34000,'maklertour_kit_v1','APRILTAG_36H11',5,0.1600,'[[2460.4143066406255,2113.7016601562495],[2554.0917968750005,2124.517333984375],[2566.61279296875,2029.6210937500005],[2472.917724609375,2019.2911376953123]]',2513.391783,2071.757783,92.07829284667969,'2026-05-14 17:13:42.111111'),
(106,32,'VIDEO_FRAME',26,'orders/5/sessions/6c81ff4c-3cbc-4808-a168-75c9048bec14/videos/2144e047-f718-402b-88da-77d6485ba18c_VID_20260514_141105_00_138.mp4',35,35000,'maklertour_kit_v1','APRILTAG_36H11',5,0.1600,'[[2440.1499023437495,2198.5588378906255],[2560.831054687499,2213.28564453125],[2580.1520996093755,2090.683837890625],[2458.1953125000005,2076.197265625]]',2509.689490,2144.976943,98.8423843383789,'2026-05-14 17:13:42.112016'),
(107,32,'VIDEO_FRAME',26,'orders/5/sessions/6c81ff4c-3cbc-4808-a168-75c9048bec14/videos/2144e047-f718-402b-88da-77d6485ba18c_VID_20260514_141105_00_138.mp4',36,36000,'maklertour_kit_v1','APRILTAG_36H11',5,0.1600,'[[2129.0512695312505,2287.177734375],[2293.9399414062505,2304.86572265625],[2318.58056640625,2142.1555175781255],[2151.5234375,2123.203369140625]]',2223.447949,2214.948185,113.33045196533203,'2026-05-14 17:13:42.112726'),
(108,32,'VIDEO_FRAME',26,'orders/5/sessions/6c81ff4c-3cbc-4808-a168-75c9048bec14/videos/2144e047-f718-402b-88da-77d6485ba18c_VID_20260514_141105_00_138.mp4',37,37000,'maklertour_kit_v1','APRILTAG_36H11',5,0.1600,'[[1615.7489013671873,2438.43505859375],[1823.1383056640625,2440.40234375],[1841.8748779296873,2245.9299316406245],[1625.93994140625,2233.4699707031255]]',1729.213147,2341.840898,86.60250091552734,'2026-05-14 17:13:42.113606'),
(109,32,'VIDEO_FRAME',26,'orders/5/sessions/6c81ff4c-3cbc-4808-a168-75c9048bec14/videos/2144e047-f718-402b-88da-77d6485ba18c_VID_20260514_141105_00_138.mp4',38,38000,'maklertour_kit_v1','APRILTAG_36H11',5,0.1600,'[[1083.1153564453123,2516.4707031250005],[1283.6910400390627,2473.3217773437505],[1280.61083984375,2267.1391601562495],[1061.0593261718748,2286.3081054687505]]',1183.775131,2389.391053,109.0492172241211,'2026-05-14 17:13:42.114338'),
(110,32,'VIDEO_FRAME',26,'orders/5/sessions/6c81ff4c-3cbc-4808-a168-75c9048bec14/videos/2144e047-f718-402b-88da-77d6485ba18c_VID_20260514_141105_00_138.mp4',52,52000,'maklertour_kit_v1','APRILTAG_36H11',1,0.1600,'[[2439.0222167968745,1976.2819824218755],[2474.2592773437495,1979.6008300781252],[2476.966796875,1938.8618164062495],[2441.5961914062505,1936.350830078125]]',2457.781398,1957.782063,156.54122924804688,'2026-05-14 17:13:42.114925'),
(111,32,'VIDEO_FRAME',26,'orders/5/sessions/6c81ff4c-3cbc-4808-a168-75c9048bec14/videos/2144e047-f718-402b-88da-77d6485ba18c_VID_20260514_141105_00_138.mp4',53,53000,'maklertour_kit_v1','APRILTAG_36H11',1,0.1600,'[[2528.947265625,2002.9475097656255],[2569.66064453125,2005.6192626953127],[2570.8596191406245,1957.4346923828123],[2529.7219238281245,1956.2249755859375]]',2549.475740,1980.655545,141.39859008789062,'2026-05-14 17:13:42.115573'),
(112,32,'VIDEO_FRAME',26,'orders/5/sessions/6c81ff4c-3cbc-4808-a168-75c9048bec14/videos/2144e047-f718-402b-88da-77d6485ba18c_VID_20260514_141105_00_138.mp4',54,54000,'maklertour_kit_v1','APRILTAG_36H11',1,0.1600,'[[2948.3278808593745,2026.0286865234377],[2999.8154296875,2029.2508544921875],[3000.14306640625,1963.8526611328123],[2947.728759765625,1963.3453369140627]]',2973.447023,1995.886781,114.4394302368164,'2026-05-14 17:13:42.116132'),
(113,32,'VIDEO_FRAME',26,'orders/5/sessions/6c81ff4c-3cbc-4808-a168-75c9048bec14/videos/2144e047-f718-402b-88da-77d6485ba18c_VID_20260514_141105_00_138.mp4',55,55000,'maklertour_kit_v1','APRILTAG_36H11',1,0.1600,'[[3439.0419921875005,2038.3494873046877],[3501.851562500001,2042.75048828125],[3503.57861328125,1952.2706298828123],[3441.4892578124995,1952.349853515625]]',3470.709616,1996.111253,95.90042114257812,'2026-05-14 17:13:42.116663'),
(114,32,'VIDEO_FRAME',26,'orders/5/sessions/6c81ff4c-3cbc-4808-a168-75c9048bec14/videos/2144e047-f718-402b-88da-77d6485ba18c_VID_20260514_141105_00_138.mp4',55,55000,'maklertour_kit_v1','APRILTAG_36H11',2,0.1600,'[[831.515686035156,2025.833984375],[878.8648071289062,2019.991577148437],[875.1397705078126,1958.32373046875],[827.0526733398435,1962.4449462890625]]',853.497303,1991.816432,81.52743530273438,'2026-05-14 17:13:42.117516'),
(115,32,'VIDEO_FRAME',26,'orders/5/sessions/6c81ff4c-3cbc-4808-a168-75c9048bec14/videos/2144e047-f718-402b-88da-77d6485ba18c_VID_20260514_141105_00_138.mp4',56,56000,'maklertour_kit_v1','APRILTAG_36H11',2,0.1600,'[[1165.4483642578127,1930.8995361328125],[1220.3883056640627,1928.40087890625],[1220.3284912109375,1865.630126953125],[1165.073486328125,1866.875]]',1193.084671,1898.031438,113.75106048583984,'2026-05-14 17:13:42.118769'),
(116,32,'VIDEO_FRAME',26,'orders/5/sessions/6c81ff4c-3cbc-4808-a168-75c9048bec14/videos/2144e047-f718-402b-88da-77d6485ba18c_VID_20260514_141105_00_138.mp4',57,57000,'maklertour_kit_v1','APRILTAG_36H11',2,0.1600,'[[1393.5279541015625,1997.9099121093748],[1457.2692871093755,1991.645751953125],[1453.0250244140623,1924.2099609374998],[1388.8572998046873,1928.9201660156248]]',1423.546253,1960.725775,116.99034118652344,'2026-05-14 17:13:42.119636'),
(117,32,'VIDEO_FRAME',26,'orders/5/sessions/6c81ff4c-3cbc-4808-a168-75c9048bec14/videos/2144e047-f718-402b-88da-77d6485ba18c_VID_20260514_141105_00_138.mp4',58,58000,'maklertour_kit_v1','APRILTAG_36H11',2,0.1600,'[[1834.8941650390627,1941.7269287109377],[1911.8613281249998,1938.4903564453123],[1909.2847900390623,1860.3027343749998],[1832.6877441406248,1863.000732421875]]',1872.307120,1900.776612,119.0187759399414,'2026-05-14 17:13:42.120486'),
(118,32,'VIDEO_FRAME',26,'orders/5/sessions/6c81ff4c-3cbc-4808-a168-75c9048bec14/videos/2144e047-f718-402b-88da-77d6485ba18c_VID_20260514_141105_00_138.mp4',59,59000,'maklertour_kit_v1','APRILTAG_36H11',2,0.1600,'[[2085.221435546875,1831.5280761718745],[2173.718017578125,1824.8280029296873],[2166.91845703125,1736.015869140625],[2078.3735351562505,1742.869873046875]]',2126.021767,1783.828299,118.785888671875,'2026-05-14 17:13:42.121328'),
(119,32,'VIDEO_FRAME',26,'orders/5/sessions/6c81ff4c-3cbc-4808-a168-75c9048bec14/videos/2144e047-f718-402b-88da-77d6485ba18c_VID_20260514_141105_00_138.mp4',59,59000,'maklertour_kit_v1','APRILTAG_36H11',5,0.1600,'[[179.35726928710938,2040.6276855468757],[204.09191894531256,2038.38623046875],[201.01678466796875,1998.3615722656245],[176.11274719238273,2003.2059326171875]]',189.748246,2020.350861,21.261411666870117,'2026-05-14 17:13:42.122104'),
(120,32,'VIDEO_FRAME',26,'orders/5/sessions/6c81ff4c-3cbc-4808-a168-75c9048bec14/videos/2144e047-f718-402b-88da-77d6485ba18c_VID_20260514_141105_00_138.mp4',60,60000,'maklertour_kit_v1','APRILTAG_36H11',2,0.1600,'[[2057.34765625,1846.3522949218748],[2164.7255859375,1838.240966796875],[2155.4758300781245,1731.2795410156248],[2049.150390625,1739.9017333984373]]',2106.506791,1788.704458,115.89241027832031,'2026-05-14 17:13:42.122857'),
(121,32,'VIDEO_FRAME',26,'orders/5/sessions/6c81ff4c-3cbc-4808-a168-75c9048bec14/videos/2144e047-f718-402b-88da-77d6485ba18c_VID_20260514_141105_00_138.mp4',61,61000,'maklertour_kit_v1','APRILTAG_36H11',2,0.1600,'[[3331.158203125,1751.8184814453125],[3457.299316406251,1738.4639892578125],[3427.946533203125,1575.1988525390625],[3305.2814941406245,1594.716064453125]]',3379.033356,1664.455763,106.30718231201172,'2026-05-14 17:13:42.123635'),
(122,32,'VIDEO_FRAME',26,'orders/5/sessions/6c81ff4c-3cbc-4808-a168-75c9048bec14/videos/2144e047-f718-402b-88da-77d6485ba18c_VID_20260514_141105_00_138.mp4',61,61000,'maklertour_kit_v1','APRILTAG_36H11',3,0.1600,'[[641.7968139648439,1931.7692871093752],[689.0406494140626,1935.8712158203125],[692.8189697265624,1870.6964111328125],[645.232177734375,1865.302001953125]]',667.439670,1901.075112,64.28189849853516,'2026-05-14 17:13:42.124477'),
(123,32,'VIDEO_FRAME',26,'orders/5/sessions/6c81ff4c-3cbc-4808-a168-75c9048bec14/videos/2144e047-f718-402b-88da-77d6485ba18c_VID_20260514_141105_00_138.mp4',62,62000,'maklertour_kit_v1','APRILTAG_36H11',1,0.1600,'[[78.93418884277345,1934.39794921875],[117.56525421142578,1932.4066162109375],[118.02995300292969,1863.3154296875],[79.46297454833986,1863.3336181640623]]',98.769778,1898.333591,78.73304748535156,'2026-05-14 17:13:42.125168'),
(124,32,'VIDEO_FRAME',26,'orders/5/sessions/6c81ff4c-3cbc-4808-a168-75c9048bec14/videos/2144e047-f718-402b-88da-77d6485ba18c_VID_20260514_141105_00_138.mp4',62,62000,'maklertour_kit_v1','APRILTAG_36H11',3,0.1600,'[[1050.8513183593752,1911.7001953125005],[1096.9328613281248,1915.327880859375],[1100.0533447265625,1856.23291015625],[1054.6784667968755,1854.1605224609377]]',1075.348964,1884.083083,110.38542938232422,'2026-05-14 17:13:42.125901'),
(125,32,'VIDEO_FRAME',26,'orders/5/sessions/6c81ff4c-3cbc-4808-a168-75c9048bec14/videos/2144e047-f718-402b-88da-77d6485ba18c_VID_20260514_141105_00_138.mp4',62,62000,'maklertour_kit_v1','APRILTAG_36H11',5,0.1600,'[[1647.0291748046875,1930.4027099609377],[1672.1672363281248,1930.7197265625],[1671.9403076171875,1905.2587890624995],[1647.8320312500002,1905.5899658203123]]',1659.586410,1917.728131,29.332740783691406,'2026-05-14 17:13:42.128232'),
(126,32,'VIDEO_FRAME',26,'orders/5/sessions/6c81ff4c-3cbc-4808-a168-75c9048bec14/videos/2144e047-f718-402b-88da-77d6485ba18c_VID_20260514_141105_00_138.mp4',63,63000,'maklertour_kit_v1','APRILTAG_36H11',1,0.1600,'[[89.27378845214842,1927.3878173828125],[128.51840209960938,1926.9492187500002],[129.6677398681641,1857.8522949218752],[90.38301086425786,1856.5030517578125]]',109.710871,1892.206728,78.9068603515625,'2026-05-14 17:13:42.128927'),
(127,32,'VIDEO_FRAME',26,'orders/5/sessions/6c81ff4c-3cbc-4808-a168-75c9048bec14/videos/2144e047-f718-402b-88da-77d6485ba18c_VID_20260514_141105_00_138.mp4',63,63000,'maklertour_kit_v1','APRILTAG_36H11',3,0.1600,'[[1065.658569335937,1914.5283203125],[1111.6363525390623,1917.7459716796875],[1114.6737060546875,1859.211669921875],[1069.1906738281248,1856.6104736328125]]',1090.184851,1886.848876,111.9163818359375,'2026-05-14 17:13:42.129788'),
(128,32,'VIDEO_FRAME',26,'orders/5/sessions/6c81ff4c-3cbc-4808-a168-75c9048bec14/videos/2144e047-f718-402b-88da-77d6485ba18c_VID_20260514_141105_00_138.mp4',63,63000,'maklertour_kit_v1','APRILTAG_36H11',5,0.1600,'[[1659.09912109375,1938.2893066406252],[1683.49853515625,1938.787353515625],[1684.1706542968748,1913.3457031249998],[1659.603515625,1913.4744873046875]]',1671.439071,1926.012323,39.70768356323242,'2026-05-14 17:13:42.130554'),
(129,32,'VIDEO_FRAME',26,'orders/5/sessions/6c81ff4c-3cbc-4808-a168-75c9048bec14/videos/2144e047-f718-402b-88da-77d6485ba18c_VID_20260514_141105_00_138.mp4',64,64000,'maklertour_kit_v1','APRILTAG_36H11',1,0.1600,'[[88.8750534057617,1927.4539794921875],[128.44122314453128,1926.9085693359375],[129.16256713867185,1857.8645019531248],[90.21221923828124,1856.2677001953125]]',109.477552,1891.866846,78.45250701904297,'2026-05-14 17:13:42.131280'),
(130,32,'VIDEO_FRAME',26,'orders/5/sessions/6c81ff4c-3cbc-4808-a168-75c9048bec14/videos/2144e047-f718-402b-88da-77d6485ba18c_VID_20260514_141105_00_138.mp4',64,64000,'maklertour_kit_v1','APRILTAG_36H11',3,0.1600,'[[1064.9902343749998,1914.9376220703123],[1111.0717773437502,1918.35888671875],[1114.216064453125,1859.6281738281255],[1068.455932617187,1857.0222167968752]]',1089.534339,1887.360212,114.05524444580078,'2026-05-14 17:13:42.131909'),
(131,32,'VIDEO_FRAME',26,'orders/5/sessions/6c81ff4c-3cbc-4808-a168-75c9048bec14/videos/2144e047-f718-402b-88da-77d6485ba18c_VID_20260514_141105_00_138.mp4',64,64000,'maklertour_kit_v1','APRILTAG_36H11',5,0.1600,'[[1658.4177246093752,1938.7559814453127],[1683.2762451171875,1939.0004882812502],[1683.61376953125,1914.1940917968748],[1659.408447265625,1913.9890136718745]]',1671.175201,1926.319596,40.848758697509766,'2026-05-14 17:13:42.132587');
/*!40000 ALTER TABLE `marker_detections` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `marker_kit_layout`
--

DROP TABLE IF EXISTS `marker_kit_layout`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `marker_kit_layout` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `marker_kit_id` varchar(64) NOT NULL DEFAULT 'maklertour_kit_v1',
  `marker_dictionary` varchar(64) NOT NULL DEFAULT 'APRILTAG_36H11',
  `marker_id` int(11) NOT NULL,
  `x_m` decimal(10,4) NOT NULL DEFAULT 0.0000,
  `y_m` decimal(10,4) NOT NULL DEFAULT 0.0000,
  `z_m` decimal(10,4) NOT NULL DEFAULT 1.2000,
  `yaw_deg` decimal(8,3) DEFAULT 0.000,
  `pitch_deg` decimal(8,3) DEFAULT 0.000,
  `roll_deg` decimal(8,3) DEFAULT 0.000,
  `marker_size_m` decimal(8,4) NOT NULL DEFAULT 0.1600,
  `created_at` datetime(6) NOT NULL DEFAULT current_timestamp(6),
  `center_x_m` decimal(10,4) NOT NULL DEFAULT 0.0000,
  `center_y_m` decimal(10,4) NOT NULL DEFAULT 0.0000,
  `center_z_m` decimal(10,4) NOT NULL DEFAULT 1.2000,
  `surface_type` varchar(32) DEFAULT NULL,
  `note` varchar(255) DEFAULT NULL,
  `updated_at` datetime(6) NOT NULL DEFAULT current_timestamp(6) ON UPDATE current_timestamp(6),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_marker` (`marker_kit_id`,`marker_dictionary`,`marker_id`)
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `marker_kit_layout`
--

LOCK TABLES `marker_kit_layout` WRITE;
/*!40000 ALTER TABLE `marker_kit_layout` DISABLE KEYS */;
INSERT INTO `marker_kit_layout` VALUES
(1,'maklertour_kit_v1','APRILTAG_36H11',1,0.0000,0.0000,1.2000,0.000,0.000,0.000,0.1600,'2026-05-14 22:04:07.134040',0.0000,0.0000,1.2000,NULL,NULL,'2026-05-14 22:04:07.134040'),
(2,'maklertour_kit_v1','APRILTAG_36H11',2,0.0000,0.0000,1.2000,0.000,0.000,0.000,0.1600,'2026-05-14 22:04:07.134040',0.0000,0.0000,1.2000,NULL,NULL,'2026-05-14 22:04:07.134040'),
(3,'maklertour_kit_v1','APRILTAG_36H11',3,0.0000,0.0000,1.2000,0.000,0.000,0.000,0.1600,'2026-05-14 22:04:07.134040',0.0000,0.0000,1.2000,NULL,NULL,'2026-05-14 22:04:07.134040'),
(4,'maklertour_kit_v1','APRILTAG_36H11',4,0.0000,0.0000,1.2000,0.000,0.000,0.000,0.1600,'2026-05-14 22:04:07.134040',0.0000,0.0000,1.2000,NULL,NULL,'2026-05-14 22:04:07.134040'),
(5,'maklertour_kit_v1','APRILTAG_36H11',5,0.0000,0.0000,1.2000,0.000,0.000,0.000,0.1600,'2026-05-14 22:04:07.134040',0.0000,0.0000,1.2000,NULL,NULL,'2026-05-14 22:04:07.134040'),
(6,'maklertour_kit_v1','APRILTAG_36H11',6,0.0000,0.0000,1.2000,0.000,0.000,0.000,0.1600,'2026-05-14 22:04:07.134040',0.0000,0.0000,1.2000,NULL,NULL,'2026-05-14 22:04:07.134040'),
(7,'maklertour_kit_v1','APRILTAG_36H11',7,0.0000,0.0000,1.2000,0.000,0.000,0.000,0.1600,'2026-05-14 22:04:07.134040',0.0000,0.0000,1.2000,NULL,NULL,'2026-05-14 22:04:07.134040'),
(8,'maklertour_kit_v1','APRILTAG_36H11',8,0.0000,0.0000,1.2000,0.000,0.000,0.000,0.1600,'2026-05-14 22:04:07.134040',0.0000,0.0000,1.2000,NULL,NULL,'2026-05-14 22:04:07.134040'),
(9,'maklertour_kit_v1','APRILTAG_36H11',9,0.0000,0.0000,1.2000,0.000,0.000,0.000,0.1600,'2026-05-14 22:04:07.134040',0.0000,0.0000,1.2000,NULL,NULL,'2026-05-14 22:04:07.134040'),
(10,'maklertour_kit_v1','APRILTAG_36H11',10,0.0000,0.0000,1.2000,0.000,0.000,0.000,0.1600,'2026-05-14 22:04:07.134040',0.0000,0.0000,1.2000,NULL,NULL,'2026-05-14 22:04:07.134040'),
(11,'maklertour_kit_v1','APRILTAG_36H11',11,0.0000,0.0000,1.2000,0.000,0.000,0.000,0.1600,'2026-05-14 22:04:07.134040',0.0000,0.0000,1.2000,NULL,NULL,'2026-05-14 22:04:07.134040'),
(12,'maklertour_kit_v1','APRILTAG_36H11',12,0.0000,0.0000,1.2000,0.000,0.000,0.000,0.1600,'2026-05-14 22:04:07.134040',0.0000,0.0000,1.2000,NULL,NULL,'2026-05-14 22:04:07.134040'),
(13,'maklertour_kit_v1','APRILTAG_36H11',13,0.0000,0.0000,1.2000,0.000,0.000,0.000,0.1600,'2026-05-14 22:04:07.134040',0.0000,0.0000,1.2000,NULL,NULL,'2026-05-14 22:04:07.134040'),
(14,'maklertour_kit_v1','APRILTAG_36H11',14,0.0000,0.0000,1.2000,0.000,0.000,0.000,0.1600,'2026-05-14 22:04:07.134040',0.0000,0.0000,1.2000,NULL,NULL,'2026-05-14 22:04:07.134040'),
(15,'maklertour_kit_v1','APRILTAG_36H11',15,0.0000,0.0000,1.2000,0.000,0.000,0.000,0.1600,'2026-05-14 22:04:07.134040',0.0000,0.0000,1.2000,NULL,NULL,'2026-05-14 22:04:07.134040'),
(16,'maklertour_kit_v1','APRILTAG_36H11',16,0.0000,0.0000,1.2000,0.000,0.000,0.000,0.1600,'2026-05-14 22:04:07.134040',0.0000,0.0000,1.2000,NULL,NULL,'2026-05-14 22:04:07.134040'),
(17,'maklertour_kit_v1','APRILTAG_36H11',17,0.0000,0.0000,1.2000,0.000,0.000,0.000,0.1600,'2026-05-14 22:04:07.134040',0.0000,0.0000,1.2000,NULL,NULL,'2026-05-14 22:04:07.134040'),
(18,'maklertour_kit_v1','APRILTAG_36H11',18,0.0000,0.0000,1.2000,0.000,0.000,0.000,0.1600,'2026-05-14 22:04:07.134040',0.0000,0.0000,1.2000,NULL,NULL,'2026-05-14 22:04:07.134040'),
(19,'maklertour_kit_v1','APRILTAG_36H11',19,0.0000,0.0000,1.2000,0.000,0.000,0.000,0.1600,'2026-05-14 22:04:07.134040',0.0000,0.0000,1.2000,NULL,NULL,'2026-05-14 22:04:07.134040'),
(20,'maklertour_kit_v1','APRILTAG_36H11',20,0.0000,0.0000,1.2000,0.000,0.000,0.000,0.1600,'2026-05-14 22:04:07.134040',0.0000,0.0000,1.2000,NULL,NULL,'2026-05-14 22:04:07.134040'),
(21,'maklertour_kit_v1','APRILTAG_36H11',21,0.0000,0.0000,1.2000,0.000,0.000,0.000,0.1600,'2026-05-14 22:04:07.134040',0.0000,0.0000,1.2000,NULL,NULL,'2026-05-14 22:04:07.134040'),
(22,'maklertour_kit_v1','APRILTAG_36H11',22,0.0000,0.0000,1.2000,0.000,0.000,0.000,0.1600,'2026-05-14 22:04:07.134040',0.0000,0.0000,1.2000,NULL,NULL,'2026-05-14 22:04:07.134040'),
(23,'maklertour_kit_v1','APRILTAG_36H11',23,0.0000,0.0000,1.2000,0.000,0.000,0.000,0.1600,'2026-05-14 22:04:07.134040',0.0000,0.0000,1.2000,NULL,NULL,'2026-05-14 22:04:07.134040'),
(24,'maklertour_kit_v1','APRILTAG_36H11',24,0.0000,0.0000,1.2000,0.000,0.000,0.000,0.1600,'2026-05-14 22:04:07.134040',0.0000,0.0000,1.2000,NULL,NULL,'2026-05-14 22:04:07.134040'),
(25,'maklertour_kit_v1','APRILTAG_36H11',25,0.0000,0.0000,1.2000,0.000,0.000,0.000,0.1600,'2026-05-14 22:04:07.134040',0.0000,0.0000,1.2000,NULL,NULL,'2026-05-14 22:04:07.134040'),
(26,'maklertour_kit_v1','APRILTAG_36H11',26,0.0000,0.0000,1.2000,0.000,0.000,0.000,0.1600,'2026-05-14 22:04:07.134040',0.0000,0.0000,1.2000,NULL,NULL,'2026-05-14 22:04:07.134040'),
(27,'maklertour_kit_v1','APRILTAG_36H11',27,0.0000,0.0000,1.2000,0.000,0.000,0.000,0.1600,'2026-05-14 22:04:07.134040',0.0000,0.0000,1.2000,NULL,NULL,'2026-05-14 22:04:07.134040'),
(28,'maklertour_kit_v1','APRILTAG_36H11',28,0.0000,0.0000,1.2000,0.000,0.000,0.000,0.1600,'2026-05-14 22:04:07.134040',0.0000,0.0000,1.2000,NULL,NULL,'2026-05-14 22:04:07.134040'),
(29,'maklertour_kit_v1','APRILTAG_36H11',29,0.0000,0.0000,1.2000,0.000,0.000,0.000,0.1600,'2026-05-14 22:04:07.134040',0.0000,0.0000,1.2000,NULL,NULL,'2026-05-14 22:04:07.134040'),
(30,'maklertour_kit_v1','APRILTAG_36H11',30,0.0000,0.0000,1.2000,0.000,0.000,0.000,0.1600,'2026-05-14 22:04:07.134040',0.0000,0.0000,1.2000,NULL,NULL,'2026-05-14 22:04:07.134040');
/*!40000 ALTER TABLE `marker_kit_layout` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `menu_groups`
--

DROP TABLE IF EXISTS `menu_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `menu_groups` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(64) NOT NULL,
  `title` varchar(128) NOT NULL,
  `icon` varchar(64) DEFAULT NULL,
  `sort_order` int(11) NOT NULL DEFAULT 100,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_menu_groups_code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `menu_groups`
--

LOCK TABLES `menu_groups` WRITE;
/*!40000 ALTER TABLE `menu_groups` DISABLE KEYS */;
INSERT INTO `menu_groups` VALUES
(1,'main','MaklerTour','bi bi-house',10,1),
(2,'admin','Admin','bi bi-gear',90,1);
/*!40000 ALTER TABLE `menu_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `menu_items`
--

DROP TABLE IF EXISTS `menu_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `menu_items` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `group_code` varchar(64) NOT NULL,
  `menu_key` varchar(128) NOT NULL,
  `title` varchar(128) NOT NULL,
  `icon` varchar(64) DEFAULT NULL,
  `action` varchar(128) DEFAULT NULL,
  `url` varchar(255) DEFAULT NULL,
  `sort_order` int(11) NOT NULL DEFAULT 100,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_menu_items_key` (`menu_key`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `menu_items`
--

LOCK TABLES `menu_items` WRITE;
/*!40000 ALTER TABLE `menu_items` DISABLE KEYS */;
INSERT INTO `menu_items` VALUES
(1,'main','orders','Заявки','bi bi-list-task','view_orders','/orders.php',10,1),
(2,'main','operator_orders','Рынок заявок','bi bi-camera-video','view_market','/market.php',20,1),
(3,'admin','users','Пользователи','bi bi-people','view_users','/main.php?page=users',10,1),
(4,'admin','audit','Аудит','bi bi-clock-history','view_audit','/audit.php',20,1);
/*!40000 ALTER TABLE `menu_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mobile_tokens`
--

DROP TABLE IF EXISTS `mobile_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mobile_tokens` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `token_hash` char(64) NOT NULL,
  `device_name` varchar(190) DEFAULT NULL,
  `device_fingerprint` varchar(190) DEFAULT NULL,
  `expires_at` datetime(6) DEFAULT NULL,
  `last_used_at` datetime(6) DEFAULT NULL,
  `created_at` datetime(6) NOT NULL DEFAULT current_timestamp(6),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_mobile_token_hash` (`token_hash`),
  KEY `idx_mobile_tokens_user` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mobile_tokens`
--

LOCK TABLES `mobile_tokens` WRITE;
/*!40000 ALTER TABLE `mobile_tokens` DISABLE KEYS */;
INSERT INTO `mobile_tokens` VALUES
(1,1,'a1e7033e201976eca08a2e9d10f1b9021abf034891be2fc6eee043d3ef9523d3','test-phone','test-device-001','2026-08-08 16:43:04.740160','2026-05-10 17:24:01.321757','2026-05-10 16:43:04.740160'),
(2,1,'340adb5ef6fcf4ff3a7cf0bc21bb5f18db4cf7e6b6e63bcba477db603aa69751','test-phone','test-device-001','2026-08-08 18:50:33.606617',NULL,'2026-05-10 18:50:33.606617'),
(5,1,'62d8d2eebbd744a6e6e3737cb957b677a4fe3a3cfd5ccb536796f7e9124d28e5','curl-test','curl-test-001','2026-08-09 08:28:22.278118','2026-05-11 08:28:31.730456','2026-05-11 08:28:22.278118'),
(8,2,'5a41ba452bfb474926ff1291a8c700b1eb446728ec103cacbd6d7750f36b8116','motorola motorola edge 50 neo','969117b65b9b580f','2026-08-09 13:33:58.214948','2026-05-14 16:24:59.640548','2026-05-11 13:33:58.214948'),
(9,2,'81f65e5ed73ca915ba99eb64db7221d3106ab491823c7c10dbb8b1d7c7d09f28','curl-test','curl-upload-test','2026-08-09 15:18:21.742299','2026-05-11 15:20:36.670126','2026-05-11 15:18:21.742299');
/*!40000 ALTER TABLE `mobile_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `photo_points`
--

DROP TABLE IF EXISTS `photo_points`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `photo_points` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `session_id` bigint(20) unsigned NOT NULL,
  `app_point_uuid` varchar(128) NOT NULL,
  `name` varchar(255) NOT NULL,
  `room_name` varchar(255) DEFAULT NULL,
  `sequence_number` int(11) DEFAULT NULL,
  `camera_file_url` text DEFAULT NULL,
  `camera_local_path` text DEFAULT NULL,
  `preview_storage_path` text DEFAULT NULL,
  `original_storage_path` text DEFAULT NULL,
  `preview_size_bytes` bigint(20) unsigned DEFAULT NULL,
  `original_size_bytes` bigint(20) unsigned DEFAULT NULL,
  `upload_state` varchar(32) NOT NULL DEFAULT 'LOCAL_ONLY',
  `initial_yaw_deg` decimal(8,3) DEFAULT 0.000,
  `initial_pitch_deg` decimal(8,3) DEFAULT 0.000,
  `initial_hfov` decimal(8,3) DEFAULT 100.000,
  `created_at` datetime(6) NOT NULL DEFAULT current_timestamp(6),
  `updated_at` datetime(6) NOT NULL DEFAULT current_timestamp(6) ON UPDATE current_timestamp(6),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_photo_points_app_uuid` (`app_point_uuid`),
  KEY `idx_photo_points_session_id` (`session_id`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `photo_points`
--

LOCK TABLES `photo_points` WRITE;
/*!40000 ALTER TABLE `photo_points` DISABLE KEYS */;
INSERT INTO `photo_points` VALUES
(1,4,'2b6ac6de-48c6-4e2e-816c-112868c8a8b5','Точка 1',NULL,NULL,'http://192.168.42.1:80/DCIM/Camera01/IMG_20260511_140734_00_127.jpg','/DCIM/Camera01/IMG_20260511_140734_00_127.jpg','orders/4/sessions/192c4533-fe07-45e1-881b-c3c41f95a563/photos/previews/2b6ac6de-48c6-4e2e-816c-112868c8a8b5_2b6ac6de-48c6-4e2e-816c-112868c8a8b5.jpg','orders/4/sessions/192c4533-fe07-45e1-881b-c3c41f95a563/photos/originals/2b6ac6de-48c6-4e2e-816c-112868c8a8b5_2b6ac6de-48c6-4e2e-816c-112868c8a8b5.jpg',12249031,12249031,'UPLOADED',0.000,0.000,100.000,'2026-05-11 22:56:11.586169','2026-05-12 10:23:34.186206'),
(3,12,'2d999854-e210-4cd9-adc4-67eaef8457c6','Точка 2',NULL,NULL,'http://192.168.42.1:80/DCIM/Camera01/IMG_20260512_200822_00_130.jpg','/DCIM/Camera01/IMG_20260512_200822_00_130.jpg','orders/4/sessions/1674181c-1f00-4e96-9ea2-1914671e4b74/photos/previews/2d999854-e210-4cd9-adc4-67eaef8457c6_2d999854-e210-4cd9-adc4-67eaef8457c6.jpg','orders/4/sessions/1674181c-1f00-4e96-9ea2-1914671e4b74/photos/originals/2d999854-e210-4cd9-adc4-67eaef8457c6_2d999854-e210-4cd9-adc4-67eaef8457c6.jpg',12256508,12256508,'UPLOADED',0.000,0.000,100.000,'2026-05-12 22:12:46.972323','2026-05-13 12:50:52.088090'),
(4,12,'605149a9-12b4-4cf0-af7a-3b3842728a5f','Точка 1',NULL,NULL,'http://192.168.42.1:80/DCIM/Camera01/IMG_20260512_200815_00_129.jpg','/DCIM/Camera01/IMG_20260512_200815_00_129.jpg','orders/4/sessions/1674181c-1f00-4e96-9ea2-1914671e4b74/photos/previews/605149a9-12b4-4cf0-af7a-3b3842728a5f_605149a9-12b4-4cf0-af7a-3b3842728a5f.jpg','orders/4/sessions/1674181c-1f00-4e96-9ea2-1914671e4b74/photos/originals/605149a9-12b4-4cf0-af7a-3b3842728a5f_605149a9-12b4-4cf0-af7a-3b3842728a5f.jpg',12254083,12254083,'UPLOADED',0.000,0.000,100.000,'2026-05-12 22:12:58.324810','2026-05-13 12:50:57.447922'),
(20,29,'ca5d2b74-2d79-4630-886c-9103cfa0acde','Точка 1',NULL,NULL,'http://192.168.42.1:80/DCIM/Camera01/IMG_20260512_210634_00_132.jpg','/DCIM/Camera01/IMG_20260512_210634_00_132.jpg','orders/2/sessions/86476880-f49d-4755-ba71-6b1f8e9b9072/photos/previews/ca5d2b74-2d79-4630-886c-9103cfa0acde_ca5d2b74-2d79-4630-886c-9103cfa0acde.jpg','orders/2/sessions/86476880-f49d-4755-ba71-6b1f8e9b9072/photos/originals/ca5d2b74-2d79-4630-886c-9103cfa0acde_ca5d2b74-2d79-4630-886c-9103cfa0acde.jpg',12305807,12305807,'UPLOADED',0.000,0.000,100.000,'2026-05-12 23:09:52.368330','2026-05-13 11:41:40.642087'),
(24,30,'8d02f0d7-2db1-42a9-8a49-166913ecd7ce','Точка 1',NULL,NULL,'http://192.168.42.1:80/DCIM/Camera01/IMG_20260513_120800_00_134.jpg','/DCIM/Camera01/IMG_20260513_120800_00_134.jpg','orders/4/sessions/075674c9-1715-44b0-b014-d8e10a935350/photos/previews/8d02f0d7-2db1-42a9-8a49-166913ecd7ce_8d02f0d7-2db1-42a9-8a49-166913ecd7ce.jpg','orders/4/sessions/075674c9-1715-44b0-b014-d8e10a935350/photos/originals/8d02f0d7-2db1-42a9-8a49-166913ecd7ce_8d02f0d7-2db1-42a9-8a49-166913ecd7ce.jpg',12306324,12306324,'UPLOADED',0.000,0.000,100.000,'2026-05-13 15:26:52.655054','2026-05-13 15:26:52.655054'),
(25,31,'07d23fbc-a181-4532-822f-f9a6ed9b39e7','Точка 2',NULL,NULL,'http://192.168.42.1:80/DCIM/Camera01/IMG_20260513_135200_00_137.jpg','/DCIM/Camera01/IMG_20260513_135200_00_137.jpg','orders/3/sessions/0a4d3b10-341d-463f-b25b-ac1f9e0c5e02/photos/previews/07d23fbc-a181-4532-822f-f9a6ed9b39e7_07d23fbc-a181-4532-822f-f9a6ed9b39e7.jpg','orders/3/sessions/0a4d3b10-341d-463f-b25b-ac1f9e0c5e02/photos/originals/07d23fbc-a181-4532-822f-f9a6ed9b39e7_07d23fbc-a181-4532-822f-f9a6ed9b39e7.jpg',12501272,12501272,'UPLOADED',0.000,0.000,100.000,'2026-05-13 16:30:52.947124','2026-05-13 16:30:52.947124'),
(26,31,'14feebb2-9f5f-4ff8-87ad-ff9c4b972892','Точка 1',NULL,NULL,'http://192.168.42.1:80/DCIM/Camera01/IMG_20260513_135154_00_136.jpg','/DCIM/Camera01/IMG_20260513_135154_00_136.jpg','orders/3/sessions/0a4d3b10-341d-463f-b25b-ac1f9e0c5e02/photos/previews/14feebb2-9f5f-4ff8-87ad-ff9c4b972892_14feebb2-9f5f-4ff8-87ad-ff9c4b972892.jpg','orders/3/sessions/0a4d3b10-341d-463f-b25b-ac1f9e0c5e02/photos/originals/14feebb2-9f5f-4ff8-87ad-ff9c4b972892_14feebb2-9f5f-4ff8-87ad-ff9c4b972892.jpg',12468380,12468380,'UPLOADED',0.000,0.000,100.000,'2026-05-13 16:30:58.153648','2026-05-13 16:30:58.153648'),
(27,32,'2ae7d953-1ac2-4749-b79c-42a9dd783ab2','Точка 7',NULL,1,'http://192.168.42.1:80/DCIM/Camera01/IMG_20260514_141434_00_145.jpg','/DCIM/Camera01/IMG_20260514_141434_00_145.jpg','orders/5/sessions/6c81ff4c-3cbc-4808-a168-75c9048bec14/photos/previews/2ae7d953-1ac2-4749-b79c-42a9dd783ab2_2ae7d953-1ac2-4749-b79c-42a9dd783ab2.jpg','orders/5/sessions/6c81ff4c-3cbc-4808-a168-75c9048bec14/photos/originals/2ae7d953-1ac2-4749-b79c-42a9dd783ab2_2ae7d953-1ac2-4749-b79c-42a9dd783ab2.jpg',11764068,11764068,'UPLOADED',0.000,0.000,100.000,'2026-05-14 16:24:28.659489','2026-05-14 20:06:47.731391'),
(28,32,'aa339941-49d4-402c-820a-187cf26364f0','Точка 6',NULL,2,'http://192.168.42.1:80/DCIM/Camera01/IMG_20260514_141413_00_144.jpg','/DCIM/Camera01/IMG_20260514_141413_00_144.jpg','orders/5/sessions/6c81ff4c-3cbc-4808-a168-75c9048bec14/photos/previews/aa339941-49d4-402c-820a-187cf26364f0_aa339941-49d4-402c-820a-187cf26364f0.jpg','orders/5/sessions/6c81ff4c-3cbc-4808-a168-75c9048bec14/photos/originals/aa339941-49d4-402c-820a-187cf26364f0_aa339941-49d4-402c-820a-187cf26364f0.jpg',12054753,12054753,'UPLOADED',0.000,0.000,100.000,'2026-05-14 16:24:33.836301','2026-05-14 20:06:47.731391'),
(29,32,'69a5da20-988a-46e9-84fa-cc91f7915cf8','Точка 5',NULL,3,'http://192.168.42.1:80/DCIM/Camera01/IMG_20260514_141357_00_143.jpg','/DCIM/Camera01/IMG_20260514_141357_00_143.jpg','orders/5/sessions/6c81ff4c-3cbc-4808-a168-75c9048bec14/photos/previews/69a5da20-988a-46e9-84fa-cc91f7915cf8_69a5da20-988a-46e9-84fa-cc91f7915cf8.jpg','orders/5/sessions/6c81ff4c-3cbc-4808-a168-75c9048bec14/photos/originals/69a5da20-988a-46e9-84fa-cc91f7915cf8_69a5da20-988a-46e9-84fa-cc91f7915cf8.jpg',12198801,12198801,'UPLOADED',0.000,0.000,100.000,'2026-05-14 16:24:39.037477','2026-05-14 20:06:47.731391'),
(30,32,'ac65595b-6a32-4066-a8f8-6d77cf017b2f','Точка 4',NULL,4,'http://192.168.42.1:80/DCIM/Camera01/IMG_20260514_141340_00_142.jpg','/DCIM/Camera01/IMG_20260514_141340_00_142.jpg','orders/5/sessions/6c81ff4c-3cbc-4808-a168-75c9048bec14/photos/previews/ac65595b-6a32-4066-a8f8-6d77cf017b2f_ac65595b-6a32-4066-a8f8-6d77cf017b2f.jpg','orders/5/sessions/6c81ff4c-3cbc-4808-a168-75c9048bec14/photos/originals/ac65595b-6a32-4066-a8f8-6d77cf017b2f_ac65595b-6a32-4066-a8f8-6d77cf017b2f.jpg',12087228,12087228,'UPLOADED',0.000,0.000,100.000,'2026-05-14 16:24:44.142261','2026-05-14 20:06:47.731391'),
(31,32,'2db840c4-3e28-4cea-92b9-157544994178','Точка 3',NULL,5,'http://192.168.42.1:80/DCIM/Camera01/IMG_20260514_141318_00_141.jpg','/DCIM/Camera01/IMG_20260514_141318_00_141.jpg','orders/5/sessions/6c81ff4c-3cbc-4808-a168-75c9048bec14/photos/previews/2db840c4-3e28-4cea-92b9-157544994178_2db840c4-3e28-4cea-92b9-157544994178.jpg','orders/5/sessions/6c81ff4c-3cbc-4808-a168-75c9048bec14/photos/originals/2db840c4-3e28-4cea-92b9-157544994178_2db840c4-3e28-4cea-92b9-157544994178.jpg',12216734,12216734,'UPLOADED',0.000,0.000,100.000,'2026-05-14 16:24:49.316086','2026-05-14 20:06:47.731391'),
(32,32,'99032573-6d7d-434a-af6b-a65a80ce9922','Точка 2',NULL,6,'http://192.168.42.1:80/DCIM/Camera01/IMG_20260514_141255_00_140.jpg','/DCIM/Camera01/IMG_20260514_141255_00_140.jpg','orders/5/sessions/6c81ff4c-3cbc-4808-a168-75c9048bec14/photos/previews/99032573-6d7d-434a-af6b-a65a80ce9922_99032573-6d7d-434a-af6b-a65a80ce9922.jpg','orders/5/sessions/6c81ff4c-3cbc-4808-a168-75c9048bec14/photos/originals/99032573-6d7d-434a-af6b-a65a80ce9922_99032573-6d7d-434a-af6b-a65a80ce9922.jpg',12097229,12097229,'UPLOADED',0.000,0.000,100.000,'2026-05-14 16:24:54.456142','2026-05-14 20:06:47.731391'),
(33,32,'cee6d76b-85e1-4b69-bdb9-a33be7cd26eb','Точка 1',NULL,7,'http://192.168.42.1:80/DCIM/Camera01/IMG_20260514_141232_00_139.jpg','/DCIM/Camera01/IMG_20260514_141232_00_139.jpg','orders/5/sessions/6c81ff4c-3cbc-4808-a168-75c9048bec14/photos/previews/cee6d76b-85e1-4b69-bdb9-a33be7cd26eb_cee6d76b-85e1-4b69-bdb9-a33be7cd26eb.jpg','orders/5/sessions/6c81ff4c-3cbc-4808-a168-75c9048bec14/photos/originals/cee6d76b-85e1-4b69-bdb9-a33be7cd26eb_cee6d76b-85e1-4b69-bdb9-a33be7cd26eb.jpg',12300528,12300528,'UPLOADED',0.000,0.000,100.000,'2026-05-14 16:24:59.687856','2026-05-14 20:06:47.731391');
/*!40000 ALTER TABLE `photo_points` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `processing_jobs`
--

DROP TABLE IF EXISTS `processing_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `processing_jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `session_id` bigint(20) unsigned NOT NULL,
  `order_id` bigint(20) unsigned NOT NULL,
  `job_type` varchar(64) NOT NULL,
  `status` varchar(32) NOT NULL DEFAULT 'QUEUED',
  `metric_status` varchar(32) NOT NULL DEFAULT 'UNKNOWN',
  `marker_expected` tinyint(1) NOT NULL DEFAULT 1,
  `marker_kit_id` varchar(64) NOT NULL DEFAULT 'maklertour_kit_v1',
  `marker_dictionary` varchar(64) NOT NULL DEFAULT 'APRILTAG_36H11',
  `marker_size_m` decimal(8,4) NOT NULL DEFAULT 0.1600,
  `markers_detected_count` int(10) unsigned NOT NULL DEFAULT 0,
  `warning_text` text DEFAULT NULL,
  `error_text` text DEFAULT NULL,
  `created_at` datetime(6) NOT NULL DEFAULT current_timestamp(6),
  `updated_at` datetime(6) NOT NULL DEFAULT current_timestamp(6) ON UPDATE current_timestamp(6),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_processing_jobs_session_type` (`session_id`,`job_type`),
  KEY `idx_processing_jobs_order_id` (`order_id`),
  KEY `idx_processing_jobs_status` (`status`),
  KEY `idx_processing_jobs_metric_status` (`metric_status`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `processing_jobs`
--

LOCK TABLES `processing_jobs` WRITE;
/*!40000 ALTER TABLE `processing_jobs` DISABLE KEYS */;
INSERT INTO `processing_jobs` VALUES
(1,31,3,'MARKER_DETECTION','PROCESSED','NO_MARKERS',1,'maklertour_kit_v1','APRILTAG_36H11',0.1600,0,'Marker detector is not connected yet. Uploaded media found, but marker detection was not executed.',NULL,'2026-05-14 13:14:07.893020','2026-05-14 13:14:53.970699'),
(2,3,4,'MARKER_DETECTION','FAILED','FAILED',1,'maklertour_kit_v1','APRILTAG_36H11',0.1600,0,NULL,'No uploaded media found for marker processing','2026-05-14 13:46:24.141461','2026-05-14 16:55:00.081096'),
(3,12,4,'MARKER_DETECTION','FAILED','FAILED',1,'maklertour_kit_v1','APRILTAG_36H11',0.1600,0,NULL,'Worker was interrupted or stuck during manual AprilTag processing test','2026-05-14 13:46:36.554585','2026-05-14 17:00:31.000000'),
(4,32,5,'MARKER_DETECTION','PROCESSED','METRIC_READY',1,'maklertour_kit_v1','APRILTAG_36H11',0.1600,130,NULL,NULL,'2026-05-14 16:24:23.552873','2026-05-14 17:13:42.133548');
/*!40000 ALTER TABLE `processing_jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `role_menu`
--

DROP TABLE IF EXISTS `role_menu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `role_menu` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `role_code` varchar(32) NOT NULL,
  `menu_key` varchar(128) NOT NULL,
  `is_allowed` tinyint(1) NOT NULL DEFAULT 1,
  `can_view` tinyint(1) NOT NULL DEFAULT 1,
  `can_edit` tinyint(1) NOT NULL DEFAULT 0,
  `can_delete` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_role_menu` (`role_code`,`menu_key`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `role_menu`
--

LOCK TABLES `role_menu` WRITE;
/*!40000 ALTER TABLE `role_menu` DISABLE KEYS */;
INSERT INTO `role_menu` VALUES
(1,'ADMIN','orders',1,1,1,1),
(2,'ADMIN','operator_orders',1,1,1,1),
(3,'ADMIN','users',1,1,1,1),
(4,'BROKER','orders',1,1,1,0),
(5,'OPERATOR','operator_orders',1,1,1,0),
(6,'ADMIN','audit',1,1,0,0);
/*!40000 ALTER TABLE `role_menu` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `role_permissions`
--

DROP TABLE IF EXISTS `role_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `role_permissions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `role_code` varchar(32) NOT NULL,
  `permission_code` varchar(128) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_role_permission` (`role_code`,`permission_code`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `role_permissions`
--

LOCK TABLES `role_permissions` WRITE;
/*!40000 ALTER TABLE `role_permissions` DISABLE KEYS */;
INSERT INTO `role_permissions` VALUES
(1,'ADMIN','*'),
(6,'ADMIN','audit.view'),
(2,'BROKER','orders.create'),
(3,'BROKER','orders.view_own'),
(4,'OPERATOR','orders.take'),
(5,'OPERATOR','orders.upload');
/*!40000 ALTER TABLE `role_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tour_orders`
--

DROP TABLE IF EXISTS `tour_orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tour_orders` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `broker_id` bigint(20) unsigned NOT NULL,
  `operator_id` bigint(20) unsigned DEFAULT NULL,
  `title` varchar(190) NOT NULL,
  `address` text NOT NULL,
  `area_m2` decimal(10,2) DEFAULT NULL,
  `customer_name` varchar(190) DEFAULT NULL,
  `customer_phone` varchar(64) DEFAULT NULL,
  `customer_email` varchar(190) DEFAULT NULL,
  `status` enum('NEW','ASSIGNED','IN_PROGRESS','CAPTURED','UPLOADING','UPLOADED','PROCESSING','READY','CANCELLED') NOT NULL DEFAULT 'NEW',
  `is_published` tinyint(1) NOT NULL DEFAULT 0,
  `public_token` varchar(64) DEFAULT NULL,
  `created_at` datetime(6) NOT NULL DEFAULT current_timestamp(6),
  `updated_at` datetime(6) NOT NULL DEFAULT current_timestamp(6) ON UPDATE current_timestamp(6),
  `closed_at` datetime(6) DEFAULT NULL,
  `closed_by` bigint(20) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_tour_orders_public_token` (`public_token`),
  KEY `idx_tour_orders_broker` (`broker_id`),
  KEY `idx_tour_orders_operator` (`operator_id`),
  KEY `idx_tour_orders_status` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tour_orders`
--

LOCK TABLES `tour_orders` WRITE;
/*!40000 ALTER TABLE `tour_orders` DISABLE KEYS */;
INSERT INTO `tour_orders` VALUES
(1,1,NULL,'админ тест','админский',100.00,'админ','01','01@gmail.com','NEW',0,'1a84c8982edefaca4b3defa1a865d935','2026-05-11 11:49:49.324797','2026-05-11 11:49:49.324797',NULL,NULL),
(2,1,2,'admin 02','adminskiy 02',200.00,'admin 02','02','02@gmail.com','UPLOADED',1,'3ae4780ab1c380868b253bb95258e500','2026-05-11 11:50:29.354555','2026-05-12 23:09:47.168623',NULL,NULL),
(3,2,NULL,'ilya','ilyamskiy',300.00,'ilya','03','03@gmail.com','NEW',0,'ba5ee8cdc37ced726d5a7e4fc3dd723a','2026-05-11 11:51:12.688328','2026-05-11 13:19:21.604710',NULL,NULL),
(4,2,2,'ilya 02','iyamskiy 02',400.00,'02','02','04@gmail.com','UPLOADED',1,'f06937cdbdadca3c59614082582d0af6','2026-05-11 11:51:31.391885','2026-05-11 22:56:04.421476',NULL,NULL),
(5,1,2,'Brunhildensteg 16D','Brunhildensteg 16D',99.00,'Svitlana Chykalova','016097735533','','UPLOADED',1,'4fc103d82019ee8025c3564e5e1b0749','2026-05-14 16:10:38.717143','2026-05-14 16:24:23.551216',NULL,NULL);
/*!40000 ALTER TABLE `tour_orders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tour_point_links`
--

DROP TABLE IF EXISTS `tour_point_links`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tour_point_links` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `session_id` bigint(20) unsigned NOT NULL,
  `from_photo_point_id` bigint(20) unsigned NOT NULL,
  `to_photo_point_id` bigint(20) unsigned NOT NULL,
  `yaw_deg` decimal(8,3) NOT NULL DEFAULT 0.000,
  `pitch_deg` decimal(8,3) NOT NULL DEFAULT 0.000,
  `label` varchar(255) DEFAULT NULL,
  `source` varchar(32) NOT NULL DEFAULT 'MANUAL',
  `shared_markers_json` longtext DEFAULT NULL,
  `confidence` double DEFAULT NULL,
  `created_at` datetime(6) NOT NULL DEFAULT current_timestamp(6),
  `updated_at` datetime(6) NOT NULL DEFAULT current_timestamp(6) ON UPDATE current_timestamp(6),
  PRIMARY KEY (`id`),
  KEY `idx_session_id` (`session_id`),
  KEY `idx_from_point` (`from_photo_point_id`),
  KEY `idx_to_point` (`to_photo_point_id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tour_point_links`
--

LOCK TABLES `tour_point_links` WRITE;
/*!40000 ALTER TABLE `tour_point_links` DISABLE KEYS */;
INSERT INTO `tour_point_links` VALUES
(6,32,28,27,78.049,-19.988,'Точка 7','MANUAL',NULL,NULL,'2026-05-14 22:28:08.000000','2026-05-14 22:28:08.000000'),
(7,32,33,32,53.750,-30.509,'Точка 2','MANUAL',NULL,NULL,'2026-05-14 22:29:03.000000','2026-05-14 22:29:03.000000'),
(8,32,32,33,-130.150,-9.831,'Точка 1','MANUAL',NULL,NULL,'2026-05-14 22:29:19.000000','2026-05-14 22:29:19.000000'),
(9,32,32,31,-20.511,-6.728,'Точка 3','MANUAL',NULL,NULL,'2026-05-14 22:29:45.000000','2026-05-14 22:29:46.000000'),
(10,32,31,32,35.684,-12.285,'Точка 2','MANUAL',NULL,NULL,'2026-05-14 22:29:55.000000','2026-05-14 22:29:55.000000'),
(11,32,32,30,115.186,2.179,'Точка 4','MANUAL',NULL,NULL,'2026-05-14 22:30:25.000000','2026-05-14 22:30:25.000000'),
(12,32,30,29,-61.597,-6.603,'Точка 5','MANUAL',NULL,NULL,'2026-05-14 22:30:44.000000','2026-05-14 22:30:44.000000'),
(13,32,30,31,46.822,-11.184,'Точка 3','MANUAL',NULL,NULL,'2026-05-14 22:30:53.000000','2026-05-14 22:30:53.000000'),
(14,32,30,28,154.705,-4.206,'Точка 6','MANUAL',NULL,NULL,'2026-05-14 22:31:09.000000','2026-05-14 22:31:09.000000'),
(15,32,29,32,139.195,-7.744,'Точка 2','MANUAL',NULL,NULL,'2026-05-14 22:31:23.000000','2026-05-14 22:31:23.000000'),
(16,32,29,33,100.779,-9.450,'Точка 1','MANUAL',NULL,NULL,'2026-05-14 22:31:28.000000','2026-05-14 22:31:28.000000'),
(17,32,29,30,-140.946,-14.850,'Точка 4','MANUAL',NULL,NULL,'2026-05-14 22:31:35.000000','2026-05-14 22:31:35.000000'),
(19,32,27,28,89.148,-9.046,'Точка 6','MANUAL',NULL,NULL,'2026-05-14 22:31:57.000000','2026-05-14 22:31:57.000000'),
(20,32,28,30,-31.662,-11.876,'Точка 4','MANUAL',NULL,NULL,'2026-05-14 22:32:13.000000','2026-05-14 22:32:13.000000'),
(21,32,28,32,19.034,-13.390,'Точка 2','MANUAL',NULL,NULL,'2026-05-14 22:32:18.000000','2026-05-14 22:32:18.000000');
/*!40000 ALTER TABLE `tour_point_links` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tour_point_positions`
--

DROP TABLE IF EXISTS `tour_point_positions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tour_point_positions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `session_id` bigint(20) unsigned NOT NULL,
  `photo_point_id` bigint(20) unsigned NOT NULL,
  `x_m` decimal(10,3) NOT NULL DEFAULT 0.000,
  `y_m` decimal(10,3) NOT NULL DEFAULT 0.000,
  `z_m` decimal(10,3) DEFAULT 0.000,
  `yaw_deg` decimal(8,3) DEFAULT 0.000,
  `source` varchar(32) NOT NULL DEFAULT 'MANUAL',
  `created_at` datetime(6) NOT NULL DEFAULT current_timestamp(6),
  `updated_at` datetime(6) NOT NULL DEFAULT current_timestamp(6) ON UPDATE current_timestamp(6),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_photo_point` (`photo_point_id`),
  KEY `idx_session_id` (`session_id`)
) ENGINE=InnoDB AUTO_INCREMENT=82 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tour_point_positions`
--

LOCK TABLES `tour_point_positions` WRITE;
/*!40000 ALTER TABLE `tour_point_positions` DISABLE KEYS */;
INSERT INTO `tour_point_positions` VALUES
(55,32,31,5.707,1.017,0.000,0.000,'MANUAL','2026-05-14 22:01:46.916983','2026-05-14 22:32:48.000000'),
(76,32,27,0.000,0.000,0.000,0.000,'MARKER_SEQUENCE_COVISIBILITY','2026-05-15 13:25:40.620797','2026-05-15 13:25:40.620797'),
(77,32,28,1.587,0.000,0.000,0.000,'MARKER_SEQUENCE_COVISIBILITY','2026-05-15 13:25:40.621760','2026-05-15 13:25:40.621760'),
(78,32,29,3.096,0.000,0.000,0.000,'MARKER_SEQUENCE_COVISIBILITY','2026-05-15 13:25:40.622688','2026-05-15 13:25:40.622688'),
(79,32,30,4.209,0.000,0.000,0.000,'MARKER_SEQUENCE_COVISIBILITY','2026-05-15 13:25:40.623721','2026-05-15 13:25:40.623721'),
(80,32,32,7.056,0.000,0.000,0.000,'MARKER_SEQUENCE_COVISIBILITY','2026-05-15 13:25:40.625250','2026-05-15 13:25:40.625250'),
(81,32,33,8.024,0.000,0.000,0.000,'MARKER_SEQUENCE_COVISIBILITY','2026-05-15 13:25:40.626189','2026-05-15 13:25:40.626189');
/*!40000 ALTER TABLE `tour_point_positions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `uploads`
--

DROP TABLE IF EXISTS `uploads`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `uploads` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `order_id` bigint(20) unsigned DEFAULT NULL,
  `session_id` bigint(20) unsigned DEFAULT NULL,
  `entity_type` enum('POINT_PREVIEW','POINT_ORIGINAL','VIDEO_SCAN') NOT NULL,
  `entity_id` bigint(20) unsigned DEFAULT NULL,
  `original_filename` varchar(255) NOT NULL,
  `storage_path` varchar(500) DEFAULT NULL,
  `mime_type` varchar(128) DEFAULT NULL,
  `size_bytes` bigint(20) unsigned DEFAULT NULL,
  `sha256` char(64) DEFAULT NULL,
  `state` enum('INIT','UPLOADING','COMPLETED','FAILED') NOT NULL DEFAULT 'INIT',
  `created_at` datetime(6) NOT NULL DEFAULT current_timestamp(6),
  `completed_at` datetime(6) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_uploads_user` (`user_id`),
  KEY `idx_uploads_order` (`order_id`),
  KEY `idx_uploads_session` (`session_id`),
  KEY `idx_uploads_state` (`state`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `uploads`
--

LOCK TABLES `uploads` WRITE;
/*!40000 ALTER TABLE `uploads` DISABLE KEYS */;
/*!40000 ALTER TABLE `uploads` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(64) NOT NULL,
  `email` varchar(190) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `full_name` varchar(190) DEFAULT NULL,
  `phone` varchar(64) DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `role` enum('ADMIN','BROKER','OPERATOR','CLIENT') NOT NULL DEFAULT 'BROKER',
  `ui_lang` varchar(8) NOT NULL DEFAULT 'ru',
  `ui_settings` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`ui_settings`)),
  `last_login_at` datetime(6) DEFAULT NULL,
  `login_count` int(10) unsigned NOT NULL DEFAULT 0,
  `last_login_ip` varchar(64) DEFAULT NULL,
  `last_user_agent` text DEFAULT NULL,
  `created_at` datetime(6) NOT NULL DEFAULT current_timestamp(6),
  `updated_at` datetime(6) NOT NULL DEFAULT current_timestamp(6) ON UPDATE current_timestamp(6),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_users_username` (`username`),
  UNIQUE KEY `uq_users_email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES
(1,'admin','admin@maklertour.local','$2b$10$wgYcHFsY3HFOwEdfKtKaPOmosiZnMeCL5bERqgSwIQtrCyEg4c2yW','Administrator',NULL,1,'ADMIN','ru',NULL,'2026-05-15 11:29:04.088498',22,'84.166.208.159','Mozilla/5.0 (X11; Linux x86_64; rv:145.0) Gecko/20100101 Firefox/145.0','2026-05-10 12:56:12.748785','2026-05-15 11:29:04.088498'),
(2,'ilya.chykalov@cargocells.com','ilya.chykalov@cargocells.com','$2y$10$Bzj.QidkppPdySgLGZnYIuvVDKjNnG7xM5EZifJRdU3ipThRVQVRa','myself',NULL,1,'OPERATOR','ru',NULL,'2026-05-15 11:38:13.974931',9,'84.166.208.159','Mozilla/5.0 (X11; Linux x86_64; rv:145.0) Gecko/20100101 Firefox/145.0','2026-05-10 17:52:34.220151','2026-05-15 11:38:13.974931');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `video_scans`
--

DROP TABLE IF EXISTS `video_scans`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `video_scans` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `session_id` bigint(20) unsigned NOT NULL,
  `app_scan_uuid` varchar(64) NOT NULL,
  `filename` varchar(255) NOT NULL,
  `local_camera_url` text DEFAULT NULL,
  `storage_path` varchar(500) DEFAULT NULL,
  `size_bytes` bigint(20) unsigned DEFAULT NULL,
  `duration_sec` int(11) DEFAULT NULL,
  `upload_state` enum('LOCAL_ONLY','QUEUED','UPLOADING','UPLOADED','FAILED') NOT NULL DEFAULT 'LOCAL_ONLY',
  `processing_state` enum('NOT_STARTED','PROCESSING','DONE','FAILED') NOT NULL DEFAULT 'NOT_STARTED',
  `created_at` datetime(6) NOT NULL DEFAULT current_timestamp(6),
  `updated_at` datetime(6) NOT NULL DEFAULT current_timestamp(6) ON UPDATE current_timestamp(6),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_video_scan_app_uuid` (`app_scan_uuid`),
  KEY `idx_video_scans_session` (`session_id`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `video_scans`
--

LOCK TABLES `video_scans` WRITE;
/*!40000 ALTER TABLE `video_scans` DISABLE KEYS */;
INSERT INTO `video_scans` VALUES
(1,1,'test-scan-001','test-scan-001_test.mp4','http://192.168.42.1:80/DCIM/Camera01/test.mp4','orders/1/sessions/test-session-001/videos/test-scan-001_test.mp4',4069115,1,'UPLOADED','NOT_STARTED','2026-05-10 17:17:46.570740','2026-05-10 17:24:01.334015'),
(3,4,'bffdf9a5-fc10-42f7-b9dc-d04c5c7792c8','bffdf9a5-fc10-42f7-b9dc-d04c5c7792c8_VID_20260511_141109_00_128.mp4','http://192.168.42.1:80/DCIM/Camera01/VID_20260511_141109_00_128.mp4','orders/4/sessions/192c4533-fe07-45e1-881b-c3c41f95a563/videos/bffdf9a5-fc10-42f7-b9dc-d04c5c7792c8_VID_20260511_141109_00_128.mp4',189451514,7,'UPLOADED','NOT_STARTED','2026-05-11 22:56:04.316468','2026-05-12 10:23:26.463301'),
(5,12,'25be3d10-beda-480b-b1c3-bb33ef7a2971','25be3d10-beda-480b-b1c3-bb33ef7a2971_VID_20260512_200830_00_131.mp4','http://192.168.42.1:80/DCIM/Camera01/VID_20260512_200830_00_131.mp4','orders/4/sessions/1674181c-1f00-4e96-9ea2-1914671e4b74/videos/25be3d10-beda-480b-b1c3-bb33ef7a2971_VID_20260512_200830_00_131.mp4',170315002,5,'UPLOADED','NOT_STARTED','2026-05-12 22:12:34.967144','2026-05-13 12:50:46.537129'),
(22,29,'c28c048f-cd78-4207-bcbf-bf4e0da7725c','c28c048f-cd78-4207-bcbf-bf4e0da7725c_VID_20260512_210641_00_133.mp4','http://192.168.42.1:80/DCIM/Camera01/VID_20260512_210641_00_133.mp4','orders/2/sessions/86476880-f49d-4755-ba71-6b1f8e9b9072/videos/c28c048f-cd78-4207-bcbf-bf4e0da7725c_VID_20260512_210641_00_133.mp4',126274810,2,'UPLOADED','NOT_STARTED','2026-05-12 23:09:47.166841','2026-05-13 11:41:37.500028'),
(25,30,'8930d2b2-040e-4000-b165-023dad4f9a85','8930d2b2-040e-4000-b165-023dad4f9a85_VID_20260513_120807_00_135.mp4','http://192.168.42.1:80/DCIM/Camera01/VID_20260513_120807_00_135.mp4','orders/4/sessions/075674c9-1715-44b0-b014-d8e10a935350/videos/8930d2b2-040e-4000-b165-023dad4f9a85_VID_20260513_120807_00_135.mp4',356699388,17,'UPLOADED','NOT_STARTED','2026-05-13 15:26:46.594990','2026-05-13 15:26:46.594990'),
(26,32,'2144e047-f718-402b-88da-77d6485ba18c','2144e047-f718-402b-88da-77d6485ba18c_VID_20260514_141105_00_138.mp4','http://192.168.42.1:80/DCIM/Camera01/VID_20260514_141105_00_138.mp4','orders/5/sessions/6c81ff4c-3cbc-4808-a168-75c9048bec14/videos/2144e047-f718-402b-88da-77d6485ba18c_VID_20260514_141105_00_138.mp4',1115081980,60,'UPLOADED','NOT_STARTED','2026-05-14 16:24:20.153820','2026-05-14 16:24:20.153822');
/*!40000 ALTER TABLE `video_scans` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'maklertour'
--

--
-- Dumping routines for database 'maklertour'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-05-15 13:26:22
